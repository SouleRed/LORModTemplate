public static class ArrayExt
{
	public static bool Contains<T>(this T[] haystack, T needle)
	{
		int num = haystack.Length;
		for (int i = 0; i < num; i++)
		{
			if (haystack[i] != null)
			{
				ref readonly T reference = ref haystack[i];
				object obj = needle;
				if (reference.Equals(obj))
				{
					return true;
				}
			}
		}
		return false;
	}
}
