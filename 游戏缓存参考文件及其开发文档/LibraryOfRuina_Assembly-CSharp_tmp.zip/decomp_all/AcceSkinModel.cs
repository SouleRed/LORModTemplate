using UnityEngine;

public class AcceSkinModel : ItemModel
{
	public Sprite front;

	public Sprite back;

	public static AcceSkinModel CreateSkin(string src)
	{
		AcceSkinModel acceSkinModel = new AcceSkinModel();
		string text = "Sprites/CharAppearance/Acce/" + src + "/";
		acceSkinModel.front = Resources.Load<Sprite>(text + "Front acce");
		acceSkinModel.back = Resources.Load<Sprite>(text + "Back acce");
		return acceSkinModel;
	}
}
