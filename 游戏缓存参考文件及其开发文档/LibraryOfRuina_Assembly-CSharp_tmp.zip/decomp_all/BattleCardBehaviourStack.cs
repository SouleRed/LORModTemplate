using System.Collections.Generic;

public class BattleCardBehaviourStack
{
	public List<BattleDiceBehaviourUI> StartBehaviours = new List<BattleDiceBehaviourUI>();

	public bool setStartBehavior;

	public List<BattleDiceBehaviourUI> BeforeActionBehaviours = new List<BattleDiceBehaviourUI>();

	public bool setBeforeBehavior;

	public List<BattleDiceBehaviourUI> EndBehaviours = new List<BattleDiceBehaviourUI>();

	public bool setEndBehavior;
}
