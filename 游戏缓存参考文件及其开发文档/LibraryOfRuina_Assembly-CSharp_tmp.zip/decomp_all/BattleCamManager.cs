using System;
using System.Collections;
using System.Collections.Generic;
using UI;
using UnityEngine;
using UnityEngine.PostProcessing;

public class BattleCamManager : SingletonBehavior<BattleCamManager>
{
	public enum CamControlMode
	{
		MANUAL,
		FOCUS
	}

	public enum ViewMode
	{
		NORMAL,
		RENCOUNTER
	}

	[Header("------------- References -------------")]
	[SerializeField]
	private CamRootRotator _camRotator;

	[SerializeField]
	private Vector3[] _stdCamPositions;

	[SerializeField]
	private float _maxOrthoSize;

	[SerializeField]
	private float _minOrthoSize;

	private const float _ORTHO_SIZE_MIN = 13f;

	[SerializeField]
	private float _minFov;

	[SerializeField]
	private float _maxFov;

	[SerializeField]
	private float _focusCamMoveSmoothTime;

	[SerializeField]
	private Transform _bgCamTransform;

	[SerializeField]
	private Transform _fgCamTransform;

	[SerializeField]
	private Camera _uiCam;

	[SerializeField]
	private Camera _effectCam;

	[SerializeField]
	private Camera _characterCam;

	[SerializeField]
	private Camera _characterUiCam;

	[SerializeField]
	private Camera _mainCam;

	[Space]
	[Header("------------- Runtime -------------")]
	[SerializeField]
	private CamControlMode _camMode;

	[SerializeField]
	private Vector3 _curStdPos;

	[SerializeField]
	private float _curStdOrtho;

	[SerializeField]
	private float _smoothTime;

	[SerializeField]
	private float _maxSpeed;

	[SerializeField]
	private float _manualCamMoveSpeed;

	[SerializeField]
	private float _manualCamZoomSpeed;

	[SerializeField]
	private List<BattleUnitView> _focusTargetList = new List<BattleUnitView>();

	[SerializeField]
	private List<MonoBehaviour> _defaultCamFilters;

	[SerializeField]
	private float[] _focusOffsetY;

	public float[] targetFov;

	private bool _bCamIsReturning;

	private Coroutine _shakeRoutine;

	private Coroutine _returnRoutine;

	private Coroutine _firstRencounterRoutine;

	private Coroutine _vignetteRoutine;

	private Coroutine _dofRoutine;

	private bool _bReadyRencounter;

	private bool _firstRencounter;

	private List<MonoBehaviour> _filterList = new List<MonoBehaviour>();

	private Coroutine _changeProjectionRoutine;

	private bool _bChangingProjection;

	[HideInInspector]
	public bool scrollable = true;

	private readonly float FIXED_TUTORIAL_ORTHOSIZE = 39.2f;

	private Coroutine focusRoutine;

	private bool _bZoomAction;

	private Coroutine _zoomRoutine;

	public bool isTiltingDone;

	[SerializeField]
	private AnimationCurve _tiltCurve;

	private bool resetCommand;

	private bool _bFocusKnockback;

	private float _eee;

	public bool stopFocusByRencounter;

	public Vector3 focusOneUnitPosition = Vector3.zero;

	public BattleUnitView focusOneUnitTarget;

	private float _focusZoomFactor = 1f;

	private Vector3 focusPos;

	[SerializeField]
	private AnimationCurve _returnPosCurve;

	[SerializeField]
	private AnimationCurve _returnOrthoCurve;

	[SerializeField]
	[Range(0.5f, 5f)]
	private float _returnSpeed;

	private bool _isShaking;

	public static int testAllyEmotionLv;

	public static int testEnemyEmotionLv;

	public bool IsCamIsReturning => _bCamIsReturning;

	public float RotationX => _camRotator.transform.rotation.eulerAngles.x;

	public Camera mainCam => _mainCam;

	public CamRootRotator camRotator => _camRotator;

	public Camera bgCam => _bgCamTransform.GetComponent<Camera>();

	public Camera EffectCam => _effectCam;

	public Camera CharacterUiCam => _characterUiCam;

	public bool IsReadyRencounter => _bReadyRencounter;

	public bool IsChanginProjection => _bChangingProjection;

	protected BattleCamManager()
	{
	}

	public List<Camera> GetAllCamera()
	{
		List<Camera> list = new List<Camera>();
		if (_bgCamTransform.GetComponent<Camera>() != null)
		{
			list.Add(_bgCamTransform.GetComponent<Camera>());
		}
		list.Add(_mainCam);
		list.Add(_characterUiCam);
		list.Add(_characterCam);
		list.Add(_uiCam);
		list.Add(_effectCam);
		return list;
	}

	public void ResetCamSetting()
	{
		ChangeCamProjection(isPerspective: false);
		float currentBorderPos = SingletonBehavior<HexagonalMapManager>.Instance.GetCurrentBorderPos(HexagonalMapManager.WallDirection.RIGHT);
		float currentBorderPos2 = SingletonBehavior<HexagonalMapManager>.Instance.GetCurrentBorderPos(HexagonalMapManager.WallDirection.LEFT);
		_curStdOrtho = (currentBorderPos - currentBorderPos2) * 0.35f;
		_curStdPos = _stdCamPositions[3];
		resetCommand = false;
		_camRotator.UpdateBorder(_curStdOrtho * 0.804f, 30f);
		base.transform.localPosition = _curStdPos;
		_mainCam.orthographicSize = _curStdOrtho;
		_bCamIsReturning = false;
		_focusTargetList.Clear();
		_camRotator.lookAt.transform.position = Vector3.zero;
		float num = _camRotator.mapBorder.size.x * 0.5f;
		float num2 = _curStdOrtho * 2f / num * 0.804f;
		_camRotator.mapBorder.transform.localScale = Vector3.one * num2;
		BlurCharacterCam(active: false);
		VignetteCharacterCam(active: false);
		UpdateOtherCameras();
		RemoveCameraFilterAll();
		FollowOneUnit(null, b: false);
		ChangeCamMode(CamControlMode.MANUAL);
	}

	public T AddCameraFilter<T>(bool duplicate = false) where T : MonoBehaviour
	{
		if (!duplicate)
		{
			foreach (MonoBehaviour filter in _filterList)
			{
				if (filter is T)
				{
					return filter as T;
				}
			}
		}
		T val = _effectCam.gameObject.AddComponent<T>();
		_filterList.Add(val);
		return val;
	}

	public void RemoveCameraFilter<T>() where T : MonoBehaviour
	{
		T component = _effectCam.gameObject.GetComponent<T>();
		if (component != null)
		{
			_filterList.Remove(component);
			UnityEngine.Object.DestroyImmediate(component);
		}
	}

	public void RemoveCameraFilterAll()
	{
		foreach (MonoBehaviour filter in _filterList)
		{
			UnityEngine.Object.Destroy(filter);
		}
		_filterList.Clear();
		foreach (MonoBehaviour defaultCamFilter in _defaultCamFilters)
		{
			defaultCamFilter.enabled = false;
		}
	}

	public void ChangeCamMode(CamControlMode mode)
	{
		_camMode = mode;
	}

	public void StartMoveUnits()
	{
		if (!_firstRencounter)
		{
			_firstRencounter = true;
			_camRotator.UpdateBorder(10f, 10f);
			_focusTargetList.Clear();
			BattleObjectManager.instance.GetAliveList().ForEach(delegate(BattleUnitModel x)
			{
				_focusTargetList.Add(x.view);
			});
			_bReadyRencounter = true;
			ChangeCamMode(CamControlMode.FOCUS);
			VignetteCharacterCam(active: true);
		}
	}

	public void ChangeCamProjection(bool isPerspective)
	{
		_mainCam.orthographic = !isPerspective;
		_characterCam.orthographic = !isPerspective;
		_characterUiCam.orthographic = !isPerspective;
		_uiCam.orthographic = !isPerspective;
		_effectCam.orthographic = !isPerspective;
	}

	private IEnumerator ChangeCamProjectionRoutine()
	{
		float aspect = (float)Screen.width / (float)Screen.height;
		float fov = targetFov[2];
		switch (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.mapSize)
		{
		case MapSize.S:
			fov = targetFov[0];
			break;
		case MapSize.M:
			fov = targetFov[1];
			break;
		case MapSize.L:
			fov = targetFov[2];
			break;
		}
		Matrix4x4 p = Matrix4x4.Perspective(fov, aspect, 0.3f, 1000f);
		_ = _mainCam.projectionMatrix;
		_bChangingProjection = true;
		float elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime;
			Matrix4x4 projectionMatrix = _mainCam.projectionMatrix;
			Matrix4x4 projectionMatrix2 = default(Matrix4x4);
			for (int i = 0; i < 16; i++)
			{
				projectionMatrix2[i] = Mathf.Lerp(projectionMatrix[i], p[i], elapsed);
			}
			_mainCam.projectionMatrix = projectionMatrix2;
			_characterCam.projectionMatrix = projectionMatrix2;
			_characterUiCam.projectionMatrix = projectionMatrix2;
			_uiCam.projectionMatrix = projectionMatrix2;
			_effectCam.projectionMatrix = projectionMatrix2;
			yield return YieldCache.waitFrame;
		}
		float fieldOfView = Mathf.Atan(1f / _mainCam.projectionMatrix[1, 1]) * 2f * 57.29578f;
		_mainCam.orthographic = false;
		_characterCam.orthographic = false;
		_characterUiCam.orthographic = false;
		_uiCam.orthographic = false;
		_effectCam.orthographic = false;
		_mainCam.fieldOfView = fieldOfView;
		_characterCam.fieldOfView = fieldOfView;
		_characterUiCam.fieldOfView = fieldOfView;
		_uiCam.fieldOfView = fieldOfView;
		_effectCam.fieldOfView = fieldOfView;
		_mainCam.ResetProjectionMatrix();
		_characterCam.ResetProjectionMatrix();
		_characterUiCam.ResetProjectionMatrix();
		_uiCam.ResetProjectionMatrix();
		_effectCam.ResetProjectionMatrix();
		_bChangingProjection = false;
	}

	public void FollowUnits(bool isAction, List<BattleUnitModel> modelList)
	{
		ChangeCamMode(CamControlMode.FOCUS);
		_focusTargetList.Clear();
		modelList.ForEach(delegate(BattleUnitModel x)
		{
			_focusTargetList.Add(x.view);
		});
		if (isAction)
		{
			ChangeCamProjection(isPerspective: true);
			if (focusRoutine != null)
			{
				StopCoroutine(focusRoutine);
				focusRoutine = null;
			}
		}
		else
		{
			ChangeCamProjection(isPerspective: false);
		}
	}

	public void FollowOneUnit(BattleUnitModel model, bool b)
	{
		if (b)
		{
			stopFocusByRencounter = true;
			focusOneUnitPosition = model.view.WorldPosition;
			focusOneUnitTarget = model.view;
		}
		else
		{
			stopFocusByRencounter = false;
			focusOneUnitPosition = Vector3.zero;
			focusOneUnitTarget = null;
		}
	}

	public void ShakeCam(float speed = 50f, float xAmount = 0.015f, float yAmount = 0.015f)
	{
		CameraFilterPack_FX_EarthQuake component = _characterCam.GetComponent<CameraFilterPack_FX_EarthQuake>();
		if (!(component == null) && xAmount + yAmount >= component.X + component.Y)
		{
			if (_isShaking && _shakeRoutine != null)
			{
				StopCoroutine(_shakeRoutine);
			}
			_shakeRoutine = StartCoroutine(VibeCam(component, speed, new Vector2(xAmount, yAmount)));
		}
	}

	public void BloodFilter(int sign, float ratioLeft = 0.6f, float ratioRight = 0.6f)
	{
		ratioLeft = ((ratioLeft < 0.15f) ? 0.333f : ((ratioLeft < 0.5f) ? 0.666f : ((!(ratioLeft < 0.8f)) ? 1.333f : 1f)));
		ratioRight = ((ratioRight < 0.15f) ? 0.333f : ((ratioRight < 0.5f) ? 0.666f : ((!(ratioRight < 0.8f)) ? 1.333f : 1f)));
		StartCoroutine(OnBloodFilter(sign, ratioLeft, ratioRight));
	}

	private IEnumerator OnBloodFilter(int sign, float ratioLeft, float ratioRight)
	{
		CameraFilterPack_AAA_Blood_Hit bloodFilter = _characterCam.GetComponent<CameraFilterPack_AAA_Blood_Hit>();
		if (!_defaultCamFilters.Exists((MonoBehaviour x) => x == bloodFilter))
		{
			_defaultCamFilters.Add(bloodFilter);
		}
		bloodFilter.enabled = true;
		bloodFilter.Hit_Left = 0f;
		bloodFilter.Hit_Down = 0f;
		bloodFilter.Blood_Hit_Left = 0f;
		bloodFilter.Blood_Hit_Down = 0f;
		bloodFilter.Blood_Hit_Full_3 = 0f;
		bloodFilter.Hit_Right = 0f;
		bloodFilter.Hit_Up = 0f;
		bloodFilter.Blood_Hit_Right = 0f;
		bloodFilter.Blood_Hit_Up = 0f;
		bloodFilter.Blood_Hit_Full_3 = 0f;
		float v1 = 0.846f;
		float v3 = 0.445f;
		float v5 = 0.108f;
		if (sign < 0)
		{
			float elapsed = 0f;
			v1 *= ratioLeft;
			v3 *= ratioLeft;
			v5 *= ratioLeft;
			while (elapsed < 1f)
			{
				elapsed += Time.deltaTime;
				bloodFilter.Hit_Left = Mathf.Lerp(v1, 0f, elapsed);
				bloodFilter.Blood_Hit_Left = Mathf.Lerp(v3, 0f, elapsed);
				bloodFilter.Blood_Hit_Full_3 = Mathf.Lerp(v5, 0f, elapsed);
				yield return YieldCache.waitFrame;
			}
			bloodFilter.Hit_Left = v1;
			bloodFilter.Blood_Hit_Left = v3;
			bloodFilter.Blood_Hit_Full_3 = v5;
		}
		else if (sign > 0)
		{
			float elapsed = 0f;
			v1 *= ratioRight;
			v3 *= ratioRight;
			v5 *= ratioRight;
			while (elapsed < 1f)
			{
				elapsed += Time.deltaTime;
				bloodFilter.Hit_Right = Mathf.Lerp(v1, 0f, elapsed);
				bloodFilter.Blood_Hit_Right = Mathf.Lerp(v3, 0f, elapsed);
				bloodFilter.Blood_Hit_Full_3 = Mathf.Lerp(v5, 0f, elapsed);
				yield return YieldCache.waitFrame;
			}
			bloodFilter.Hit_Right = v1;
			bloodFilter.Blood_Hit_Right = v3;
			bloodFilter.Blood_Hit_Full_3 = v5;
		}
		else
		{
			float elapsed = 0f;
			float v1_right = v1 * ratioRight;
			float v3_right = v3 * ratioRight;
			float v5_right = v5 * ratioRight;
			v1 *= ratioLeft;
			v3 *= ratioLeft;
			v5 *= ratioLeft;
			while (elapsed < 1f)
			{
				elapsed += Time.deltaTime;
				bloodFilter.Hit_Left = Mathf.Lerp(v1, 0f, elapsed);
				bloodFilter.Blood_Hit_Left = Mathf.Lerp(v3, 0f, elapsed);
				if (v5 > v5_right)
				{
					bloodFilter.Blood_Hit_Full_3 = Mathf.Lerp(v5, 0f, elapsed);
				}
				bloodFilter.Hit_Right = Mathf.Lerp(v1_right, 0f, elapsed);
				bloodFilter.Blood_Hit_Right = Mathf.Lerp(v3_right, 0f, elapsed);
				if (v5 < v5_right)
				{
					bloodFilter.Blood_Hit_Full_3 = Mathf.Lerp(v5_right, 0f, elapsed);
				}
				yield return YieldCache.waitFrame;
			}
			bloodFilter.Hit_Left = v1;
			bloodFilter.Blood_Hit_Left = v3;
			bloodFilter.Blood_Hit_Full_3 = v5;
			bloodFilter.Hit_Right = v1_right;
			bloodFilter.Blood_Hit_Right = v3_right;
			bloodFilter.Blood_Hit_Full_3 = v5_right;
		}
		bloodFilter.enabled = false;
	}

	public void BlurBackgroundCam(bool enable)
	{
		PostProcessingBehaviour component = _bgCamTransform.GetComponent<PostProcessingBehaviour>();
		if (component != null)
		{
			component.enabled = enable;
		}
	}

	public void BlurCharacterCam(bool active, float speed = 2.5f)
	{
		PostProcessingBehaviour component = _characterCam.GetComponent<PostProcessingBehaviour>();
		if (_dofRoutine != null)
		{
			StopCoroutine(_dofRoutine);
			_dofRoutine = null;
		}
		_dofRoutine = StartCoroutine(BlurRoutine(component, active, speed));
	}

	private IEnumerator BlurRoutine(PostProcessingBehaviour pp, bool active, float speed)
	{
		float elapsed = 0f;
		DepthOfFieldModel dof = pp.profile.depthOfField;
		DepthOfFieldModel.Settings dofSetting = dof.settings;
		float src = dofSetting.focalLength;
		int dst = ((!active) ? 1 : 188);
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * speed;
			dofSetting.focalLength = Mathf.Lerp(src, dst, elapsed);
			dof.settings = dofSetting;
			yield return YieldCache.waitFrame;
		}
		dofSetting.focalLength = dst;
		dof.settings = dofSetting;
	}

	public void SetVignetteColorBgCam(Color c, bool active = true)
	{
		CameraFilterPack_TV_Vignetting component = _bgCamTransform.GetComponent<CameraFilterPack_TV_Vignetting>();
		component.VignettingColor = c;
		component.enabled = active;
		SingletonBehavior<BattleManagerUI>.Instance.ui_emotionInfoBar.SetSephirahFrameImgColor(c);
	}

	public void SetCreatureFilter()
	{
		if (_effectCam.GetComponent<CameraFilterPack_Drawing_Paper3>() != null)
		{
			_effectCam.GetComponent<CameraFilterPack_Drawing_Paper3>().enabled = SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.isCreature && !SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.isBossPhase && !SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.isEgo;
		}
	}

	public void SetFilter(string str, params object[] p)
	{
		if (str == "BloodBath")
		{
			StartCoroutine(BloodOnScreen((int)p[0]));
		}
	}

	private IEnumerator BloodOnScreen(int lv)
	{
		float blood_On_Screen = 1f;
		switch (lv)
		{
		case 1:
			blood_On_Screen = 1f;
			break;
		case 2:
			blood_On_Screen = 1.2f;
			break;
		case 3:
			blood_On_Screen = 1.6f;
			break;
		}
		CameraFilterPack_AAA_BloodOnScreen f = _effectCam.GetComponent<CameraFilterPack_AAA_BloodOnScreen>();
		if (f == null)
		{
			f = _effectCam.gameObject.AddComponent<CameraFilterPack_AAA_BloodOnScreen>();
		}
		_filterList.Add(f);
		f.Blood_Distortion_Speed = 0f;
		f.Blood_On_Screen = blood_On_Screen;
		f.Blood_Color = new Color(0.5f, 0f, 0f, 1f);
		float e = 0f;
		while (e < 1f)
		{
			e += Time.deltaTime * 2f;
			f.Blood_Fade = (1f - e) * 0.5f;
			yield return null;
		}
		f.enabled = false;
		UnityEngine.Object.Destroy(f);
		_filterList.Remove(f);
	}

	public void VignetteCharacterCam(bool active)
	{
		PostProcessingBehaviour component = _characterCam.GetComponent<PostProcessingBehaviour>();
		if (_vignetteRoutine != null)
		{
			StopCoroutine(_vignetteRoutine);
			_vignetteRoutine = null;
		}
		_vignetteRoutine = StartCoroutine(VignetteRoutine(component, active));
		_characterCam.GetComponent<CameraFilterPack_AAA_Blood_Hit>().enabled = false;
	}

	private IEnumerator VignetteRoutine(PostProcessingBehaviour pp, bool active)
	{
		float e = 0f;
		float defaultVignetteIntensity = 0.725f;
		VignetteModel vignette = pp.profile.vignette;
		VignetteModel.Settings vignetteSetting = vignette.settings;
		float vignetteValue = vignetteSetting.intensity;
		while (e < 1f)
		{
			e += Time.deltaTime * 2.5f;
			if (active)
			{
				vignetteSetting.intensity = Mathf.Lerp(vignetteValue, defaultVignetteIntensity, e);
			}
			else
			{
				vignetteSetting.intensity = Mathf.Lerp(vignetteValue, 0f, e);
			}
			vignette.settings = vignetteSetting;
			yield return YieldCache.waitFrame;
		}
	}

	public void ChangeCharacterCamRGB(bool active)
	{
		_characterCam.GetComponent<CameraFilterPack_Color_RGB>().enabled = active;
	}

	public void ZoomAction(bool zoomIn, bool directly, float ratio = 0.75f)
	{
		if (directly)
		{
			if (_zoomRoutine != null)
			{
				StopCoroutine(_zoomRoutine);
				_zoomRoutine = null;
			}
			_bZoomAction = zoomIn;
			if (_bZoomAction)
			{
				_minOrthoSize = 13f * ratio;
			}
			else
			{
				_minOrthoSize = 13f;
			}
		}
		else if (zoomIn)
		{
			if (!_bZoomAction)
			{
				_zoomRoutine = StartCoroutine(ZoomActionRoutine(ratio));
			}
		}
		else
		{
			_bZoomAction = zoomIn;
		}
	}

	private IEnumerator ZoomActionRoutine(float ratio)
	{
		_bZoomAction = true;
		float defaultOrtho = _minOrthoSize;
		float value = (_minOrthoSize = defaultOrtho * ratio);
		yield return new WaitUntil(() => !_bZoomAction);
		float elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 5f;
			_minOrthoSize = Mathf.Lerp(value, defaultOrtho, elapsed);
			yield return YieldCache.waitFrame;
		}
		_minOrthoSize = defaultOrtho;
	}

	public void TiltCam(int sign, bool exitForcely = false)
	{
		if (exitForcely)
		{
			_mainCam.transform.localRotation = Quaternion.identity;
			isTiltingDone = true;
		}
		else
		{
			isTiltingDone = false;
			StartCoroutine(TiltRoutine(sign));
		}
	}

	private IEnumerator TiltRoutine(int sign)
	{
		float dstAngle = (float)sign * 2f;
		float elapsed = 0f;
		float speed = 6f;
		while (elapsed <= 1.1f)
		{
			elapsed += Time.deltaTime * speed;
			float t = _tiltCurve.Evaluate(elapsed) * 0.5f;
			float z = Mathf.LerpAngle(0f, dstAngle, t);
			_mainCam.transform.localRotation = Quaternion.Euler(0f, 0f, z);
			yield return YieldCache.waitFrame;
		}
		elapsed = 1f;
		while (elapsed > -0.1f)
		{
			elapsed -= Time.deltaTime * speed;
			float num = _tiltCurve.Evaluate(elapsed) * 0.5f;
			if (num < 0f)
			{
				num = 0f;
			}
			float z2 = Mathf.LerpAngle(0f, dstAngle, num);
			_mainCam.transform.localRotation = Quaternion.Euler(0f, 0f, z2);
			yield return YieldCache.waitFrame;
		}
		isTiltingDone = true;
	}

	public void OnRoundEnd()
	{
		VignetteCharacterCam(active: false);
		BlurCharacterCam(active: false);
		_bReadyRencounter = false;
		_firstRencounter = false;
		float currentBorderPos = SingletonBehavior<HexagonalMapManager>.Instance.GetCurrentBorderPos(HexagonalMapManager.WallDirection.RIGHT);
		float currentBorderPos2 = SingletonBehavior<HexagonalMapManager>.Instance.GetCurrentBorderPos(HexagonalMapManager.WallDirection.LEFT);
		_curStdOrtho = (currentBorderPos - currentBorderPos2) * 0.35f;
		_curStdPos = _stdCamPositions[3];
		resetCommand = false;
		_camRotator.UpdateBorder(_curStdOrtho * 0.804f, 30f);
		FollowOneUnit(null, b: false);
		if (focusRoutine != null)
		{
			StopCoroutine(focusRoutine);
			focusRoutine = null;
		}
		_returnRoutine = StartCoroutine(ReturnCam(_curStdPos, _curStdOrtho, 1f));
		_focusTargetList.Clear();
	}

	public IEnumerator ReturnCam()
	{
		_bCamIsReturning = true;
		ChangeCamProjection(isPerspective: false);
		float elapsed = 0f;
		Vector3 srcPos = base.transform.localPosition;
		float srcOrtho = _mainCam.orthographicSize;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 1f;
			base.transform.localPosition = Vector3.Lerp(srcPos, _curStdPos, _returnPosCurve.Evaluate(elapsed));
			_mainCam.orthographicSize = Mathf.Lerp(srcOrtho, _curStdOrtho, _returnOrthoCurve.Evaluate(elapsed));
			yield return YieldCache.waitFrame;
		}
		base.transform.localPosition = _curStdPos;
		_mainCam.orthographicSize = _curStdOrtho;
		_bCamIsReturning = false;
		ChangeCamMode(CamControlMode.MANUAL);
	}

	public void OnClickCharacter(BattleUnitModel unit)
	{
	}

	public void OnReleaseCharacter()
	{
	}

	public void OnClickCardInHand()
	{
	}

	public void OnReleaseCardInHand(BattleUnitModel unit)
	{
	}

	private void Awake()
	{
		ResetCamSetting();
	}

	private void OnEnable()
	{
		_minOrthoSize = 13f;
	}

	private void OnDisable()
	{
		_minOrthoSize = 13f;
	}

	private void FixedUpdate()
	{
		if (!_bCamIsReturning)
		{
			if (Input.GetMouseButton(2) && _camMode == CamControlMode.FOCUS && !SingletonBehavior<RencounterManager>.Instance.IsRunning)
			{
				_camMode = CamControlMode.MANUAL;
			}
			switch (_camMode)
			{
			case CamControlMode.MANUAL:
				UpdateManual();
				break;
			case CamControlMode.FOCUS:
				UpdateFocus(Time.fixedDeltaTime);
				break;
			}
		}
	}

	private void LateUpdate()
	{
		UpdateOtherCameras();
	}

	private void UpdateOtherCameras()
	{
		_characterCam.orthographicSize = _mainCam.orthographicSize;
		_characterUiCam.orthographicSize = _mainCam.orthographicSize;
		_uiCam.orthographicSize = _mainCam.orthographicSize;
		_effectCam.orthographicSize = _mainCam.orthographicSize;
		float minOrthoSize = _minOrthoSize;
		float num = (_mainCam.orthographicSize - minOrthoSize) / (_maxOrthoSize - minOrthoSize);
		float num2 = (_maxFov - _minFov) * num + _minFov;
		Camera component = _bgCamTransform.GetComponent<Camera>();
		if (_bReadyRencounter)
		{
			component.fieldOfView = Mathf.Lerp(component.fieldOfView, 17f, Time.deltaTime * 2.5f);
		}
		else
		{
			component.fieldOfView = Mathf.Lerp(component.fieldOfView, num2, Time.deltaTime * 2.5f);
		}
		_fgCamTransform.GetComponent<Camera>().fieldOfView = num2;
		Vector3 localPosition = _mainCam.transform.localPosition;
		_bgCamTransform.localPosition = localPosition;
		_fgCamTransform.localPosition = localPosition;
	}

	private void UpdateManual()
	{
		if (_bCamIsReturning || SingletonBehavior<BattleManagerUI>.Instance.ui_battleStory.isRunning)
		{
			return;
		}
		if (SingletonBehavior<BattleTutorialManagerUI>.Instance.IsRunningCreatureTutorial || SingletonBehavior<BattleTutorialManagerUI>.Instance.IsRunningTutorial)
		{
			_mainCam.orthographicSize = FIXED_TUTORIAL_ORTHOSIZE;
			return;
		}
		if (resetCommand)
		{
			_mainCam.orthographicSize = Mathf.Lerp(_mainCam.orthographicSize, _curStdOrtho, Time.deltaTime * 10f);
			if (Mathf.Abs(mainCam.orthographicSize - _curStdOrtho) < 1f)
			{
				resetCommand = false;
			}
		}
		float num = 0f;
		if (UIControlManager.isControllerInput)
		{
			num = -1f * Input.GetAxis("AxisVertical_RightStick") * 0.2f;
			if (Input.GetButtonDown("Button_RightStick"))
			{
				resetCommand = true;
				return;
			}
		}
		else
		{
			num = Input.GetAxis("Mouse ScrollWheel");
		}
		float value = _mainCam.orthographicSize - num * _manualCamZoomSpeed * (float)(scrollable ? 1 : 0);
		float num2 = 0f;
		if (UIControlManager.isControllerInput)
		{
			num2 = 20f;
		}
		value = Mathf.Clamp(value, _minOrthoSize, _curStdOrtho + num2);
		_mainCam.orthographicSize = Mathf.Lerp(_mainCam.orthographicSize, value, Time.deltaTime * 10f);
		Vector3 b = base.transform.localPosition;
		if (Input.GetMouseButton(2))
		{
			CursorManager.Instance?.OnCameraScroll();
			float x = 0f - Input.GetAxis("Mouse X");
			float y = 0f - Input.GetAxis("Mouse Y");
			Vector3 vector = new Vector3(x, y, 0f) * Time.deltaTime * _manualCamMoveSpeed;
			b = CheckBoundary(base.transform.localPosition + vector);
		}
		base.transform.localPosition = Vector3.Lerp(base.transform.localPosition, b, Time.deltaTime * 10f);
	}

	private void UpdateFocusPosition(float deltaTime)
	{
		if (!(focusOneUnitTarget == null) && stopFocusByRencounter)
		{
			Vector3 vector = focusOneUnitPosition - base.transform.position;
			float num = Vector3.Dot(_mainCam.transform.forward, vector.normalized);
			Vector3 vector2 = base.transform.forward * vector.magnitude * num;
			Vector3 vector3 = focusOneUnitPosition;
			Vector3 vector4 = base.transform.position + vector2;
			Vector3 vector5 = vector3 - vector4;
			Vector3 target = base.transform.position + vector5;
			float num2 = _focusOffsetY[0];
			switch (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.mapSize)
			{
			case MapSize.S:
				num2 = _focusOffsetY[0];
				break;
			case MapSize.M:
				num2 = _focusOffsetY[1];
				break;
			case MapSize.L:
				num2 = _focusOffsetY[2];
				break;
			}
			float num3 = focusOneUnitTarget.camRotationFollower.localScale.x;
			if (num3 < 1f)
			{
				num3 = 1f;
			}
			target += base.transform.up * num2 * num3;
			Vector3 currentVelocity = Vector3.zero;
			base.transform.position = Vector3.SmoothDamp(base.transform.position, target, ref currentVelocity, _smoothTime * _focusCamMoveSmoothTime * 0.5f, _maxSpeed);
			focusPos = target;
			float num4 = 1f;
			switch (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.mapSize)
			{
			case MapSize.S:
				num4 = 1.5f;
				break;
			case MapSize.M:
				num4 = 1.27f;
				break;
			case MapSize.L:
				num4 = 1f;
				break;
			}
			float num5 = _minOrthoSize * num4 * num3;
			if (num5 > _curStdOrtho)
			{
				num5 = _curStdOrtho;
			}
			float target2 = Mathf.Clamp(num5, num5, _curStdOrtho);
			float currentVelocity2 = 0f;
			_mainCam.orthographicSize = Mathf.SmoothDamp(_mainCam.orthographicSize, target2, ref currentVelocity2, _smoothTime, _maxSpeed);
			if (SingletonBehavior<RencounterManager>.Instance.IsRunning)
			{
				SetFov(focusOneUnitPosition, _mainCam.aspect);
			}
			base.transform.localPosition = CheckBoundary(base.transform.localPosition);
		}
	}

	private void UpdateFocus(float deltaTime)
	{
		if (stopFocusByRencounter)
		{
			UpdateFocusPosition(deltaTime);
		}
		else
		{
			if (_focusTargetList.Count == 0)
			{
				return;
			}
			float num = _focusTargetList[0].transform.position.x;
			float num2 = _focusTargetList[0].transform.position.x;
			float num3 = 1f;
			Vector3 vector = Vector3.zero;
			float num4 = 1f;
			if (_focusTargetList.Count == 1)
			{
				vector = _focusTargetList[0].transform.position;
			}
			else if (_focusTargetList.Count == 2)
			{
				BattleUnitModel model = _focusTargetList[0].model;
				BattleUnitModel model2 = _focusTargetList[1].model;
				foreach (BattleUnitView focusTarget in _focusTargetList)
				{
					Vector3 position = focusTarget.transform.position;
					if (position.x > num)
					{
						num = position.x;
					}
					if (position.x < num2)
					{
						num2 = position.x;
					}
				}
				if (model.moveDetail.isKnockback ^ model2.moveDetail.isKnockback)
				{
					num4 = 0.5f;
					if (model.moveDetail.isKnockback && !model.moveDetail.IsCollideWithWall)
					{
						vector = model.view.WorldPosition + (model.view.WorldPosition - model2.view.WorldPosition).normalized * 4f;
						_bFocusKnockback = true;
						_eee = 0f;
					}
					else if (model2.moveDetail.isKnockback && !model2.moveDetail.IsCollideWithWall)
					{
						vector = model2.view.WorldPosition + (model2.view.WorldPosition - model.view.WorldPosition).normalized * 4f;
						_bFocusKnockback = true;
						_eee = 0f;
					}
					else
					{
						vector = (model.view.WorldPosition + model2.view.WorldPosition) * 0.5f;
						_bFocusKnockback = false;
						if (!_bFocusKnockback)
						{
							_eee = 2f - Mathf.Clamp(_eee + deltaTime, 0f, 1f);
							num4 = _eee;
						}
					}
				}
				else
				{
					_bFocusKnockback = false;
					if (!_bFocusKnockback)
					{
						_eee = 2f - Mathf.Clamp(_eee + deltaTime, 0f, 1f);
						num4 = _eee;
					}
					vector = (model.view.WorldPosition + model2.view.WorldPosition) * 0.5f;
				}
				vector = (model.view.WorldPosition + model2.view.WorldPosition) * 0.5f;
				num3 = Mathf.Max(model.view.camRotationFollower.localScale.x, model2.view.camRotationFollower.localScale.x);
				if (num3 < 1f)
				{
					num3 = 1f;
				}
			}
			else if (_focusTargetList.Count > 2)
			{
				Vector3 zero = Vector3.zero;
				foreach (BattleUnitView focusTarget2 in _focusTargetList)
				{
					Vector3 position2 = focusTarget2.transform.position;
					zero += position2;
					if (position2.x > num)
					{
						num = position2.x;
					}
					if (position2.x < num2)
					{
						num2 = position2.x;
					}
				}
				vector = zero / _focusTargetList.Count;
				num += 3f;
				num2 -= 3f;
			}
			Vector3 vector2 = vector - base.transform.position;
			float num5 = Vector3.Dot(_mainCam.transform.forward, vector2.normalized);
			Vector3 vector3 = base.transform.forward * vector2.magnitude * num5;
			Vector3 vector4 = vector;
			Vector3 vector5 = base.transform.position + vector3;
			Vector3 vector6 = vector4 - vector5;
			Vector3 target = base.transform.position + vector6;
			float num6 = _focusOffsetY[0];
			if (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject != null)
			{
				switch (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.mapSize)
				{
				case MapSize.S:
					num6 = _focusOffsetY[0];
					break;
				case MapSize.M:
					num6 = _focusOffsetY[1];
					break;
				case MapSize.L:
					num6 = _focusOffsetY[2];
					break;
				}
			}
			target += base.transform.up * num6 * num3;
			Vector3 currentVelocity = Vector3.zero;
			base.transform.position = Vector3.SmoothDamp(base.transform.position, target, ref currentVelocity, _smoothTime * num4 * _focusCamMoveSmoothTime, _maxSpeed);
			focusPos = target;
			float value = (num - num2) * 0.5625f;
			float num7 = 1f;
			if (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject != null)
			{
				switch (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.mapSize)
				{
				case MapSize.S:
					num7 = 1.5f;
					break;
				case MapSize.M:
					num7 = 1.27f;
					break;
				case MapSize.L:
					num7 = 1f;
					break;
				}
			}
			float num8 = _minOrthoSize * num7 * num3 * _focusZoomFactor;
			if (num8 > _curStdOrtho)
			{
				num8 = _curStdOrtho;
			}
			value = Mathf.Clamp(value, num8, _curStdOrtho);
			float currentVelocity2 = 0f;
			_mainCam.orthographicSize = Mathf.SmoothDamp(_mainCam.orthographicSize, value, ref currentVelocity2, _smoothTime * num4, _maxSpeed);
			if (SingletonBehavior<RencounterManager>.Instance.IsRunning)
			{
				SetFov(vector, _mainCam.aspect);
			}
			base.transform.localPosition = CheckBoundary(base.transform.localPosition);
		}
	}

	public void SetFocusZoomFaction(float t)
	{
		_focusZoomFactor = t;
	}

	public bool IsCamFarFromFocusUnit()
	{
		return Vector3.Distance(base.transform.position, focusPos) > 5f;
	}

	private void SetFov(Vector3 stdPos, float aspect)
	{
		float num = Vector3.Distance(stdPos, _mainCam.transform.position);
		float fieldOfView = Mathf.Atan(_mainCam.orthographicSize / num) * 2f / ((float)Math.PI / 180f);
		_mainCam.fieldOfView = fieldOfView;
		_characterCam.fieldOfView = fieldOfView;
		_characterUiCam.fieldOfView = fieldOfView;
		_uiCam.fieldOfView = fieldOfView;
		_effectCam.fieldOfView = fieldOfView;
	}

	private Vector3 CheckBoundary(Vector3 pos)
	{
		float x = SingletonBehavior<HexagonalMapManager>.Instance.CenterPos.x;
		float max = _curStdPos.x + _curStdOrtho * 1.78f + 5f + x;
		float min = _curStdPos.x - _curStdOrtho * 1.78f - 5f + x;
		float max2 = _curStdPos.y + _curStdOrtho + 3f;
		float min2 = _curStdPos.y - _curStdOrtho - 3f;
		Vector3 result = pos;
		result.x = Mathf.Clamp(result.x, min, max);
		result.y = Mathf.Clamp(result.y, min2, max2);
		return result;
	}

	private IEnumerator ReturnCam(Vector3 dstPos, float dstOrtho, float speed)
	{
		_bCamIsReturning = true;
		ChangeCamProjection(isPerspective: false);
		float elapsed = 0f;
		Vector3 srcPos = base.transform.localPosition;
		float srcOrtho = _mainCam.orthographicSize;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * speed;
			base.transform.localPosition = Vector3.Lerp(srcPos, dstPos, _returnPosCurve.Evaluate(elapsed));
			_mainCam.orthographicSize = Mathf.Lerp(srcOrtho, dstOrtho, _returnOrthoCurve.Evaluate(elapsed));
			yield return YieldCache.waitFrame;
		}
		base.transform.localPosition = dstPos;
		_mainCam.orthographicSize = dstOrtho;
		_bCamIsReturning = false;
		ChangeCamMode(CamControlMode.MANUAL);
	}

	private IEnumerator VibeCam(CameraFilterPack_FX_EarthQuake filter, float speed, Vector2 xy)
	{
		_isShaking = true;
		if (!_defaultCamFilters.Exists((MonoBehaviour monoBehaviour) => monoBehaviour == filter))
		{
			_defaultCamFilters.Add(filter);
		}
		if (filter != null)
		{
			float s = filter.Speed;
			float x = filter.X;
			float y = filter.Y;
			filter.Speed = speed;
			filter.X = xy.x;
			filter.Y = xy.y;
			filter.enabled = true;
			yield return YieldCache.WaitForSeconds(0.25f);
			filter.enabled = false;
			filter.Speed = s;
			filter.X = x;
			filter.Y = y;
			_isShaking = false;
		}
		else
		{
			yield return null;
		}
	}

	private void DEBUG_RoundEnd(int i)
	{
	}
}
