using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UI;
using UnityEngine;
using UnityEngine.UI;

namespace BattleCharacterProfile;

public class BattleCharacterProfileUI : MonoBehaviour
{
	[Serializable]
	public class HpBar
	{
		public Image img;

		public _2dxFX_HSV hsv;
	}

	public delegate void OnAcquireEnd();

	[Header("Reference")]
	[SerializeField]
	private Transform uiRoot;

	[SerializeField]
	private Image img_bg;

	[SerializeField]
	private BattleUnitProfileInfoUI_EmotionLvTooltip _emotionLvTooltip;

	[Space]
	[Header("Appearance")]
	[SerializeField]
	private RawImage rawImg_portrait;

	[SerializeField]
	private TextMeshProUGUI txt_unitName;

	[Space]
	[Header("HP")]
	[SerializeField]
	private GameObject go_hpValueLayout;

	[SerializeField]
	private GameObject go_emotionLVPivot;

	[SerializeField]
	private HpBar hpBar;

	[SerializeField]
	private HpBar img_damagedHp;

	[SerializeField]
	private HpBar img_healedHp;

	[SerializeField]
	private NumbersData nd_hpNumbers;

	[SerializeField]
	private Text txt_hp;

	[Space]
	[Header("Emotion")]
	[SerializeField]
	private List<Image> img_emotionCoinList;

	[SerializeField]
	private BattleCharacterProfileUI_CoinManager coinUI;

	[SerializeField]
	private BattleCharacterProfileEmotionUI emotionUI;

	[Space]
	[SerializeField]
	private Color _colorDialogBG_New;

	[SerializeField]
	private CanvasGroup _battleDialogCanvasGroup;

	[SerializeField]
	private TextMeshProUGUI _battleDialog;

	[SerializeField]
	private Image _battleDialogBG;

	[SerializeField]
	private Image _battleDialogNewBG;

	[SerializeField]
	private Image _battleDialogChildImg;

	[SerializeField]
	private Image _battleDialogLinearDodge;

	private bool isExited;

	public bool isLeft;

	private int emotionLV_Prev;

	private BattleUnitInformationUI playerinfo;

	private BattleUnitInformationUI enemyinfo;

	private BattleUnitModel _unitModel;

	private bool _grayScaled;

	private float _curHp;

	private Coroutine displayDlgRoutine;

	private Coroutine hideDlgWithDelayRoutine;

	private bool _bDlgIsAbnormality;

	private MentalState _bAbnormalityState;

	private Coroutine clickableRoutine;

	private float _emotion_elap;

	private float _emotion_duration = 0.3f;

	private bool _isAcquireProcess;

	private OnAcquireEnd _onAcquireEnd;

	private int _negativeIndex;

	private int _positiveIndex;

	public BattleUnitModel UnitModel => _unitModel;

	public float CurHp => _curHp;

	private void Awake()
	{
		Initialize();
	}

	public void OnPointerEnter()
	{
		if (SingletonBehavior<RencounterManager>.Instance.IsRunning)
		{
			return;
		}
		uiRoot.localScale = Vector3.one * 1.2f;
		if (!(playerinfo == null) && !(enemyinfo == null))
		{
			if (UnitModel.faction == Faction.Player)
			{
				playerinfo.OpenUnitInformationByCharacter(_unitModel, charclicked: false);
			}
			else
			{
				enemyinfo.OpenUnitInformationByCharacter(_unitModel, charclicked: false);
			}
			SingletonBehavior<BattleSoundManager>.Instance.PlaySound(EffectSoundType.DICE_ROLL);
		}
	}

	public void OnPointerExit()
	{
		if (SingletonBehavior<RencounterManager>.Instance.IsRunning)
		{
			return;
		}
		uiRoot.localScale = Vector3.one;
		if (!(playerinfo == null) && !(enemyinfo == null))
		{
			if (UnitModel.faction == Faction.Player)
			{
				playerinfo.CloseUnitInformation(forcehide: false);
			}
			else
			{
				enemyinfo.CloseUnitInformation(forcehide: false);
			}
		}
	}

	public void OnPointerUp()
	{
		OnClick(byPad: false);
	}

	public void OnClick(bool byPad)
	{
		if (SingletonBehavior<RencounterManager>.Instance.IsRunning)
		{
			return;
		}
		uiRoot.localScale = Vector3.one;
		if (playerinfo == null || enemyinfo == null)
		{
			return;
		}
		if (_unitModel.faction == Faction.Player)
		{
			if (!byPad)
			{
				enemyinfo.ReleaseSelectedCharacter();
				playerinfo.ReleaseSelectedDice();
			}
			playerinfo.OpenUnitInformationByCharacter(_unitModel, charclicked: true);
			if (byPad)
			{
				playerinfo.SetFocus();
			}
		}
		else
		{
			if (!byPad)
			{
				playerinfo.ReleaseSelectedCharacter();
				enemyinfo.ReleaseSelectedDice();
			}
			enemyinfo.OpenUnitInformationByCharacter(_unitModel, charclicked: true);
			if (byPad)
			{
				enemyinfo.SetFocus();
			}
			if (SingletonBehavior<BattleTutorialManagerUI>.Instance.IsRunningCreatureTutorial && _unitModel != null && _unitModel.UnitData.unitData.EnemyUnitId == SingletonBehavior<BattleTutorialManagerUI>.Instance.BloodBathEnemyID && SingletonBehavior<BattleTutorialManagerUI>.Instance.onSelectEnemyFuncForCreatureTutorial != null)
			{
				SingletonBehavior<BattleTutorialManagerUI>.Instance.onSelectEnemyFuncForCreatureTutorial();
			}
		}
		Select(b: true);
	}

	public void Select(bool b)
	{
		img_bg.enabled = b;
		_unitModel.view.unitBottomStatUI.SetClicked(b);
	}

	public void Initialize()
	{
		StopAllCoroutines();
		if (_grayScaled)
		{
			SetGrayscale(b: false);
		}
		Color color = img_damagedHp.img.color;
		color.a = 0f;
		img_damagedHp.img.color = color;
		color = img_healedHp.img.color;
		color.a = 0f;
		img_healedHp.img.color = color;
		_battleDialogCanvasGroup.alpha = 0f;
		_emotionLvTooltip.Initialize(this);
		SetDefaultCoinImgScale();
	}

	public void SetUnitModel(BattleUnitModel unitModel)
	{
		_unitModel = unitModel;
		rawImg_portrait.texture = SingletonBehavior<UICharacterRenderer>.Instance.GetRenderTextureByIndex(unitModel.UnitData.TextureIndex);
		txt_unitName.text = _unitModel.UnitData.unitData.name;
		_curHp = unitModel.hp;
		if (isLeft)
		{
			Vector3 localScale = base.transform.localScale;
			localScale.x = Mathf.Abs(localScale.x) * -1f;
			base.transform.localScale = localScale;
			localScale = go_emotionLVPivot.gameObject.transform.localScale;
			localScale.x = Mathf.Abs(localScale.x) * -1f;
			go_emotionLVPivot.gameObject.transform.localScale = localScale;
			localScale = txt_unitName.transform.localScale;
			localScale.x = Mathf.Abs(localScale.x) * -1f;
			txt_unitName.transform.localScale = localScale;
			localScale = go_hpValueLayout.transform.localScale;
			localScale.x = Mathf.Abs(localScale.x) * -1f;
			go_hpValueLayout.transform.localScale = localScale;
			localScale = _battleDialog.transform.localScale;
			localScale.x = Mathf.Abs(localScale.x) * -1f;
			_battleDialog.transform.localScale = localScale;
		}
		SetHpUI(UnitModel.hp);
		UpdateEmotionCoinList();
		InitEmotionCoin();
		emotionUI.Init(UnitModel.emotionDetail.EmotionLevel);
		if (isLeft)
		{
			playerinfo = ((UnitModel.faction == Faction.Player) ? SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation : SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformationPlayer);
			enemyinfo = ((UnitModel.faction == Faction.Player) ? SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformationPlayer : SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation);
		}
		else
		{
			playerinfo = ((UnitModel.faction == Faction.Player) ? SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformationPlayer : SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation);
			enemyinfo = ((UnitModel.faction == Faction.Player) ? SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation : SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformationPlayer);
		}
	}

	public void DisplayDlg(string str, bool isAbnormality, MentalState state)
	{
		_bDlgIsAbnormality = isAbnormality;
		_bAbnormalityState = state;
		if (displayDlgRoutine != null)
		{
			StopCoroutine(displayDlgRoutine);
			displayDlgRoutine = null;
		}
		if (hideDlgWithDelayRoutine != null)
		{
			StopCoroutine(hideDlgWithDelayRoutine);
			hideDlgWithDelayRoutine = null;
		}
		displayDlgRoutine = StartCoroutine(DisplayRoutine(show: true, isAbnormality, state));
		_battleDialog.text = str;
		if (isAbnormality)
		{
			_battleDialog.gameObject.AddComponent<AbnormalityDlgEffect>().Init();
			return;
		}
		AbnormalityDlgEffect component = _battleDialog.GetComponent<AbnormalityDlgEffect>();
		if (component != null)
		{
			UnityEngine.Object.Destroy(component);
		}
	}

	public void OnClickDlgArea()
	{
		if (!(_battleDialogCanvasGroup.alpha < 0.1f))
		{
			if (displayDlgRoutine != null)
			{
				StopCoroutine(displayDlgRoutine);
				displayDlgRoutine = null;
			}
			displayDlgRoutine = StartCoroutine(DisplayRoutine(show: false, _bDlgIsAbnormality, _bAbnormalityState));
		}
	}

	public void CloseDlgWithDelay()
	{
		if (base.gameObject.activeInHierarchy)
		{
			if (hideDlgWithDelayRoutine != null)
			{
				StopCoroutine(hideDlgWithDelayRoutine);
				hideDlgWithDelayRoutine = null;
			}
			hideDlgWithDelayRoutine = StartCoroutine(HideRoutineWithDelay(2));
		}
	}

	private IEnumerator HideRoutineWithDelay(int delay = 0)
	{
		yield return new WaitForSeconds(delay);
		hideDlgWithDelayRoutine = null;
		OnClickDlgArea();
	}

	private IEnumerator DisplayRoutine(bool show, bool isAbnormality, MentalState state)
	{
		float e = 0f;
		float a = _battleDialogCanvasGroup.alpha;
		isExited = false;
		Color color = _battleDialogChildImg.color;
		color.a = 0.5f;
		_battleDialogChildImg.color = color;
		_battleDialog.color = Color.black;
		_battleDialog.fontMaterial.SetFloat(ShaderUtilities.ID_FaceDilate, 0.1f);
		if (isAbnormality)
		{
			_ = Color.white;
			Color value = ((state != MentalState.Positive) ? SingletonBehavior<BattleManagerUI>.Instance.negativeCoinColor : SingletonBehavior<BattleManagerUI>.Instance.positiveCoinColor);
			value.a = 0.9f;
			_battleDialog.fontMaterial.SetColor(ShaderUtilities.ID_UnderlayColor, value);
		}
		else
		{
			Color color2 = _battleDialog.color;
			color2.a = 0.9f;
			_battleDialog.fontMaterial.SetColor(ShaderUtilities.ID_UnderlayColor, color2);
		}
		_battleDialog.fontMaterial.SetFloat(ShaderUtilities.ID_UnderlayDilate, 0f);
		_battleDialog.fontMaterial.SetFloat(ShaderUtilities.ID_UnderlaySoftness, 0.8f);
		_battleDialogNewBG.enabled = true;
		_battleDialogNewBG.color = _colorDialogBG_New * (_grayScaled ? 0.25f : 1f);
		_battleDialogLinearDodge.enabled = true;
		while (e < 1f)
		{
			e += Time.deltaTime * 2f;
			_battleDialogCanvasGroup.alpha = Mathf.Lerp(a, show ? 1 : 0, e);
			color = _battleDialogChildImg.color;
			color.a = Mathf.Lerp(0.5f, 0f, e);
			_battleDialogChildImg.color = color;
			yield return null;
		}
	}

	public void OnEnterDlgArea()
	{
		if (clickableRoutine != null)
		{
			StopCoroutine(clickableRoutine);
			clickableRoutine = null;
		}
		Color color = Color.white;
		_battleDialog.fontMaterial.SetFloat(ShaderUtilities.ID_FaceDilate, 0f);
		if (_bDlgIsAbnormality)
		{
			Color white = Color.white;
			if (_bAbnormalityState == MentalState.Positive)
			{
				color = SingletonBehavior<BattleManagerUI>.Instance.positiveTextColor;
				white = SingletonBehavior<BattleManagerUI>.Instance.positiveCoinColor * (_grayScaled ? 0.25f : 1f);
			}
			else
			{
				color = SingletonBehavior<BattleManagerUI>.Instance.negativeTextColor;
				white = SingletonBehavior<BattleManagerUI>.Instance.negativeCoinColor * (_grayScaled ? 0.25f : 1f);
			}
			white.a = 0.5f;
			_battleDialog.fontMaterial.SetColor(ShaderUtilities.ID_UnderlayColor, white);
		}
		else
		{
			ColorUtility.TryParseHtmlString("#EFC281", out color);
			Color value = _colorDialogBG_New * (_grayScaled ? 0.25f : 1f);
			value.a = 0.5f;
			_battleDialog.fontMaterial.SetColor(ShaderUtilities.ID_UnderlayColor, value);
		}
		_battleDialog.color = color;
		_battleDialog.fontMaterial.SetFloat(ShaderUtilities.ID_UnderlayDilate, 0.2f);
		_battleDialog.fontMaterial.SetFloat(ShaderUtilities.ID_UnderlaySoftness, 0.8f);
		if (_battleDialogNewBG.enabled)
		{
			StartCoroutine(EnterRoutine());
		}
		_battleDialogLinearDodge.enabled = false;
		clickableRoutine = StartCoroutine(ClickableEffectRoutine());
	}

	private IEnumerator EnterRoutine()
	{
		float elapsed = 0f;
		Color c = _battleDialogNewBG.color;
		float alpha = c.a;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 5f;
			c.a = Mathf.Lerp(alpha, 0f, elapsed);
			_battleDialogNewBG.color = c;
			yield return null;
		}
		_battleDialogNewBG.enabled = false;
	}

	public void OnExitDlgArea()
	{
		if (clickableRoutine != null)
		{
			StopCoroutine(clickableRoutine);
			clickableRoutine = null;
		}
		Image component = _battleDialogCanvasGroup.GetComponent<Image>();
		Color color = component.color;
		color.a = 0.85f;
		component.color = color;
		OnClickDlgArea();
	}

	private IEnumerator ClickableEffectRoutine()
	{
		isExited = false;
		Image img = _battleDialogCanvasGroup.GetComponent<Image>();
		Color c = img.color;
		while (true)
		{
			c.a = 0.85f - Mathf.PingPong(TimeManager.GetUITime(), 0.35f);
			img.color = c;
			yield return null;
		}
	}

	public void SetStatNumberEnable(bool enable)
	{
		txt_hp.enabled = enable;
	}

	public void SetHpUI(float newHp)
	{
		if (newHp > _curHp)
		{
			StartCoroutine(UpdateHpBar(hpBar, img_healedHp, _curHp, newHp, img_healedHp));
		}
		else
		{
			StartCoroutine(UpdateHpBar(img_damagedHp, hpBar, _curHp, newHp, img_damagedHp));
		}
		StartCoroutine(UpdateHpNum(_curHp, newHp));
	}

	private IEnumerator UpdateHpBar(HpBar src, HpBar dst, float curHp, float newHp, HpBar bar)
	{
		Color c = bar.img.color;
		c.a = 1f;
		bar.img.color = c;
		float t = newHp / (float)_unitModel.MaxHp;
		float x = Mathf.Lerp(-550f, 0f, t);
		Vector3 dstPos = dst.img.transform.localPosition;
		dstPos.x = x;
		dst.img.transform.localPosition = dstPos;
		float e = 0f;
		Vector3 srcPos = src.img.transform.localPosition;
		while (e < 1f)
		{
			e += Time.deltaTime;
			src.img.transform.localPosition = Vector3.Lerp(srcPos, dstPos, e);
			c.a = 1f - e;
			bar.img.color = c;
			yield return YieldCache.waitFrame;
		}
		c.a = 0f;
		bar.img.color = c;
	}

	private IEnumerator UpdateHpNum(float curHP, float newHP)
	{
		float e = 0f;
		while (e < 1f)
		{
			e += Time.deltaTime;
			float num = Mathf.Lerp(curHP, newHP, e);
			txt_hp.text = ((int)num).ToString();
			yield return YieldCache.waitFrame;
		}
		_curHp = newHP;
		if (_curHp <= 0f)
		{
			SetGrayscale(b: true);
		}
		else
		{
			SetGrayscale(b: false);
		}
	}

	private void Update()
	{
		if (_unitModel != null && !_grayScaled && emotionLV_Prev != _unitModel.emotionDetail.EmotionLevel)
		{
			emotionUI.UpdateEmotion(_unitModel.emotionDetail.EmotionLevel);
			emotionLV_Prev = _unitModel.emotionDetail.EmotionLevel;
		}
		_battleDialogCanvasGroup.blocksRaycasts = _battleDialogCanvasGroup.alpha > 0f;
		_battleDialogCanvasGroup.interactable = _battleDialogCanvasGroup.alpha > 0f;
	}

	private void OnEnable()
	{
		_emotionLvTooltip.OnPointerExit(null);
	}

	private void OnDisable()
	{
		StopAllCoroutines();
		_emotionLvTooltip.OnPointerExit(null);
	}

	public void SetAcquireProcess(bool state)
	{
		_isAcquireProcess = state;
	}

	public IEnumerator AcquireCoroutine(Image targetImage)
	{
		float sizeFactor = 3f;
		float defaultSize = 1f;
		_emotion_elap = 0f;
		Vector3 initialSize = targetImage.rectTransform.localScale;
		do
		{
			_emotion_elap += Time.deltaTime;
			float t = _emotion_elap / _emotion_duration;
			float num = Mathf.Lerp(sizeFactor, defaultSize, t);
			targetImage.rectTransform.localScale = initialSize * num;
			yield return new WaitForFixedUpdate();
		}
		while (_emotion_elap < _emotion_duration);
		_isAcquireProcess = false;
	}

	public void InitEmotionCoin()
	{
		coinUI.Init(_unitModel);
		coinUI.UpdateCoins(_unitModel);
		_negativeIndex = UnitModel.emotionDetail.NegativeCoins.Count;
		_positiveIndex = UnitModel.emotionDetail.PositiveCoins.Count;
	}

	public void OnAcquireCoin(bool isPositive, int emotionLevel)
	{
		if (emotionLevel != _unitModel.emotionDetail.EmotionLevel || _unitModel.emotionDetail.EmotionLevel >= _unitModel.emotionDetail.MaximumEmotionLevel)
		{
			return;
		}
		Image image = null;
		if (isPositive)
		{
			if (_positiveIndex + 1 > _unitModel.emotionDetail.PositiveCoins.Count)
			{
				return;
			}
			_positiveIndex++;
		}
		else
		{
			if (_negativeIndex + 1 > _unitModel.emotionDetail.NegativeCoins.Count)
			{
				return;
			}
			_negativeIndex++;
		}
		image = coinUI.OnAcquireCoin(isPositive, _negativeIndex, _positiveIndex);
		if ((bool)image)
		{
			StartCoroutine(AcquireCoroutine(image));
		}
	}

	public void UpdateEmotionCoinList()
	{
		coinUI.UpdateCoins(UnitModel);
	}

	private void SetGrayscale(bool b)
	{
		if (_grayScaled == b)
		{
			return;
		}
		_grayScaled = b;
		Image[] componentsInChildren = base.transform.GetComponentsInChildren<Image>(includeInactive: true);
		foreach (Image image in componentsInChildren)
		{
			if (!(image == _battleDialogBG) && !(image.transform.parent == _battleDialogBG.transform))
			{
				Color color = image.color;
				float a = color.a;
				color *= (_grayScaled ? 0.25f : 4f);
				color.a = a;
				image.color = color;
			}
		}
		RawImage[] componentsInChildren2 = base.transform.GetComponentsInChildren<RawImage>(includeInactive: true);
		foreach (RawImage obj in componentsInChildren2)
		{
			Color color2 = obj.color;
			float a2 = color2.a;
			color2 *= (_grayScaled ? 0.25f : 4f);
			color2.a = a2;
			obj.color = color2;
		}
		emotionUI.SetGrayScaleColor(_grayScaled);
		Color color3 = txt_unitName.color;
		color3 *= (_grayScaled ? 0.25f : 4f);
		color3.a = 1f;
		txt_unitName.color = color3;
		Color value = txt_unitName.fontMaterial.GetColor(ShaderUtilities.ID_UnderlayColor) * (_grayScaled ? 0.25f : 1f);
		value.a = 1f;
		txt_unitName.fontMaterial.SetColor(ShaderUtilities.ID_UnderlayColor, value);
	}

	private List<Image> GetChildRecursiveList(Transform t)
	{
		Image[] componentsInChildren = t.GetComponentsInChildren<Image>(includeInactive: true);
		List<Image> list = new List<Image>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			list.Add(componentsInChildren[i]);
		}
		return list;
	}

	public void SetDefaultCoinImgScale()
	{
		coinUI.SetDefaultCoinScale();
	}
}
