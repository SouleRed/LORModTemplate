using UnityEngine;
using UnityEngine.UI;

namespace BattleCharacterProfile;

public class EmotionCoin : MonoBehaviour
{
	public Image img_coin;

	private Color _positiveColor = new Color(0.2901961f, 0.9960785f, 0.7882354f, 1f);

	public void SetCoin(EmotionCoinType coinType)
	{
		switch (coinType)
		{
		case EmotionCoinType.Positive:
			img_coin.color = _positiveColor;
			break;
		case EmotionCoinType.Negative:
			img_coin.color = Color.red;
			break;
		}
	}
}
