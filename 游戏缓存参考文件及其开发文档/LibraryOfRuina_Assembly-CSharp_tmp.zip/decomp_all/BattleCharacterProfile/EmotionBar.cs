using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace BattleCharacterProfile;

public class EmotionBar : MonoBehaviour
{
	[SerializeField]
	private int level;

	[SerializeField]
	private List<EmotionCoin> emotionCoins;

	[SerializeField]
	private Image img_Frame;

	[SerializeField]
	private Image img_Bg;

	private BattleUnitModel _unitModel;

	public void SetUnitModel(BattleUnitModel unitModel)
	{
		_unitModel = unitModel;
	}

	private void Start()
	{
	}

	private void Update()
	{
		if (_unitModel == null || _unitModel.IsDead() || _unitModel.emotionDetail.EmotionLevel != level)
		{
			return;
		}
		IList<global::EmotionCoin> allEmotionCoins = _unitModel.emotionDetail.AllEmotionCoins;
		for (int i = 0; i < emotionCoins.Count; i++)
		{
			if (i < allEmotionCoins.Count)
			{
				emotionCoins[i].img_coin.enabled = true;
				emotionCoins[i].SetCoin(allEmotionCoins[i].CoinType);
			}
			else
			{
				emotionCoins[i].img_coin.enabled = false;
			}
		}
	}
}
