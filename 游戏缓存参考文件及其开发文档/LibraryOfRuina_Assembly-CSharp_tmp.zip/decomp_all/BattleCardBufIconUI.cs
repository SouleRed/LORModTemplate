using UnityEngine;

public class BattleCardBufIconUI : MonoBehaviour
{
	public BattlePlayingCardDataInUnitModel model;

	public void Init(BattlePlayingCardDataInUnitModel model)
	{
		this.model = model;
	}
}
