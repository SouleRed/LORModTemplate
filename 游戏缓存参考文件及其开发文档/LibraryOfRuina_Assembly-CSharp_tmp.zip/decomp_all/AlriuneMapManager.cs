using UnityEngine;

public class AlriuneMapManager : CreatureMapManager
{
	[SerializeField]
	private GameObject _windEffect;

	[SerializeField]
	private GameObject _windLoopEffect;

	[SerializeField]
	private GameObject _windStrongLoopEffect;

	private const int _defaultDlgNum = 5;

	private const int _specialDlg1Num = 3;

	private const int _bossDlgNum = 9;

	private bool super;

	private CreatureEffect_Alriune_Curtain _curtain;

	protected CreatureEffect_Alriune_Curtain Curtain
	{
		get
		{
			if (_curtain == null)
			{
				_curtain = SingletonBehavior<BattleManagerUI>.Instance.EffectLayer.GetComponentInChildren<CreatureEffect_Alriune_Curtain>();
			}
			return _curtain;
		}
	}

	public override void InitializeMap()
	{
		base.InitializeMap();
		_creatureDlgIdList.Add("Alriune_nomal_1");
		_creatureDlgIdList.Add("Alriune_nomal_2");
		_creatureDlgIdList.Add("Alriune_nomal_3");
		_creatureDlgIdList.Add("Alriune_nomal_4");
		_creatureDlgIdList.Add("Alriune_nomal_5");
		_creatureDlgIdList.Add("Alriune_attack_1");
		_creatureDlgIdList.Add("Alriune_attack_2");
		_creatureDlgIdList.Add("Alriune_attack_3");
		CreateDialog();
	}

	public override void ChangeDlgByBoss()
	{
		base.ChangeDlgByBoss();
		_creatureDlgIdList.Add("N_Angela_Alriune_1");
		_creatureDlgIdList.Add("N_Angela_Alriune_2");
		_creatureDlgIdList.Add("N_Angela_Alriune_3");
		_creatureDlgIdList.Add("N_Angela_Alriune_4");
		_creatureDlgIdList.Add("N_Angela_Alriune_5");
		_creatureDlgIdList.Add("N_Angela_Alriune_6");
		_creatureDlgIdList.Add("N_Angela_Alriune_7");
		_creatureDlgIdList.Add("N_Angela_Alriune_8");
		_creatureDlgIdList.Add("N_Angela_Alriune_9");
		CreateDialog();
	}

	public override void CreateDialog()
	{
		if (isBossPhase)
		{
			_dlgIdx %= 9;
		}
		else if (!super)
		{
			_dlgIdx = Random.Range(0, 5);
		}
		else
		{
			_dlgIdx = Random.Range(0, 3) + 5;
		}
		base.CreateDialog();
	}

	public override void OnRoundEnd()
	{
		base.OnRoundEnd();
		super = false;
	}

	public void Super()
	{
		super = true;
	}

	public void WindOnce()
	{
		GameObject obj = Object.Instantiate(_windEffect);
		obj.SetActive(value: true);
		obj.AddComponent<AutoDestruct>().time = 5f;
	}

	public void WindOn()
	{
		ParticleSystem[] componentsInChildren = _windLoopEffect.GetComponentsInChildren<ParticleSystem>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			ParticleSystem.EmissionModule emission = componentsInChildren[i].emission;
			emission.enabled = true;
		}
	}

	public void WindStrong()
	{
		ParticleSystem[] componentsInChildren = _windLoopEffect.GetComponentsInChildren<ParticleSystem>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			ParticleSystem.EmissionModule emission = componentsInChildren[i].emission;
			emission.enabled = false;
		}
		componentsInChildren = _windStrongLoopEffect.GetComponentsInChildren<ParticleSystem>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			ParticleSystem.EmissionModule emission2 = componentsInChildren[i].emission;
			emission2.enabled = true;
		}
	}

	public void WindOff()
	{
		ParticleSystem[] componentsInChildren = _windLoopEffect.GetComponentsInChildren<ParticleSystem>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			ParticleSystem.EmissionModule emission = componentsInChildren[i].emission;
			emission.enabled = false;
		}
		componentsInChildren = _windStrongLoopEffect.GetComponentsInChildren<ParticleSystem>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			ParticleSystem.EmissionModule emission2 = componentsInChildren[i].emission;
			emission2.enabled = false;
		}
	}

	protected override void OnDestroy()
	{
		Curtain?.ManualDestroy();
		base.OnDestroy();
	}

	private void OnDisable()
	{
		Curtain?.ManualDestroy();
	}
}
