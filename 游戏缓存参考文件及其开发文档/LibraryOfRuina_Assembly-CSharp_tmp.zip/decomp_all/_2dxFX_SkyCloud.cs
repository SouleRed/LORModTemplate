using System;
using UnityEngine;
using UnityEngine.UI;

[Serializable]
[ExecuteInEditMode]
[AddComponentMenu("2DxFX/Standard/SkyCloud")]
public class _2dxFX_SkyCloud : MonoBehaviour
{
	[HideInInspector]
	public Material ForceMaterial;

	[HideInInspector]
	public bool ActiveChange = true;

	private string shader = "2DxFX/Standard/SkyCloud";

	[HideInInspector]
	[Range(0f, 1f)]
	public float _Alpha = 1f;

	[HideInInspector]
	public Texture2D __MainTex2;

	[HideInInspector]
	public float _OffsetX;

	[HideInInspector]
	public float _OffsetY;

	[HideInInspector]
	[Range(0.1f, 2f)]
	public float _Zoom = 0.2f;

	[HideInInspector]
	[Range(-1f, 1f)]
	public float _Intensity = 0.3f;

	[HideInInspector]
	public bool _AutoScrollX;

	[HideInInspector]
	[Range(-2f, 2f)]
	public float _AutoScrollSpeedX = 0.08f;

	[HideInInspector]
	public bool _AutoScrollY;

	[HideInInspector]
	[Range(-2f, 2f)]
	public float _AutoScrollSpeedY = 0.02f;

	[HideInInspector]
	private float _AutoScrollCountX;

	[HideInInspector]
	private float _AutoScrollCountY;

	[HideInInspector]
	public int ShaderChange;

	private Material tempMaterial;

	private Material defaultMaterial;

	private Image CanvasImage;

	private SpriteRenderer CanvasSpriteRenderer;

	[HideInInspector]
	public bool ActiveUpdate = true;

	private void Awake()
	{
		if (base.gameObject.GetComponent<Image>() != null)
		{
			CanvasImage = base.gameObject.GetComponent<Image>();
		}
		if (base.gameObject.GetComponent<SpriteRenderer>() != null)
		{
			CanvasSpriteRenderer = base.gameObject.GetComponent<SpriteRenderer>();
		}
	}

	private void Start()
	{
		__MainTex2 = Resources.Load("_2dxFX_ShadowTXT") as Texture2D;
		ShaderChange = 0;
		if (CanvasSpriteRenderer != null)
		{
			CanvasSpriteRenderer.sharedMaterial.SetTexture("_MainTex2", __MainTex2);
		}
		else if (CanvasImage != null)
		{
			CanvasImage.material.SetTexture("_MainTex2", __MainTex2);
		}
		XUpdate();
	}

	public void CallUpdate()
	{
		XUpdate();
	}

	private void Update()
	{
		if (ActiveUpdate)
		{
			XUpdate();
		}
	}

	private void XUpdate()
	{
		if (CanvasImage == null && base.gameObject.GetComponent<Image>() != null)
		{
			CanvasImage = base.gameObject.GetComponent<Image>();
		}
		if (CanvasSpriteRenderer == null && base.gameObject.GetComponent<SpriteRenderer>() != null)
		{
			CanvasSpriteRenderer = base.gameObject.GetComponent<SpriteRenderer>();
		}
		if (ShaderChange == 0 && ForceMaterial != null)
		{
			ShaderChange = 1;
			if (tempMaterial != null)
			{
				UnityEngine.Object.DestroyImmediate(tempMaterial);
			}
			if (CanvasSpriteRenderer != null)
			{
				CanvasSpriteRenderer.sharedMaterial = ForceMaterial;
			}
			else if (CanvasImage != null)
			{
				CanvasImage.material = ForceMaterial;
			}
			ForceMaterial.hideFlags = HideFlags.None;
			ForceMaterial.shader = Shader.Find(shader);
		}
		if (ForceMaterial == null && ShaderChange == 1)
		{
			if (tempMaterial != null)
			{
				UnityEngine.Object.DestroyImmediate(tempMaterial);
			}
			tempMaterial = new Material(Shader.Find(shader));
			tempMaterial.hideFlags = HideFlags.None;
			if (CanvasSpriteRenderer != null)
			{
				CanvasSpriteRenderer.sharedMaterial = tempMaterial;
			}
			else if (CanvasImage != null)
			{
				CanvasImage.material = tempMaterial;
			}
			ShaderChange = 0;
		}
		if (!ActiveChange)
		{
			return;
		}
		if (CanvasSpriteRenderer != null)
		{
			CanvasSpriteRenderer.sharedMaterial.SetFloat("_Alpha", 1f - _Alpha);
			CanvasSpriteRenderer.sharedMaterial.SetFloat("_Zoom", _Zoom);
			CanvasSpriteRenderer.sharedMaterial.SetFloat("_Intensity", _Intensity);
			if (!_AutoScrollX && !_AutoScrollY)
			{
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetX", _OffsetX);
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetY", _OffsetY);
			}
			if (_AutoScrollX && !_AutoScrollY)
			{
				_AutoScrollCountX += _AutoScrollSpeedX * Time.deltaTime;
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetX", _AutoScrollCountX);
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetY", _OffsetY);
			}
			if (!_AutoScrollX && _AutoScrollY)
			{
				_AutoScrollCountY += _AutoScrollSpeedY * Time.deltaTime;
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetX", _OffsetX);
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetY", _AutoScrollCountY);
			}
			if (_AutoScrollX && _AutoScrollY)
			{
				_AutoScrollCountX += _AutoScrollSpeedX * Time.deltaTime;
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetX", _AutoScrollCountX);
				_AutoScrollCountY += _AutoScrollSpeedY * Time.deltaTime;
				CanvasSpriteRenderer.sharedMaterial.SetFloat("_OffsetY", _AutoScrollCountY);
			}
		}
		else if (CanvasImage != null)
		{
			CanvasImage.material.SetFloat("_Alpha", 1f - _Alpha);
			CanvasImage.material.SetFloat("_Zoom", _Zoom);
			CanvasImage.material.SetFloat("_Intensity", _Intensity);
			if (!_AutoScrollX && !_AutoScrollY)
			{
				CanvasImage.material.SetFloat("_OffsetX", _OffsetX);
				CanvasImage.material.SetFloat("_OffsetY", _OffsetY);
			}
			if (_AutoScrollX && !_AutoScrollY)
			{
				_AutoScrollCountX += _AutoScrollSpeedX * Time.deltaTime;
				CanvasImage.material.SetFloat("_OffsetX", _AutoScrollCountX);
				CanvasImage.material.SetFloat("_OffsetY", _OffsetY);
			}
			if (!_AutoScrollX && _AutoScrollY)
			{
				_AutoScrollCountY += _AutoScrollSpeedY * Time.deltaTime;
				CanvasImage.material.SetFloat("_OffsetX", _OffsetX);
				CanvasImage.material.SetFloat("_OffsetY", _AutoScrollCountY);
			}
			if (_AutoScrollX && _AutoScrollY)
			{
				_AutoScrollCountX += _AutoScrollSpeedX * Time.deltaTime;
				CanvasImage.material.SetFloat("_OffsetX", _AutoScrollCountX);
				_AutoScrollCountY += _AutoScrollSpeedY * Time.deltaTime;
				CanvasImage.material.SetFloat("_OffsetY", _AutoScrollCountY);
			}
		}
		if (_AutoScrollCountX > 1f)
		{
			_AutoScrollCountX = 0f;
		}
		if (_AutoScrollCountX < -1f)
		{
			_AutoScrollCountX = 0f;
		}
		if (_AutoScrollCountY > 1f)
		{
			_AutoScrollCountY = 0f;
		}
		if (_AutoScrollCountY < -1f)
		{
			_AutoScrollCountY = 0f;
		}
	}

	private void OnDestroy()
	{
		if (Application.isPlaying || !Application.isEditor)
		{
			return;
		}
		if (ForceMaterial != null && tempMaterial != null)
		{
			UnityEngine.Object.DestroyImmediate(tempMaterial);
		}
		if (base.gameObject.activeSelf)
		{
			if (CanvasSpriteRenderer != null)
			{
				CanvasSpriteRenderer.sharedMaterial = defaultMaterial;
				CanvasSpriteRenderer.sharedMaterial.hideFlags = HideFlags.None;
			}
			else if (CanvasImage != null)
			{
				CanvasImage.material = defaultMaterial;
				CanvasImage.material.hideFlags = HideFlags.None;
			}
		}
	}

	private void OnDisable()
	{
		if (ForceMaterial != null && tempMaterial != null)
		{
			UnityEngine.Object.DestroyImmediate(tempMaterial);
			if (CanvasSpriteRenderer != null)
			{
				CanvasSpriteRenderer.sharedMaterial = defaultMaterial;
				CanvasSpriteRenderer.sharedMaterial.hideFlags = HideFlags.None;
			}
			else if (CanvasImage != null)
			{
				CanvasImage.material = defaultMaterial;
				CanvasImage.material.hideFlags = HideFlags.None;
			}
		}
	}

	private void OnEnable()
	{
		if (defaultMaterial == null)
		{
			defaultMaterial = new Material(Shader.Find("Sprites/Default"));
		}
		if (ForceMaterial == null)
		{
			ActiveChange = true;
			tempMaterial = new Material(Shader.Find(shader));
			tempMaterial.hideFlags = HideFlags.None;
			if (CanvasSpriteRenderer != null)
			{
				CanvasSpriteRenderer.sharedMaterial = tempMaterial;
			}
			else if (CanvasImage != null)
			{
				CanvasImage.material = tempMaterial;
			}
			__MainTex2 = Resources.Load("_2dxFX_ShadowTXT") as Texture2D;
		}
		else
		{
			ForceMaterial.shader = Shader.Find(shader);
			ForceMaterial.hideFlags = HideFlags.None;
			if (CanvasSpriteRenderer != null)
			{
				CanvasSpriteRenderer.sharedMaterial = ForceMaterial;
			}
			else if (CanvasImage != null)
			{
				CanvasImage.material = ForceMaterial;
			}
			__MainTex2 = Resources.Load("_2dxFX_ShadowTXT") as Texture2D;
		}
		if ((bool)__MainTex2)
		{
			__MainTex2.wrapMode = TextureWrapMode.Repeat;
			if (CanvasSpriteRenderer != null)
			{
				CanvasSpriteRenderer.sharedMaterial.SetTexture("_MainTex2", __MainTex2);
			}
			else if (CanvasImage != null)
			{
				CanvasImage.material.SetTexture("_MainTex2", __MainTex2);
			}
		}
	}
}
