using System.Collections.Generic;
using GameSave;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel : Savable
{
	protected BattleDialogCharacter _xmlInfo;

	protected Dictionary<DialogType, List<BattleDialog>> _dlgDictionary;

	protected Dictionary<DialogType, List<BattleDialog>> _equippedDlgDictionary;

	protected Dictionary<DialogType, DialogData> _data;

	private string save_dlglist = "save_dlglist";

	public Dictionary<DialogType, DialogData> Data => _data;

	public BattleDialogueModel(BattleDialogCharacter battleDlg)
	{
		Init(battleDlg);
	}

	public void Init(BattleDialogCharacter battleDlg)
	{
		_xmlInfo = battleDlg;
		_dlgDictionary = new Dictionary<DialogType, List<BattleDialog>>();
		_equippedDlgDictionary = new Dictionary<DialogType, List<BattleDialog>>();
		_data = new Dictionary<DialogType, DialogData>();
		foreach (BattleDialogType dialogType in _xmlInfo.dialogTypeList)
		{
			if (dialogType.dialogType != DialogType.ERROR)
			{
				_dlgDictionary.Add(dialogType.dialogType, dialogType.dialogList);
			}
		}
		if (battleDlg.characterID == "Librarian")
		{
			RandomAll();
		}
	}

	public void SetDialogByDlgAndIndex(DialogType dlgType, BattleDialog dlg, int index = 0)
	{
		if (_equippedDlgDictionary.ContainsKey(dlgType))
		{
			if (_equippedDlgDictionary.Count < index + 1)
			{
				_equippedDlgDictionary[dlgType].Add(dlg);
			}
			else
			{
				_equippedDlgDictionary[dlgType][index] = dlg;
			}
		}
		else
		{
			List<BattleDialog> list = new List<BattleDialog>();
			list.Add(dlg);
			_equippedDlgDictionary.Add(dlgType, list);
		}
	}

	public virtual string GetBattleDlg(DialogType dlgType, List<BattleUnitModel> targets)
	{
		return GetBattleDlg(dlgType);
	}

	public virtual string GetBattleDlg(DialogType dlgType, string id)
	{
		string result = string.Empty;
		if (_dlgDictionary.ContainsKey(dlgType))
		{
			BattleDialog battleDialog = _dlgDictionary[dlgType].Find((BattleDialog x) => x.dialogID == id);
			if (battleDialog != null)
			{
				result = battleDialog.dialogContent;
			}
		}
		return result;
	}

	public virtual string GetBattleDlg(DialogType dlgType)
	{
		if (Data.ContainsKey(dlgType) && _xmlInfo.characterID == "Librarian")
		{
			if (Data[dlgType].xmlData != null)
			{
				return Data[dlgType].xmlData.dialogContent;
			}
			if (!string.IsNullOrEmpty(Data[dlgType].customText))
			{
				return Data[dlgType].customText;
			}
		}
		if (_dlgDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = _dlgDictionary[dlgType];
			if (list.Count > 0)
			{
				return list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		return "";
	}

	public virtual string GetBattleDlgSpecialEvent(string dialogID)
	{
		string result = string.Empty;
		if (_dlgDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
		{
			BattleDialog battleDialog = _dlgDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == dialogID);
			if (battleDialog != null)
			{
				result = battleDialog.dialogContent;
			}
		}
		return result;
	}

	public void Copy(BattleDialogueModel origin)
	{
		_xmlInfo = origin._xmlInfo;
		_dlgDictionary = new Dictionary<DialogType, List<BattleDialog>>(origin._dlgDictionary);
		_data = new Dictionary<DialogType, DialogData>();
		foreach (KeyValuePair<DialogType, DialogData> datum in origin._data)
		{
			_data.Add(datum.Key, new DialogData(datum.Value));
		}
	}

	public void RandomAll()
	{
		_equippedDlgDictionary.Clear();
		_ = _dlgDictionary;
		SetDialogByRandom(DialogType.START_BATTLE);
		SetDialogByRandom(DialogType.BATTLE_VICTORY);
		SetDialogByRandom(DialogType.DEATH);
		SetDialogByRandom(DialogType.COLLEAGUE_DEATH);
		SetDialogByRandom(DialogType.KILLS_OPPONENT);
	}

	public bool Contains(DialogType type, BattleDialog dlg)
	{
		DialogData dialogData = GetDialogData(type);
		if (dialogData != null && dialogData.xmlData == dlg)
		{
			return true;
		}
		return false;
	}

	public BattleDialog GetEquippedDialogByType(DialogType type)
	{
		if (_equippedDlgDictionary.TryGetValue(type, out var value) && value.Count > 0)
		{
			return value[0];
		}
		return null;
	}

	public void SetDialogByRandom(DialogType dialogType)
	{
		BattleDialogType battleDialogType = _xmlInfo.dialogTypeList.Find((BattleDialogType x) => x.dialogType == dialogType);
		if (battleDialogType != null)
		{
			SetDialogById(dialogType, RandomUtil.SelectOne(battleDialogType.dialogList).dialogID);
		}
	}

	public void SetDialogById(DialogType dialogType, string dialogXmlId)
	{
		BattleDialog dialogXmlInfo = GetDialogXmlInfo(dialogType, dialogXmlId);
		if (dialogXmlInfo != null)
		{
			if (_data.TryGetValue(dialogType, out var value))
			{
				value.xmlData = dialogXmlInfo;
				value.customText = "";
				return;
			}
			DialogData dialogData = new DialogData();
			dialogData.xmlData = dialogXmlInfo;
			dialogData.customText = "";
			_data.Add(dialogType, dialogData);
		}
	}

	public void SetDialog(DialogType dialogType, DialogData dialog)
	{
		if (_data.TryGetValue(dialogType, out var value))
		{
			value.xmlData = dialog.xmlData;
			value.customText = dialog.customText;
			return;
		}
		DialogData dialogData = new DialogData();
		dialogData.xmlData = dialog.xmlData;
		dialogData.customText = dialog.customText;
		_data.Add(dialogType, dialogData);
	}

	public void SetDialogByCustom(DialogType dialogType, string str)
	{
		if (_data.TryGetValue(dialogType, out var value))
		{
			value.xmlData = null;
			value.customText = str;
			return;
		}
		DialogData dialogData = new DialogData();
		dialogData.xmlData = null;
		dialogData.customText = str;
		_data.Add(dialogType, dialogData);
	}

	public string GetDialogText(DialogType dialogType)
	{
		if (_data.TryGetValue(dialogType, out var value))
		{
			if (value.xmlData != null)
			{
				return value.xmlData.dialogContent;
			}
			return value.customText;
		}
		return "";
	}

	public DialogData GetDialogData(DialogType dialogType)
	{
		if (_data.TryGetValue(dialogType, out var value))
		{
			return value;
		}
		return null;
	}

	private BattleDialog GetDialogXmlInfo(DialogType dialogType, string dialogXmlId)
	{
		return _xmlInfo.dialogTypeList.Find((BattleDialogType x) => x.dialogType == dialogType)?.dialogList.Find((BattleDialog x) => x.dialogID == dialogXmlId);
	}

	public virtual SaveData GetSaveData()
	{
		SaveData saveData = new SaveData();
		SaveData saveData2 = new SaveData();
		foreach (KeyValuePair<DialogType, DialogData> datum in _data)
		{
			datum.Value.dialogkey = datum.Key.ToString();
			saveData2.AddData(datum.Key.ToString(), datum.Value.GetSaveData());
		}
		saveData.AddData(save_dlglist, saveData2);
		return saveData;
	}

	public virtual void LoadFromSaveData(SaveData data)
	{
		SaveData data2 = data.GetData(save_dlglist);
		_data = new Dictionary<DialogType, DialogData>();
		List<DialogType> list = new List<DialogType>();
		for (int i = 0; i < 5; i++)
		{
			DialogType dialogType = (DialogType)i;
			SaveData data3 = data2.GetData(dialogType.ToString());
			if (data3 != null)
			{
				DialogData dialogData = new DialogData();
				dialogData.LoadFromSaveData(data3, dialogType);
				_data.Add(dialogType, dialogData);
			}
			else
			{
				list.Add(dialogType);
			}
		}
		if (list.Count <= 0)
		{
			return;
		}
		BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("Librarian", "Librarian");
		_xmlInfo = characterData;
		foreach (DialogType item in list)
		{
			SetDialogByRandom(item);
		}
	}
}
