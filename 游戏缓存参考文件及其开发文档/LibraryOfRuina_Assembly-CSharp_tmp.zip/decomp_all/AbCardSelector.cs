using System.Collections.Generic;
using LOR_XML;
using TMPro;
using UI;
using UnityEngine;
using UnityEngine.EventSystems;

public class AbCardSelector : MonoBehaviour
{
	[SerializeField]
	private Canvas _canvas;

	[SerializeField]
	private BattleUnitView _view;

	[SerializeField]
	private CanvasGroup _selectionGroup;

	[SerializeField]
	private CanvasGroup _dialogGroup;

	[SerializeField]
	private TextMeshProUGUI _lvText;

	[SerializeField]
	private _2dxFX_PlasmaShield imgEffect;

	public UICustomSelectable_autofind selectable;

	private BattleUnitModel _model;

	private bool _initialized;

	public BattleUnitView view => _view;

	public bool isInitialized => _initialized;

	public void Init(BattleUnitModel model, int emotionLv = 1)
	{
		if (!_initialized)
		{
			_initialized = true;
			selectable.interactable = true;
			_canvas.enabled = true;
			_model = model;
			imgEffect.Speed = Random.Range(1f, 3f);
			switch (emotionLv)
			{
			case 0:
				_lvText.text = "O";
				break;
			case 1:
				_lvText.text = "I";
				break;
			case 2:
				_lvText.text = "II";
				break;
			case 3:
				_lvText.text = "III";
				break;
			case 4:
				_lvText.text = "IV";
				break;
			case 5:
				_lvText.text = "V";
				break;
			}
		}
	}

	public void OnClickSelectButton()
	{
		Animator component = selectable.GetComponent<Animator>();
		if (component != null)
		{
			component.SetTrigger("Pressed");
		}
		SingletonBehavior<BattleManagerUI>.Instance.ui_levelup.OnClickTargetUnit(_model);
		SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SetToDefault();
	}

	public void OnPointerEnter(BaseEventData data)
	{
		Over();
	}

	public void OnPointerExit(BaseEventData data)
	{
		Unover();
	}

	private void Over()
	{
		if (SingletonBehavior<RencounterManager>.Instance.IsRunning || _view.model.IsDead() || _view.model.IsExtinction())
		{
			return;
		}
		Animator component = selectable.GetComponent<Animator>();
		if (component != null)
		{
			component.ResetTrigger("Normal");
			component.ResetTrigger("Pressed");
			component.SetTrigger("Highlighted");
		}
		if (Singleton<StageController>.Instance.Phase == StageController.StagePhase.ApplyLibrarianCardPhase)
		{
			if (SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.IsCardSelected())
			{
				if (_view.model.faction == Faction.Enemy)
				{
					_view.HighlightTurn(b: true, Color.red);
				}
				else
				{
					_view.HighlightTurn(b: true, Color.cyan);
				}
			}
			else
			{
				_view.HighlightTurn(b: true, Color.cyan);
			}
		}
		else
		{
			_view.HighlightTurn(b: true, Color.cyan);
		}
		if (!SingletonBehavior<BattleCamManager>.Instance.IsChanginProjection)
		{
			SingletonBehavior<BattleManagerUI>.Instance.ui_unitListInfoSummary.MouseEnterCharacter(_view.model, hOvered: true);
		}
		if (SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SelectedModel == null && _view.model.faction == Faction.Player)
		{
			SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SetCardsObject(_view.model, isClicked: false);
		}
		if (_view != null && _view.model != null)
		{
			_view.unitBottomStatUI.DisplayChildCanvasOverSpeedDice(over: true);
		}
	}

	private void Unover()
	{
		if (!SingletonBehavior<RencounterManager>.Instance.IsRunning && !_view.model.IsDead() && !_view.model.IsExtinction())
		{
			Animator component = selectable.GetComponent<Animator>();
			if (component != null)
			{
				component.SetTrigger("Normal");
			}
			if (!SingletonBehavior<BattleCamManager>.Instance.IsChanginProjection)
			{
				SingletonBehavior<BattleManagerUI>.Instance.ui_unitListInfoSummary.MouseEnterCharacter(_view.model, hOvered: false);
			}
			if (SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SelectedModel == null)
			{
				SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SetToDefault();
			}
			if (!SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.IsCardSelected() && _view != null && _view.model != null)
			{
				_view.unitBottomStatUI.DisplayChildCanvasOverSpeedDice(over: false);
			}
		}
	}

	public void DisplaySelectionDialog(EmotionCardXmlInfo card)
	{
		List<AbnormalityCardDialog> abnormalityDialogue = Singleton<AbnormalityCardDescXmlList>.Instance.GetAbnormalityDialogue(card.Name);
		_ = abnormalityDialogue[Random.Range(0, abnormalityDialogue.Count)];
		TurnOffUI();
	}

	public void TurnOffUI()
	{
		_initialized = false;
		_model = null;
		_canvas.enabled = false;
		selectable.interactable = false;
	}
}
