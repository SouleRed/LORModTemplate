public enum BattleDiceValueColor
{
	Normal,
	Increase,
	Decrease
}
