using TMPro;
using UI;
using UnityEngine;
using UnityEngine.UI;

public class BattleDiceCardBufUI : MonoBehaviour
{
	public Image img_bufIcon;

	public TextMeshProUGUI txt_bufIconStack;

	public UICardBufOverlay overlay;

	public void SetEnable(bool b)
	{
		base.gameObject.SetActive(b);
	}

	public void SetBufIcon(BattleDiceCardBuf cardBuf)
	{
		img_bufIcon.sprite = cardBuf.GetBufIcon();
		if (cardBuf.Stack > 0)
		{
			txt_bufIconStack.text = cardBuf.Stack.ToString();
		}
		else
		{
			txt_bufIconStack.text = "";
		}
		if (!string.IsNullOrEmpty(cardBuf.bufActivatedText))
		{
			overlay.SetDescription(cardBuf.bufActivatedText);
			overlay.SetEnable(b: true);
		}
		else
		{
			overlay.SetEnable(b: false);
		}
	}
}
