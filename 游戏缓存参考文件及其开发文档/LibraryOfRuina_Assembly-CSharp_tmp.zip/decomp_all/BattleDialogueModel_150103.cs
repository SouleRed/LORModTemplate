using LOR_XML;

public class BattleDialogueModel_150103 : BattleDialogueModel
{
	private bool _bSecondBattle;

	public BattleDialogueModel_150103(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bSecondBattle = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.GetStageModel().ClassInfo.id == 50011 && !_bSecondBattle)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep2", "R_Corp_Reindeer_2");
			Init(characterData);
			_bSecondBattle = true;
		}
		return base.GetBattleDlg(dlgType);
	}
}
