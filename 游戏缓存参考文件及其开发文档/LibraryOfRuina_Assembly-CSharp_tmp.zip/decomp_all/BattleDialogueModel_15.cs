using LOR_XML;

public class BattleDialogueModel_15 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_15(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Tiphereth";
		_characterId_RB1 = "T_O_Librarian_";
		_stageId_RB1 = 70005;
		_characterId_BS = "T_Librarian";
		_sephirahType = SephirahType.Tiphereth;
		_characterId_RB2 = _characterId_BS;
	}
}
