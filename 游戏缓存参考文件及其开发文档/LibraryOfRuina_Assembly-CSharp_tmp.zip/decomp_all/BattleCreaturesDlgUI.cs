using UnityEngine;

public class BattleCreaturesDlgUI : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
