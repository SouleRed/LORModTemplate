using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_140002 : BattleDialogueModel
{
	private bool _bCheckTenmaDead;

	private bool _bCheckYujinDead;

	public BattleDialogueModel_140002(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bCheckTenmaDead = false;
		_bCheckYujinDead = false;
	}

	public override string GetBattleDlg(DialogType dlgType, List<BattleUnitModel> targets)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.COLLEAGUE_DEATH)
		{
			BattleUnitModel battleUnitModel = targets.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 140001);
			BattleUnitModel battleUnitModel2 = targets.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 140003);
			if (battleUnitModel != null)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_1");
			}
			if (battleUnitModel2 != null)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
		}
		return result;
	}
}
