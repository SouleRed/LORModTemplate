using System.Collections.Generic;
using LOR_XML;

public class AbnormalityAbilityTextXmlList : Singleton<AbnormalityAbilityTextXmlList>
{
	private Dictionary<string, AbnormalityAbilityText> _dictionary;

	public void Init(Dictionary<string, AbnormalityAbilityText> dictionary)
	{
		_dictionary = dictionary;
	}

	public string GetAbilityText(string id, int index)
	{
		if (_dictionary.TryGetValue(id, out var value) && index < value.abilityList.Count)
		{
			return value.abilityList[index];
		}
		return "";
	}
}
