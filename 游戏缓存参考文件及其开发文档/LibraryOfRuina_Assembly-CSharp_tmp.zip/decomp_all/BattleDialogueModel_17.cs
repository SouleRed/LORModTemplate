using LOR_XML;

public class BattleDialogueModel_17 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_17(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Chesed";
		_characterId_RB1 = "C_J_Librarian_";
		_stageId_RB1 = 70007;
		_characterId_BS = "C_Librarian";
		_sephirahType = SephirahType.Chesed;
		_characterId_RB2 = _characterId_BS;
	}
}
