using LOR_XML;

public class BattleDialogueModel_16 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_16(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Gebura";
		_characterId_RB1 = "G_T_Librarian_";
		_stageId_RB1 = 70006;
		_characterId_BS = "G_Librarian";
		_sephirahType = SephirahType.Gebura;
		_characterId_RB2 = _characterId_BS;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (Singleton<StageController>.Instance.GetStageModel().ClassInfo.id == _stageId_RB1 && dlgType == DialogType.BATTLE_VICTORY)
		{
			result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
		}
		return result;
	}
}
