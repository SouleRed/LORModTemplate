using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_130008 : BattleDialogueModel
{
	private bool _bCheckSalvadorDead;

	private bool _bCheckPhilipDead;

	public BattleDialogueModel_130008(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bCheckPhilipDead = false;
		_bCheckSalvadorDead = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = string.Empty;
		switch (dlgType)
		{
		case DialogType.COLLEAGUE_DEATH:
		{
			List<BattleUnitModel> list = BattleObjectManager.instance.GetList(Faction.Enemy);
			BattleUnitModel battleUnitModel = list.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130007);
			BattleUnitModel battleUnitModel2 = list.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130009);
			if (battleUnitModel2 == null)
			{
				_bCheckPhilipDead = true;
			}
			if (battleUnitModel == null)
			{
				_bCheckSalvadorDead = true;
			}
			if (battleUnitModel2 != null && battleUnitModel2.IsDead() && !_bCheckPhilipDead)
			{
				_bCheckPhilipDead = true;
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_4");
			}
			if (battleUnitModel != null && battleUnitModel.IsDead() && !_bCheckSalvadorDead)
			{
				_bCheckSalvadorDead = true;
				result = ((!_bCheckPhilipDead) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_2") : GetBattleDlgSpecialEvent("SPECIAL_EVENT_3"));
			}
			break;
		}
		case DialogType.DEATH:
			result = ((!_bCheckSalvadorDead) ? base.GetBattleDlg(dlgType) : GetBattleDlgSpecialEvent("SPECIAL_EVENT_1"));
			break;
		case DialogType.BATTLE_VICTORY:
			result = ((!_bCheckSalvadorDead || !_bCheckPhilipDead) ? base.GetBattleDlg(dlgType) : GetBattleDlgSpecialEvent("SPECIAL_EVENT_0"));
			break;
		default:
			result = base.GetBattleDlg(dlgType);
			break;
		}
		return result;
	}
}
