using System.Collections.Generic;
using System.Xml.Serialization;

public class AttackEffectPathInfoRoot
{
	[XmlElement("Info")]
	public List<AttackEffectPathXmlInfo> list;
}
