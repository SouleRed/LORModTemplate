using UnityEngine;

public class AbsorbEffectInfo
{
	public GameObject effectObj;

	public SimpleBezier curve;

	public AbsorbEffectInfo(GameObject effectObj, Vector3 src, Vector3 dst)
	{
		this.effectObj = effectObj;
		curve = new SimpleBezier(src, dst);
	}

	public void SetPos(float t)
	{
		if (effectObj != null)
		{
			effectObj.transform.position = curve.GetPos(t);
		}
	}
}
