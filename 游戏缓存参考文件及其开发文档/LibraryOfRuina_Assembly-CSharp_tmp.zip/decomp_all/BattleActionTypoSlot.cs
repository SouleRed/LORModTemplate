using System.Collections;
using TMPro;
using UI;
using UnityEngine;
using UnityEngine.UI;

public class BattleActionTypoSlot : MonoBehaviour
{
	[SerializeField]
	private RectTransform content;

	[SerializeField]
	private Image img_Frame;

	[SerializeField]
	private Image img_Icon;

	[SerializeField]
	private Image img_IconGlow;

	[SerializeField]
	private TextMeshProUGUI txt_title;

	[SerializeField]
	private TextMeshProMaterialSetter msetter_title;

	[SerializeField]
	private TextMeshProUGUI txt_desc;

	[SerializeField]
	private CanvasGroup cg;

	private float defaultFrameHeight = 120f;

	private float TitleFrameHeight = 180f;

	public void SetData(EffectTypoData data, BattleUnitView view)
	{
		if (data == null)
		{
			return;
		}
		cg.alpha = 0f;
		BattleUIPassiveSet value = default(BattleUIPassiveSet);
		if (UISpriteDataManager.instance.BattleUIEffectSetDic.TryGetValue(data.category.ToString(), out value))
		{
			img_Icon.sprite = value.Icon;
			img_Icon.color = value.IconColor;
			if (value.IconGlow != null)
			{
				img_IconGlow.enabled = true;
				img_IconGlow.sprite = value.IconGlow;
				img_IconGlow.color = value.IconGlowColor;
			}
			else
			{
				img_IconGlow.enabled = false;
			}
			img_Frame.sprite = value.frame;
			txt_desc.color = value.textColor;
			txt_title.color = value.textColor;
			Color underlayColor = (SingletonBehavior<DirectingDataSetter>.Instance.OnGrayScale ? (value.textColor * value.textColor.grayscale) : (value.textColor * SingletonBehavior<DirectingDataSetter>.Instance.graycolor));
			msetter_title.underlayColor = underlayColor;
		}
		else
		{
			Debug.LogError("EffectTypo Not SpriteData : " + data.category);
		}
		txt_desc.text = data.Desc;
		if (data.Title != "")
		{
			txt_title.text = data.Title;
			txt_title.enabled = false;
			txt_title.enabled = true;
			float preferredWidth = txt_title.preferredWidth;
			Vector2 sizeDelta = txt_title.rectTransform.sizeDelta;
			sizeDelta.x = preferredWidth;
			txt_title.rectTransform.sizeDelta = sizeDelta;
			txt_title.gameObject.SetActive(value: false);
			txt_title.gameObject.SetActive(value: true);
		}
		else
		{
			txt_title.gameObject.SetActive(value: false);
		}
		Vector2 sizeDelta2 = img_Frame.rectTransform.sizeDelta;
		sizeDelta2.y = ((data.Title != "") ? TitleFrameHeight : defaultFrameHeight);
		img_Frame.rectTransform.sizeDelta = sizeDelta2;
		if (view != null)
		{
			SetDir(view.model.direction);
		}
		StartReveal();
	}

	public void SetDir(Direction dir)
	{
		if (dir == Direction.LEFT)
		{
			txt_title.rectTransform.localScale = new Vector3(1f, 1f, 1f);
			txt_title.alignment = TextAlignmentOptions.Left;
			txt_desc.rectTransform.localScale = new Vector3(1f, 1f, 1f);
			txt_desc.alignment = TextAlignmentOptions.Left;
		}
		else
		{
			txt_title.rectTransform.localScale = new Vector3(-1f, 1f, 1f);
			txt_title.alignment = TextAlignmentOptions.Right;
			txt_desc.rectTransform.localScale = new Vector3(-1f, 1f, 1f);
			txt_desc.alignment = TextAlignmentOptions.Right;
		}
	}

	public void StartReveal()
	{
		StopAllCoroutines();
		StartCoroutine(RevealProcess());
	}

	public void StartHide()
	{
		StopAllCoroutines();
		StartCoroutine(HideProcess());
	}

	public void HideForcely()
	{
		StopAllCoroutines();
		Object.Destroy(base.gameObject);
	}

	private IEnumerator RevealProcess()
	{
		DirectingDataSetter data = SingletonBehavior<DirectingDataSetter>.Instance;
		float elapsed = 0f;
		cg.alpha = 0f;
		float xpos = 500f;
		while (xpos != 0f)
		{
			elapsed += Time.deltaTime * data.Typo_revealSpeed;
			cg.alpha = Mathf.Lerp(0f, 1f, data.Typo_revealAlphaCurve.Evaluate(elapsed));
			xpos = Mathf.Lerp(xpos, 0f, data.Typo_revealXposCurve.Evaluate(elapsed));
			content.anchoredPosition = new Vector2(xpos, 0f);
			yield return YieldCache.waitFixedUpdate;
		}
	}

	private IEnumerator HideProcess()
	{
		DirectingDataSetter data = SingletonBehavior<DirectingDataSetter>.Instance;
		float elapsed = 0f;
		cg.alpha = 0f;
		float xpos = 0f;
		while (xpos != 500f)
		{
			elapsed += Time.deltaTime * data.Typo_hidespeed;
			cg.alpha = Mathf.Lerp(1f, 0f, elapsed * 1.5f);
			xpos = Mathf.Lerp(xpos, 500f, elapsed);
			content.anchoredPosition = new Vector2(xpos, 0f);
			yield return YieldCache.waitFixedUpdate;
		}
		Object.Destroy(base.gameObject);
	}
}
