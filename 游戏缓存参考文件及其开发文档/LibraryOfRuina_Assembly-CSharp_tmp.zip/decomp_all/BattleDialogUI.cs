using System.Collections;
using System.Collections.Generic;
using LOR_XML;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BattleDialogUI : MonoBehaviour
{
	[SerializeField]
	private BattleUnitView view;

	[SerializeField]
	private TextMeshProUGUI _txtAbnormalityDlg;

	[SerializeField]
	private Canvas _canvas;

	private Coroutine _routine;

	[SerializeField]
	private Image _speechBubble;

	[SerializeField]
	private TextMeshProUGUI _battleDialog;

	private bool _bEndedDisplay;

	private float xPos;

	public bool IsEndedDisplay => _bEndedDisplay;

	public void EnableCanvas(bool b)
	{
		_canvas.enabled = b;
	}

	public void TurnOnAbnormalityDlg(EmotionCardXmlInfo card)
	{
		Debug.Log("turnon");
		List<AbnormalityCardDialog> abnormalityDialogue = Singleton<AbnormalityCardDescXmlList>.Instance.GetAbnormalityDialogue(card.Name);
		CanvasGroup component = GetComponent<CanvasGroup>();
		string dialog = abnormalityDialogue[Random.Range(0, abnormalityDialogue.Count)].dialog;
		_txtAbnormalityDlg.text = dialog;
		if (card.State == MentalState.Positive)
		{
			_txtAbnormalityDlg.fontMaterial.SetColor("_GlowColor", SingletonBehavior<BattleManagerUI>.Instance.positiveCoinColor);
			_txtAbnormalityDlg.color = SingletonBehavior<BattleManagerUI>.Instance.positiveTextColor;
		}
		else if (card.State == MentalState.Negative)
		{
			_txtAbnormalityDlg.fontMaterial.SetColor("_GlowColor", SingletonBehavior<BattleManagerUI>.Instance.negativeCoinColor);
			_txtAbnormalityDlg.color = SingletonBehavior<BattleManagerUI>.Instance.negativeTextColor;
		}
		if (_routine != null)
		{
			StopCoroutine(_routine);
			_routine = null;
			_canvas.enabled = false;
		}
		_canvas.enabled = true;
		component.interactable = true;
		component.blocksRaycasts = true;
		_txtAbnormalityDlg.GetComponent<AbnormalityDlgEffect>().Init();
		_routine = StartCoroutine(AbnormalityDlgRoutine());
	}

	public void TurnOffAbnormalityDlg()
	{
		if (_canvas.enabled)
		{
			if (_routine != null)
			{
				StopCoroutine(_routine);
				_routine = null;
			}
			StartCoroutine(FadeOutRoutine());
		}
	}

	private IEnumerator FadeOutRoutine()
	{
		Debug.Log("turnoff");
		float elapsed = 0f;
		CanvasGroup cg = _canvas.GetComponent<CanvasGroup>();
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime;
			cg.alpha = 1f - elapsed;
			yield return null;
		}
		_canvas.enabled = false;
		cg.interactable = false;
		cg.blocksRaycasts = false;
	}

	private IEnumerator AbnormalityDlgRoutine()
	{
		float elapsed = 0f;
		CanvasGroup cg = _canvas.GetComponent<CanvasGroup>();
		while (elapsed < 1f)
		{
			elapsed = (cg.alpha = elapsed + Time.deltaTime * 2f);
			yield return null;
		}
		yield return YieldCache.WaitForSeconds(19f);
		elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 2f;
			cg.alpha = 1f - elapsed;
			yield return null;
		}
		_canvas.enabled = false;
		cg.interactable = false;
		cg.blocksRaycasts = false;
	}

	public void TurnOnDialog(string dlg, float duration)
	{
	}

	public void TurnOffDialog()
	{
	}

	private IEnumerator DlgRoutine(string str, float duration)
	{
		float elapsed = 0f;
		CanvasGroup cg = GetComponent<CanvasGroup>();
		_battleDialog.text = str;
		_canvas.enabled = true;
		cg.interactable = true;
		cg.blocksRaycasts = true;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 5f;
			cg.alpha = Mathf.Lerp(0f, 1f, elapsed);
			yield return YieldCache.waitFrame;
		}
		yield return YieldCache.WaitForSeconds(duration);
		elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime;
			cg.alpha = Mathf.Lerp(1f, 0f, elapsed);
			yield return YieldCache.waitFrame;
		}
		_canvas.enabled = false;
		cg.interactable = false;
		cg.blocksRaycasts = false;
		_bEndedDisplay = true;
	}

	private void OnDisable()
	{
		CanvasGroup component = GetComponent<CanvasGroup>();
		StopAllCoroutines();
		_canvas.enabled = false;
		component.interactable = false;
		component.blocksRaycasts = false;
	}

	private void Update()
	{
		if (view.speedDiceSetterUI.SpeedDicesCount > 0)
		{
			base.transform.localPosition = new Vector3(0f, 3.8f, 0f);
		}
		else
		{
			base.transform.localPosition = new Vector3(0f, 2.5f, 0f);
		}
	}
}
