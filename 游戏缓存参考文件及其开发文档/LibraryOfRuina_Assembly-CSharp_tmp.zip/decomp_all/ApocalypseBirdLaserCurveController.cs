using UnityEngine;

public class ApocalypseBirdLaserCurveController : MonoBehaviour
{
	[SerializeField]
	private Transform[] _controlPoints;

	public void SetLastPos(Vector3 worldPos)
	{
		if (_controlPoints != null && _controlPoints.Length != 0)
		{
			_controlPoints[_controlPoints.Length - 1].position = worldPos;
		}
	}

	public Vector3 GetPos(float ratio)
	{
		if (ratio > 1f)
		{
			ratio = 1f;
		}
		else if (ratio < 0f)
		{
			ratio = 0f;
		}
		return GetPosByFourCp(ratio);
	}

	private Vector3 GetPosByFourCp(float t)
	{
		if (_controlPoints.Length < 4)
		{
			Util.DebugEditorLog("Please reset control points' count");
			return Vector3.zero;
		}
		Vector3 position = _controlPoints[0].position;
		Vector3 position2 = _controlPoints[1].position;
		Vector3 position3 = _controlPoints[2].position;
		Vector3 position4 = _controlPoints[3].position;
		Vector3 vector = position + (position2 - position) * t;
		Vector3 vector2 = position2 + (position3 - position2) * t;
		Vector3 vector3 = position3 + (position4 - position3) * t;
		Vector3 vector4 = vector + (vector2 - vector) * t;
		Vector3 vector5 = vector2 + (vector3 - vector2) * t;
		return vector4 + (vector5 - vector4) * t;
	}

	private void OnDrawGizmos()
	{
		Gizmos.color = Color.green;
		for (int i = 0; i < _controlPoints.Length; i++)
		{
			Gizmos.DrawSphere(_controlPoints[i].position, 0.5f);
			if (i < _controlPoints.Length - 1)
			{
				Vector3 position = _controlPoints[i].position;
				Vector3 position2 = _controlPoints[i + 1].position;
				Gizmos.DrawLine(position, position2);
			}
		}
	}
}
