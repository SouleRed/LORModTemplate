using System;
using UnityEngine;

public class ApocalypseBirdMapManager : CreatureMapManager
{
	[Serializable]
	public class EggSpriteInfo
	{
		public SpriteRenderer normal;

		public SpriteRenderer breaked;

		public GameObject particle;

		public void Init()
		{
			normal.enabled = true;
			breaked.enabled = false;
			particle.SetActive(value: false);
		}

		public void SetBufActivated(bool active)
		{
			particle.SetActive(active);
		}

		public void SetBrokenSprite()
		{
			normal.enabled = false;
			breaked.enabled = true;
			particle.SetActive(value: false);
		}
	}

	[SerializeField]
	private ApocalypseBirdObjectController _birdController;

	[SerializeField]
	private EggSpriteInfo _bigBirdEggInfo;

	[SerializeField]
	private EggSpriteInfo _punishmentBirdEggInfo;

	[SerializeField]
	private EggSpriteInfo _judgementBirdEggInfo;

	public ApocalypseBirdObjectController birdController => _birdController;

	public void SetBufState(bool bigEyeOn, bool smallBeakOn, bool longArmOn)
	{
		_bigBirdEggInfo.SetBufActivated(bigEyeOn);
		_punishmentBirdEggInfo.SetBufActivated(smallBeakOn);
		_judgementBirdEggInfo.SetBufActivated(longArmOn);
	}

	public void BreakBuf(bool bigEyeBreaked, bool smallBeakBreaked, bool longArmBreaked)
	{
		if (bigEyeBreaked)
		{
			_bigBirdEggInfo.SetBrokenSprite();
		}
		if (smallBeakBreaked)
		{
			_punishmentBirdEggInfo.SetBrokenSprite();
		}
		if (longArmBreaked)
		{
			_judgementBirdEggInfo.SetBrokenSprite();
		}
	}

	public override void InitializeMap()
	{
		base.InitializeMap();
		_creatureDlgIdList.Add("B_roland_End_1");
		_creatureDlgIdList.Add("B_roland_End_2");
		_creatureDlgIdList.Add("B_roland_End_3");
		_creatureDlgIdList.Add("B_roland_End_4");
		_creatureDlgIdList.Add("B_roland_End_5");
		_creatureDlgIdList.Add("B_roland_End_6");
		_creatureDlgIdList.Add("B_roland_End_7");
		_creatureDlgIdList.Add("B_roland_End_8");
		_creatureDlgIdList.Add("B_roland_End_9");
		_creatureDlgIdList.Add("B_roland_End_10");
		_creatureDlgIdList.Add("B_roland_End_11");
		_creatureDlgIdList.Add("B_roland_End_12");
		_creatureDlgIdList.Add("B_roland_End_13");
		_creatureDlgIdList.Add("B_roland_End_14");
		_bigBirdEggInfo.Init();
		_punishmentBirdEggInfo.Init();
		_judgementBirdEggInfo.Init();
		CreateDialog();
	}

	public override void ChangeDlgByBoss()
	{
	}

	public override void CreateDialog()
	{
		_dlgIdx %= 14;
		base.CreateDialog();
	}
}
