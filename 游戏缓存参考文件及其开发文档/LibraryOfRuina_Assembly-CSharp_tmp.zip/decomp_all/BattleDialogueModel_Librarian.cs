using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_Librarian : BattleDialogueModel
{
	protected static List<int> librarianIndex = new List<int> { 1, 2, 3, 4 };

	protected int _index;

	protected SephirahType _sephirahType;

	protected string _floorName_RB1 = string.Empty;

	protected string _characterId_RB1 = string.Empty;

	protected int _stageId_RB1 = -1;

	protected const int _stageId_BS = 60003;

	protected string _characterId_BS = string.Empty;

	protected const int _stageId_RB2 = 60004;

	protected string _characterId_RB2 = string.Empty;

	private Dictionary<DialogType, List<BattleDialog>> _dlgDictionaryInBattle;

	public BattleDialogueModel_Librarian(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		if (librarianIndex.Count == 0)
		{
			librarianIndex.Add(1);
			librarianIndex.Add(2);
			librarianIndex.Add(3);
			librarianIndex.Add(4);
		}
		_index = RandomUtil.SelectOne(librarianIndex);
		librarianIndex.Remove(_index);
		_dlgDictionaryInBattle = null;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		LorId id = Singleton<StageController>.Instance.GetStageModel().ClassInfo.id;
		string result = string.Empty;
		if (id == _stageId_RB1)
		{
			if (_dlgDictionaryInBattle == null)
			{
				_dlgDictionaryInBattle = new Dictionary<DialogType, List<BattleDialog>>();
				foreach (BattleDialogType dialogType in Singleton<BattleDialogXmlList>.Instance.GetCharacterData("The Blue Reverberation2 " + _floorName_RB1, _characterId_RB1 + _index).dialogTypeList)
				{
					if (dialogType.dialogType != DialogType.ERROR)
					{
						_dlgDictionaryInBattle.Add(dialogType.dialogType, dialogType.dialogList);
					}
				}
			}
			if (_dlgDictionaryInBattle != null && _dlgDictionaryInBattle.ContainsKey(dlgType))
			{
				List<BattleDialog> list = _dlgDictionaryInBattle[dlgType];
				if (list.Count > 0)
				{
					result = list[Random.Range(0, list.Count)].dialogContent;
				}
			}
		}
		else if (id == 60003)
		{
			if (dlgType == DialogType.START_BATTLE)
			{
				List<SephirahType> usedFloorList = Singleton<StageController>.Instance.GetStageModel().GetUsedFloorList();
				SephirahType sephirahType = usedFloorList.Find((SephirahType x) => x == _sephirahType);
				if (sephirahType == _sephirahType)
				{
					int num = usedFloorList.IndexOf(sephirahType) + 1;
					result = TextDataModel.GetText($"Roland_Black_{_characterId_BS}_{_index}_{num}");
				}
			}
		}
		else if (id == 60004)
		{
			if (dlgType == DialogType.START_BATTLE)
			{
				List<SephirahType> usedFloorList2 = Singleton<StageController>.Instance.GetStageModel().GetUsedFloorList();
				SephirahType sephirahType2 = usedFloorList2.Find((SephirahType x) => x == _sephirahType);
				if (sephirahType2 == _sephirahType)
				{
					int num2 = usedFloorList2.IndexOf(sephirahType2);
					int num3 = 1;
					num3 = ((num2 < 1) ? 1 : ((num2 >= 4) ? 3 : 2));
					result = TextDataModel.GetText($"BlueReverberation_{_characterId_RB2}_{_index}_{num3}");
				}
			}
		}
		else
		{
			if (_xmlInfo.characterID != "Librarian")
			{
				BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("Librarian", "Librarian");
				Init(characterData);
			}
			result = base.GetBattleDlg(dlgType);
		}
		return result;
	}

	public virtual string GetBattleDlg_BS(DialogType dlgType, SephirahType sephirah, string sephirahName)
	{
		string result = string.Empty;
		switch (dlgType)
		{
		case DialogType.DEATH:
			result = TextDataModel.GetText($"Roland_Black_{sephirahName}_Die");
			break;
		case DialogType.START_BATTLE:
		{
			List<SephirahType> usedFloorList = Singleton<StageController>.Instance.GetStageModel().GetUsedFloorList();
			SephirahType sephirahType = usedFloorList.Find((SephirahType x) => x == sephirah);
			if (sephirahType == sephirah)
			{
				int num = usedFloorList.IndexOf(sephirahType) + 1;
				result = TextDataModel.GetText($"Roland_Black_{sephirahName}_{num}");
			}
			break;
		}
		}
		return result;
	}
}
