using UnityEngine;

public class AutoScriptDestruct : MonoBehaviour
{
	public MonoBehaviour targetScript;

	public float time = 0.25f;

	private float _elapsedTime;

	private void Start()
	{
	}

	private void Update()
	{
		_elapsedTime += Time.deltaTime;
		if (!(_elapsedTime > time))
		{
			return;
		}
		try
		{
			if (targetScript != null)
			{
				Object.Destroy(targetScript);
			}
		}
		catch
		{
		}
		Object.Destroy(this);
	}
}
