using System;
using System.Collections;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;

public static class AudioUtil
{
	public static IEnumerator LoadAudioCoroutine(string fullpath, Action<AudioClip> callback)
	{
		using UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip("file://" + fullpath, AudioType.UNKNOWN);
		yield return www.SendWebRequest();
		try
		{
			if (www.isNetworkError)
			{
				callback(null);
				Debug.Log(www.error);
				yield break;
			}
			AudioClip audioClip = null;
			if (www.downloadHandler is DownloadHandlerAudioClip { isDone: not false } downloadHandlerAudioClip)
			{
				audioClip = downloadHandlerAudioClip.audioClip;
				audioClip.name = Path.GetFileName(fullpath);
			}
			callback(audioClip);
		}
		catch (Exception message)
		{
			Debug.LogError(message);
			callback(null);
		}
	}
}
