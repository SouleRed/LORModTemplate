using LOR_XML;

public class BattleDialogueModel_Pierre : BattleDialogueModel
{
	public BattleDialogueModel_Pierre(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.DEATH)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.Book.GetBookClassInfoId() == 110001);
			if (battleUnitModel != null && battleUnitModel.IsDead())
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
		}
		return result;
	}
}
