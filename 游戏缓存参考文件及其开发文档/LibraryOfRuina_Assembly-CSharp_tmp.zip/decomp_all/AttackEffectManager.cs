using LOR_DiceSystem;
using UI;
using UnityEngine;

public class AttackEffectManager : SingletonBehavior<AttackEffectManager>
{
	public GameObject actionTextPrefab;

	[Header("데미지 폰트 관련 이펙트")]
	public DamageTextEffect damagedTextPrefab;

	public DamageNumber[] damageNumberPrefabs;

	public Color damageTextColor;

	public Color[] damageRwbpTextColor;

	protected AttackEffectManager()
	{
	}

	public void CreateActionText(BattleUnitView view, string actionName)
	{
		Object.Instantiate(actionTextPrefab, view.atkTextRoot).GetComponent<ActionText>().Init(actionName, view);
	}

	public void CreateRecoverTextEffect(int recoverAmount, BattleUnitModel unit, int colorType = 0)
	{
		DamageTextEffect damageTextEffect = Object.Instantiate(damagedTextPrefab, unit.view.damageTextEffectRoot);
		Color color = Color.white;
		if (UIColorManager.Manager.battleRecoverIconColors.Length > colorType)
		{
			color = UIColorManager.Manager.battleRecoverIconColors[colorType];
		}
		if (UISpriteDataManager.instance.battleRecoverIcons.Count > colorType)
		{
			damageTextEffect.img_RecoverIcon.img_Icon.sprite = UISpriteDataManager.instance.battleRecoverIcons[colorType];
		}
		damageTextEffect.img_RecoverIcon.SetColor(color);
		damageTextEffect.maxEffect = false;
		damageTextEffect.isAtk = false;
		if (recoverAmount > 0)
		{
			int num = (int)Mathf.Log10(recoverAmount);
			int num2 = (int)Mathf.Pow(10f, num);
			int num3 = recoverAmount / num2;
			DamageNumber damageNumber = Object.Instantiate(damageNumberPrefabs[num3], damageTextEffect.damageNumParent);
			damageNumber.SetColor(color, AtkResist.Weak);
			damageTextEffect.numberList.Add(damageNumber);
			if (num > 0)
			{
				damageNumber.transform.localScale *= 1.3f;
			}
			while (num2 / 10 > 0)
			{
				int num4 = recoverAmount % num2;
				num2 /= 10;
				num3 = num4 / num2;
				damageNumber = Object.Instantiate(damageNumberPrefabs[num3], damageTextEffect.damageNumParent);
				damageNumber.SetColor(color, AtkResist.Weak);
				damageTextEffect.numberList.Add(damageNumber);
			}
		}
		damageTextEffect.sign = 0f;
		SetEffectSizeByCamZoom(damageTextEffect);
		SetEffectSizeByUnitHeight(unit, damageTextEffect);
	}

	public void CreateDamagedTextEffectWithoutResist(int damage, int colorIdx, BattleUnitModel unit)
	{
		DamageTextEffect damageTextEffect = Object.Instantiate(damagedTextPrefab, unit.view.damageTextEffectRoot);
		damageTextEffect.maxEffect = false;
		damageTextEffect.isAtk = true;
		damageTextEffect.img_resistIcon.enabled = false;
		damageTextEffect.img_resistIconBg.enabled = false;
		damageTextEffect.img_resistIconFg.enabled = false;
		damageTextEffect.txt_resist.enabled = false;
		if (colorIdx == 2)
		{
			damageTextEffect.startDelay = true;
		}
		if (damage > 0)
		{
			int num = (int)Mathf.Log10(damage);
			int num2 = (int)Mathf.Pow(10f, num);
			int num3 = damage / num2;
			DamageNumber damageNumber = Object.Instantiate(damageNumberPrefabs[num3], damageTextEffect.damageNumParent);
			damageNumber.SetColor(damageRwbpTextColor[colorIdx], AtkResist.Weak);
			damageTextEffect.numberList.Add(damageNumber);
			if (num > 0)
			{
				damageNumber.transform.localScale *= 1.3f;
			}
			while (num2 / 10 > 0)
			{
				int num4 = damage % num2;
				num2 /= 10;
				num3 = num4 / num2;
				damageNumber = Object.Instantiate(damageNumberPrefabs[num3], damageTextEffect.damageNumParent);
				damageNumber.SetColor(damageRwbpTextColor[colorIdx], AtkResist.Weak);
				damageTextEffect.numberList.Add(damageNumber);
			}
		}
		else if (damage == 0)
		{
			DamageNumber damageNumber2 = Object.Instantiate(damageNumberPrefabs[0], damageTextEffect.damageNumParent);
			damageNumber2.SetColor(damageRwbpTextColor[colorIdx], AtkResist.Weak);
			damageTextEffect.numberList.Add(damageNumber2);
		}
		if (colorIdx == 2)
		{
			Vector3 localPosition = damageTextEffect.rotatePivot.localPosition;
			localPosition.x += 0.3f;
			localPosition.y -= 0.5f;
			damageTextEffect.rotatePivot.localPosition = localPosition;
		}
		if (unit.direction == Direction.RIGHT)
		{
			damageTextEffect.sign = -2f;
		}
		else
		{
			damageTextEffect.sign = 2f;
		}
		SetEffectSizeByCamZoom(damageTextEffect);
		SetEffectSizeByUnitHeight(unit, damageTextEffect);
	}

	public void CreateDamagedTextEffect(int damage, BehaviourDetail detail, BattleUnitModel unit, BattleUnitModel attacker, AtkResist atkResist, bool add, int colorIdx = 1)
	{
		DamageTextEffect damageTextEffect = Object.Instantiate(damagedTextPrefab, unit.view.damageTextEffectRoot);
		if (damageTextEffect == null)
		{
			return;
		}
		damageTextEffect.maxEffect = add;
		damageTextEffect.isAtk = true;
		AtkResist atkResist2 = AtkResist.Immune;
		damageTextEffect.txt_resist.color = damageRwbpTextColor[colorIdx];
		Color value = damageRwbpTextColor[colorIdx];
		value.a = 0.5f;
		damageTextEffect.txt_resist.fontMaterial.SetColor("_UnderlayColor", value);
		switch (colorIdx)
		{
		case 1:
		{
			damageTextEffect.txt_resist.text = unit.Book.GetResistHP_Text(detail, atkResist);
			atkResist2 = atkResist;
			int num3 = 0;
			switch (atkResist)
			{
			case AtkResist.None:
			case AtkResist.Weak:
				num3 = 0;
				break;
			case AtkResist.Vulnerable:
				num3 = 1;
				break;
			case AtkResist.Normal:
				num3 = 2;
				break;
			case AtkResist.Endure:
				num3 = 3;
				break;
			case AtkResist.Resist:
				num3 = 4;
				break;
			case AtkResist.Immune:
				num3 = 4;
				break;
			}
			switch (detail)
			{
			case BehaviourDetail.Slash:
				damageTextEffect.img_resistIcon.sprite = SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation.hpResists[0].icons[num3];
				break;
			case BehaviourDetail.Penetrate:
				damageTextEffect.img_resistIcon.sprite = SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation.hpResists[1].icons[num3];
				break;
			case BehaviourDetail.Hit:
				damageTextEffect.img_resistIcon.sprite = SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation.hpResists[2].icons[num3];
				break;
			}
			if (atkResist == AtkResist.Resist || atkResist == AtkResist.Immune)
			{
				damageTextEffect.img_resistIconBg.enabled = true;
				damageTextEffect.img_resistIconFg.enabled = true;
			}
			else
			{
				damageTextEffect.img_resistIconBg.enabled = false;
				damageTextEffect.img_resistIconFg.enabled = false;
			}
			float num4 = 1f;
			switch (atkResist2)
			{
			case AtkResist.Vulnerable:
				num4 = 0.8f;
				break;
			case AtkResist.Normal:
				num4 = 0.6f;
				break;
			case AtkResist.Endure:
				num4 = 0.4f;
				break;
			case AtkResist.Resist:
				num4 = 0.2f;
				break;
			case AtkResist.Immune:
				num4 = 0.1f;
				break;
			}
			Color color2 = damageTextEffect.txt_resist.color;
			color2 *= num4;
			color2.a = 1f;
			damageTextEffect.txt_resist.color = color2;
			break;
		}
		case 2:
		{
			damageTextEffect.txt_resist.text = unit.Book.GetResistBP_Text(detail, atkResist);
			atkResist2 = atkResist;
			int num = 0;
			switch (atkResist)
			{
			case AtkResist.None:
			case AtkResist.Weak:
				num = 0;
				break;
			case AtkResist.Vulnerable:
				num = 1;
				break;
			case AtkResist.Normal:
				num = 2;
				break;
			case AtkResist.Endure:
				num = 3;
				break;
			case AtkResist.Resist:
				num = 4;
				break;
			case AtkResist.Immune:
				num = 4;
				break;
			}
			switch (detail)
			{
			case BehaviourDetail.Slash:
				damageTextEffect.img_resistIcon.sprite = SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation.bpResists[0].icons[num];
				break;
			case BehaviourDetail.Penetrate:
				damageTextEffect.img_resistIcon.sprite = SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation.bpResists[1].icons[num];
				break;
			case BehaviourDetail.Hit:
				damageTextEffect.img_resistIcon.sprite = SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation.bpResists[2].icons[num];
				break;
			}
			if (atkResist == AtkResist.Resist || atkResist == AtkResist.Immune)
			{
				damageTextEffect.img_resistIconBg.enabled = true;
				damageTextEffect.img_resistIconFg.enabled = true;
			}
			else
			{
				damageTextEffect.img_resistIconBg.enabled = false;
				damageTextEffect.img_resistIconFg.enabled = false;
			}
			float num2 = 1f;
			switch (atkResist2)
			{
			case AtkResist.Vulnerable:
				num2 = 0.8f;
				break;
			case AtkResist.Normal:
				num2 = 0.6f;
				break;
			case AtkResist.Endure:
				num2 = 0.4f;
				break;
			case AtkResist.Resist:
				num2 = 0.2f;
				break;
			case AtkResist.Immune:
				num2 = 0.1f;
				break;
			}
			Color color = damageTextEffect.txt_resist.color;
			color *= num2;
			color.a = 1f;
			damageTextEffect.txt_resist.color = color;
			break;
		}
		}
		if (colorIdx == 2)
		{
			damageTextEffect.startDelay = true;
		}
		if (damage > 0)
		{
			int num5 = (int)Mathf.Log10(damage);
			int num6 = (int)Mathf.Pow(10f, num5);
			int num7 = damage / num6;
			DamageNumber damageNumber = Object.Instantiate(damageNumberPrefabs[num7], damageTextEffect.damageNumParent);
			damageNumber.SetColor(damageRwbpTextColor[colorIdx], atkResist2);
			damageTextEffect.numberList.Add(damageNumber);
			if (num5 > 0)
			{
				damageNumber.transform.localScale *= 1.3f;
			}
			while (num6 / 10 > 0)
			{
				int num8 = damage % num6;
				num6 /= 10;
				num7 = num8 / num6;
				damageNumber = Object.Instantiate(damageNumberPrefabs[num7], damageTextEffect.damageNumParent);
				damageNumber.SetColor(damageRwbpTextColor[colorIdx], atkResist2);
				damageTextEffect.numberList.Add(damageNumber);
			}
		}
		else if (damage == 0)
		{
			DamageNumber damageNumber2 = Object.Instantiate(damageNumberPrefabs[0], damageTextEffect.damageNumParent);
			damageNumber2.SetColor(damageRwbpTextColor[colorIdx], atkResist2);
			damageTextEffect.numberList.Add(damageNumber2);
		}
		if (colorIdx == 2)
		{
			Vector3 localPosition = damageTextEffect.rotatePivot.localPosition;
			localPosition.x += 0.3f;
			localPosition.y -= 0.5f;
			damageTextEffect.rotatePivot.localPosition = localPosition;
		}
		if (attacker != null)
		{
			if (attacker.view.WorldPosition.x > unit.view.WorldPosition.x)
			{
				damageTextEffect.sign = -2f;
			}
			else
			{
				damageTextEffect.sign = 2f;
			}
		}
		else
		{
			damageTextEffect.sign = 2f;
		}
		if (atkResist2 == AtkResist.None)
		{
			damageTextEffect.img_resistIcon.enabled = false;
			damageTextEffect.img_resistIconBg.enabled = false;
			damageTextEffect.img_resistIconFg.enabled = false;
			damageTextEffect.txt_resist.enabled = false;
		}
		SetEffectSizeByCamZoom(damageTextEffect);
		SetEffectSizeByUnitHeight(unit, damageTextEffect);
	}

	public void SetEffectSizeByCamZoom(DamageTextEffect effect)
	{
		float scaleByCamSize = SingletonBehavior<BattleCamManager>.Instance.mainCam.orthographicSize / SingletonBehavior<DirectingDataSetter>.Instance.DEFAULT_SIZE;
		effect.SetScaleByCamSize(scaleByCamSize);
	}

	public void SetEffectSizeByUnitHeight(BattleUnitModel unit, DamageTextEffect effect)
	{
		if (unit == null || unit.UnitData.unitData.customizeData == null)
		{
			return;
		}
		float num = (float)unit.UnitData.unitData.customizeData.height / SingletonBehavior<DirectingDataSetter>.Instance.DEFAULT_SIZE_Height - 1f;
		if (num > 0f)
		{
			float num2 = SingletonBehavior<DirectingDataSetter>.Instance.Maxdivdevalue_height;
			if (num2 == 0f)
			{
				num2 = 1f;
			}
			num = ((num > num2) ? num2 : num);
			num *= SingletonBehavior<DirectingDataSetter>.Instance.MaxScale_height / num2;
			effect.AddScaleByheight(num);
		}
	}
}
