public enum ActionType
{
	Atk,
	Def,
	None
}
