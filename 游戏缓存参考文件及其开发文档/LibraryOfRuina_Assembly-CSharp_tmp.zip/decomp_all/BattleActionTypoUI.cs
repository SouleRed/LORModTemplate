using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleActionTypoUI : MonoBehaviour
{
	[SerializeField]
	private BattleActionTypoSlot passivePrefab;

	[SerializeField]
	private RectTransform passiveRoot;

	private Direction currentdir = Direction.RIGHT;

	private List<BattleActionTypoSlot> prevActions = new List<BattleActionTypoSlot>();

	public void SetTypo(List<EffectTypoData> datas, BattleUnitView unitview)
	{
		StartCoroutine(NewActionTextRoutine(datas, unitview));
	}

	private IEnumerator NewActionTextRoutine(List<EffectTypoData> strList, BattleUnitView _unitView)
	{
		int i = 0;
		float ypos = 0f;
		passiveRoot.anchoredPosition = ((_unitView.model.direction == Direction.LEFT) ? new Vector2(1000f, 0f) : new Vector2(500f, 0f));
		float num = 1f;
		if (SingletonBehavior<BattleCamManager>.Instance.mainCam != null)
		{
			float num2 = SingletonBehavior<BattleCamManager>.Instance.mainCam.orthographicSize / SingletonBehavior<DirectingDataSetter>.Instance.DEFAULT_SIZE_ForTypo;
			if (num2 > 1f)
			{
				num = num2;
			}
		}
		float maxScale_fortypo = SingletonBehavior<DirectingDataSetter>.Instance.MaxScale_fortypo;
		num = ((num > maxScale_fortypo) ? maxScale_fortypo : num);
		passiveRoot.localScale = ((_unitView.model.direction == Direction.LEFT) ? Vector3.one : new Vector3(0f - num, num, 1f));
		if (currentdir != _unitView.model.direction)
		{
			currentdir = _unitView.model.direction;
			BattleActionTypoSlot[] componentsInChildren = passiveRoot.GetComponentsInChildren<BattleActionTypoSlot>();
			if (componentsInChildren.Length != 0)
			{
				BattleActionTypoSlot[] array = componentsInChildren;
				for (int j = 0; j < array.Length; j++)
				{
					array[j].SetDir(currentdir);
				}
			}
		}
		prevActions.Clear();
		while (i < strList.Count)
		{
			float typo_intervalHeight = SingletonBehavior<DirectingDataSetter>.Instance.Typo_intervalHeight;
			float num3 = ((strList[i].Title == "") ? typo_intervalHeight : (typo_intervalHeight * 1.5f));
			ypos += ((i == 0) ? 0f : num3);
			BattleActionTypoSlot component = Object.Instantiate(passivePrefab, passiveRoot).GetComponent<BattleActionTypoSlot>();
			component.SetData(strList[i], _unitView);
			prevActions.Add(component);
			Vector3 localPosition = component.transform.localPosition;
			localPosition.y += ypos;
			component.transform.localPosition = localPosition;
			i++;
			yield return YieldCache.WaitForSeconds(SingletonBehavior<DirectingDataSetter>.Instance.Typo_revealInterval);
		}
	}

	public void HidePrevActions()
	{
		StopAllCoroutines();
		if (prevActions.Count == 0)
		{
			return;
		}
		foreach (BattleActionTypoSlot prevAction in prevActions)
		{
			prevAction.StartHide();
		}
		prevActions.Clear();
	}

	public void HideActionsForcely()
	{
		StopAllCoroutines();
		foreach (BattleActionTypoSlot prevAction in prevActions)
		{
			prevAction.HideForcely();
		}
		prevActions.Clear();
	}
}
