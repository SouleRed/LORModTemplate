using System.Collections;
using System.Collections.Generic;
using LOR_DiceSystem;
using UnityEngine;

public class ActionManager : SingletonBehavior<ActionManager>
{
	[Header("-------- Reference --------")]
	[SerializeField]
	private DamageText _dmgTextPrefab;

	[SerializeField]
	private Camera _battleCam;

	[SerializeField]
	private Camera _actionCam;

	[SerializeField]
	private Vector3 stdPosA;

	[SerializeField]
	private Vector3 stdPosB;

	[SerializeField]
	private Vector3 stdScaleA;

	[SerializeField]
	private Vector3 stdScaleB;

	[SerializeField]
	private GameObject cloneBackgroundObj;

	[SerializeField]
	private CameraFilterPack_AAA_Blood_Hit bloodFilter;

	[SerializeField]
	private CameraFilterPack_FX_EarthQuake earthquakeFilter;

	[SerializeField]
	private BattleFocusActionUI_Frame frameSc;

	[SerializeField]
	private AnimationCurve _camRotCurve_damaged;

	[SerializeField]
	private AnimationCurve _camRotCurve_waitRolling;

	[SerializeField]
	private ActionTotalDamage _leftTotalDamageObj;

	[SerializeField]
	private ActionTotalDamage _rightTotalDamageObj;

	[SerializeField]
	private Transform characterRoot;

	[Header("-------- Runtime --------")]
	public ActionCharacter unitA;

	public ActionCharacter unitB;

	private bool _bAPosArranged = true;

	private bool _bInitialized;

	private bool _bActionEnd = true;

	private bool _bActionEndOnce = true;

	private BattleResult _leftUnitResult;

	private BattleResult _rightUnitResult;

	private int _leftUnitTotalDamage;

	private int _rightUnitTotalDamage;

	private bool _bWaitPlayerRolling;

	private float _elapsedCamMoving;

	private float _elapsedUnitMoving;

	[SerializeField]
	private BattleUnitBottomUIInBattle leftBottomUI;

	[SerializeField]
	private BattleUnitBottomUIInBattle rightBottonUI;

	public bool IsPosArranged => _bAPosArranged;

	public bool IsActionEnd => _bActionEnd;

	public bool IsReadyAction
	{
		get
		{
			if (unitA.isReadyAction)
			{
				return unitB.isReadyAction;
			}
			return false;
		}
	}

	public bool IsActionEndOnce => _bActionEndOnce;

	public bool IsInitialized => _bInitialized;

	public void InitData(BattleUnitView leftView, BattleUnitView rightView)
	{
		_bInitialized = true;
		_actionCam.enabled = true;
		if (!_bActionEnd)
		{
			EndActionForcely();
		}
		_leftUnitResult = new BattleResult(leftView, new List<ResultData>());
		_rightUnitResult = new BattleResult(rightView, new List<ResultData>());
		frameSc.AppearAnimStart();
		_bActionEnd = false;
		leftView.actionView = unitA;
		rightView.actionView = unitB;
		cloneBackgroundObj.SetActive(value: true);
		leftBottomUI.view = _leftUnitResult.unit;
		rightBottonUI.view = _rightUnitResult.unit;
		leftBottomUI.gameObject.SetActive(value: true);
		rightBottonUI.gameObject.SetActive(value: true);
		StartCoroutine(ArrangeStartPos(leftView, rightView));
		unitA.Initialize(leftView.charAppearance);
		unitB.Initialize(rightView.charAppearance);
	}

	public void AddBattleResult(ResultData enemyResult, ResultData allyResult)
	{
		_leftUnitResult.resultList.Add(enemyResult);
		_rightUnitResult.resultList.Add(allyResult);
	}

	public void DoAction()
	{
		if (_leftUnitResult != null && _rightUnitResult != null)
		{
			StartCoroutine(DoActions());
		}
	}

	public void WaitRolling(bool b)
	{
		_elapsedCamMoving = 0f;
		_elapsedUnitMoving = 0f;
		_bWaitPlayerRolling = b;
		if (!b)
		{
			Vector3 eulerAngles = _actionCam.transform.localRotation.eulerAngles;
			eulerAngles.y = 0f;
			_actionCam.transform.localRotation = Quaternion.Euler(eulerAngles);
			_elapsedCamMoving = 0f;
			_elapsedUnitMoving = 0f;
		}
	}

	public void CreateDamageText(int dmg, ActionCharacter actionView, bool isAdditionalDmg)
	{
		DamageText damageText = Object.Instantiate(_dmgTextPrefab, actionView.transform);
		damageText.CreateDamageText(dmg, Color.red);
		float x = actionView.transform.localScale.x;
		damageText.transform.localScale = actionView.transform.localScale * (isAdditionalDmg ? 0.005f : 0.01f);
		damageText.transform.localPosition = new Vector3(1f, (x > 0f) ? (-0.5f) : 3.5f, -1f);
		Vector3 localPosition = damageText.transform.localPosition;
		localPosition.x += Random.Range(-1f, 1f);
		localPosition.y += Random.Range(-1f, 0.5f);
		damageText.transform.localPosition = localPosition;
		damageText.transform.localRotation = Quaternion.Euler(0f, 0f, (x > 0f) ? Random.Range(-15f, -5f) : Random.Range(5f, 15f));
		if (actionView == unitA)
		{
			_leftUnitTotalDamage += dmg;
		}
		else if (actionView == unitB)
		{
			_rightUnitTotalDamage += dmg;
		}
		StartCoroutine(OnBloodFilter(actionView == unitA));
		StartCoroutine(OnEarthQuakeFilter(dmg));
	}

	private IEnumerator OnEarthQuakeFilter(int dmg)
	{
		earthquakeFilter.enabled = true;
		float elapsed = 0f;
		earthquakeFilter.Speed = 30f;
		float vy = 50f;
		float vx = 8f;
		earthquakeFilter.Y = vy * 0.001f;
		earthquakeFilter.X = vx * 0.001f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 2f;
			earthquakeFilter.Y = Mathf.Lerp(vy, 0f, elapsed) * 0.001f;
			earthquakeFilter.X = Mathf.Lerp(vx, 0f, elapsed) * 0.001f;
			yield return YieldCache.waitFrame;
		}
		earthquakeFilter.Y = 0f;
		earthquakeFilter.X = 0f;
		earthquakeFilter.enabled = false;
	}

	private IEnumerator OnBloodFilter(bool left)
	{
		bloodFilter.enabled = true;
		bloodFilter.Hit_Left = 0f;
		bloodFilter.Hit_Down = 0f;
		bloodFilter.Blood_Hit_Left = 0f;
		bloodFilter.Blood_Hit_Down = 0f;
		bloodFilter.Blood_Hit_Full_3 = 0f;
		bloodFilter.Hit_Right = 0f;
		bloodFilter.Hit_Up = 0f;
		bloodFilter.Blood_Hit_Right = 0f;
		bloodFilter.Blood_Hit_Up = 0f;
		bloodFilter.Blood_Hit_Full_3 = 0f;
		float v1 = 0.846f;
		float v2 = 0.663f;
		float v3 = 0.445f;
		float v4 = 0.25f;
		float v5 = 0.108f;
		if (left)
		{
			float elapsed = 0f;
			while (elapsed < 1f)
			{
				elapsed += Time.deltaTime * 2f;
				bloodFilter.Hit_Left = Mathf.Lerp(v1, 0f, elapsed);
				bloodFilter.Hit_Up = Mathf.Lerp(v2, 0f, elapsed);
				bloodFilter.Blood_Hit_Left = Mathf.Lerp(v3, 0f, elapsed);
				bloodFilter.Blood_Hit_Up = Mathf.Lerp(v4, 0f, elapsed);
				bloodFilter.Blood_Hit_Full_3 = Mathf.Lerp(v5, 0f, elapsed);
				yield return YieldCache.waitFrame;
			}
			bloodFilter.Hit_Left = v1;
			bloodFilter.Hit_Up = v2;
			bloodFilter.Blood_Hit_Left = v3;
			bloodFilter.Blood_Hit_Up = v4;
			bloodFilter.Blood_Hit_Full_3 = v5;
		}
		else
		{
			float elapsed = 0f;
			while (elapsed < 1f)
			{
				elapsed += Time.deltaTime * 2f;
				bloodFilter.Hit_Right = Mathf.Lerp(v1, 0f, elapsed);
				bloodFilter.Hit_Down = Mathf.Lerp(v2, 0f, elapsed);
				bloodFilter.Blood_Hit_Right = Mathf.Lerp(v3, 0f, elapsed);
				bloodFilter.Blood_Hit_Down = Mathf.Lerp(v4, 0f, elapsed);
				bloodFilter.Blood_Hit_Full_3 = Mathf.Lerp(v5, 0f, elapsed);
				yield return YieldCache.waitFrame;
			}
			bloodFilter.Hit_Right = v1;
			bloodFilter.Hit_Down = v2;
			bloodFilter.Blood_Hit_Right = v3;
			bloodFilter.Blood_Hit_Down = v4;
			bloodFilter.Blood_Hit_Full_3 = v5;
		}
		bloodFilter.enabled = false;
	}

	public void EndAction()
	{
		if (_bInitialized)
		{
			unitA.isReadyAction = false;
			unitB.isReadyAction = false;
			_leftTotalDamageObj.ResetNumber();
			_rightTotalDamageObj.ResetNumber();
			StartCoroutine(Reset());
			_bInitialized = false;
		}
	}

	public void EndActionForcely()
	{
		StopAllCoroutines();
		unitA.ResetAction();
		unitB.ResetAction();
		unitA.gameObject.SetActive(value: false);
		unitB.gameObject.SetActive(value: false);
		frameSc.FadeOutAnimStart();
		Vector3 position = _actionCam.transform.position;
		position.x = 0f;
		_actionCam.transform.position = position;
		leftBottomUI.gameObject.SetActive(value: false);
		rightBottonUI.gameObject.SetActive(value: false);
		_bActionEndOnce = true;
		_bActionEnd = true;
		_bInitialized = false;
		_leftUnitResult.unit.actionView = null;
		_rightUnitResult.unit.actionView = null;
	}

	private IEnumerator DisplayTotalDamage()
	{
		yield return YieldCache.WaitForSeconds(0.5f);
		_leftTotalDamageObj.gameObject.SetActive(value: true);
		_rightTotalDamageObj.gameObject.SetActive(value: true);
		_leftTotalDamageObj.CreateDamageText(_leftUnitTotalDamage);
		_rightTotalDamageObj.CreateDamageText(_rightUnitTotalDamage);
		float elapsed = 0f;
		Vector3 src = Vector3.one * 5f;
		Vector3 dst = Vector3.one;
		float v = 5f;
		Vector3 lp = _leftTotalDamageObj.transform.localPosition;
		Vector3 rp = _rightTotalDamageObj.transform.localPosition;
		Vector3 rv = Vector3.one;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 7.5f;
			_leftTotalDamageObj.transform.localScale = Vector3.Lerp(src, dst, elapsed);
			_rightTotalDamageObj.transform.localScale = Vector3.Lerp(src, dst, elapsed);
			rv.x = Random.Range(0f - v, v);
			rv.y = Random.Range(0f - v, v);
			_leftTotalDamageObj.transform.localPosition = lp + rv;
			rv.x = Random.Range(0f - v, v);
			rv.y = Random.Range(0f - v, v);
			_rightTotalDamageObj.transform.localPosition = rp + rv;
			yield return YieldCache.waitFrame;
		}
		_leftTotalDamageObj.transform.localPosition = lp;
		_rightTotalDamageObj.transform.localPosition = rp;
		yield return YieldCache.WaitForSeconds(0.5f);
		StartCoroutine(Reset());
	}

	private IEnumerator Reset()
	{
		yield return new WaitUntil(() => IsActionEndOnce);
		unitA.ResetAction();
		unitB.ResetAction();
		BattleUnitView unit = _leftUnitResult.unit;
		BattleUnitView unit2 = _rightUnitResult.unit;
		Vector3 pA = _actionCam.ViewportToWorldPoint(_battleCam.WorldToViewportPoint(unit.transform.position));
		Vector3 pB = _actionCam.ViewportToWorldPoint(_battleCam.WorldToViewportPoint(unit2.transform.position));
		float num = _actionCam.orthographicSize / _battleCam.orthographicSize;
		Vector3 sA = unit.characterRotationCenter.localScale * num;
		Vector3 sB = unit2.characterRotationCenter.localScale * num;
		Vector3 srcA = unitA.transform.position;
		Vector3 srcB = unitB.transform.position;
		float srcRotA = unitA.transform.rotation.eulerAngles.z;
		float srcRotB = unitB.transform.rotation.eulerAngles.z;
		float elapsed = 1f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 10f;
			unitA.transform.position = Vector3.Lerp(srcA, pA, elapsed);
			unitB.transform.position = Vector3.Lerp(srcB, pB, elapsed);
			unitA.transform.localScale = Vector3.Lerp(stdScaleA, sA, elapsed * 4f);
			unitB.transform.localScale = Vector3.Lerp(stdScaleB, sB, elapsed * 4f);
			float z = Mathf.Lerp(srcRotA, 0f, elapsed);
			float z2 = Mathf.Lerp(srcRotB, 0f, elapsed);
			Vector3 eulerAngles = unitA.transform.rotation.eulerAngles;
			eulerAngles.z = z;
			Vector3 eulerAngles2 = unitB.transform.rotation.eulerAngles;
			eulerAngles2.z = z2;
			unitA.transform.rotation = Quaternion.Euler(eulerAngles);
			unitB.transform.rotation = Quaternion.Euler(eulerAngles2);
			yield return YieldCache.waitFrame;
		}
		leftBottomUI.gameObject.SetActive(value: false);
		rightBottonUI.gameObject.SetActive(value: false);
		yield return YieldCache.WaitForSeconds(0.2f);
		unitA.transform.position = stdPosA;
		unitB.transform.position = stdPosB;
		unitA.gameObject.SetActive(value: false);
		unitB.gameObject.SetActive(value: false);
		frameSc.FadeOutAnimStart();
		Vector3 position = _actionCam.transform.position;
		position.x = 0f;
		_actionCam.transform.position = position;
		cloneBackgroundObj.SetActive(value: false);
		_leftUnitTotalDamage = 0;
		_rightUnitTotalDamage = 0;
		_leftTotalDamageObj.gameObject.SetActive(value: false);
		_rightTotalDamageObj.gameObject.SetActive(value: false);
		_leftUnitResult.unit.actionView = null;
		_rightUnitResult.unit.actionView = null;
		_bActionEnd = true;
		_actionCam.enabled = true;
	}

	private IEnumerator ArrangeStartPos(BattleUnitView v1, BattleUnitView v2)
	{
		_bAPosArranged = false;
		float elapsed = 0f;
		Vector3 pA = _actionCam.ViewportToWorldPoint(_battleCam.WorldToViewportPoint(v1.transform.position));
		Vector3 pB = _actionCam.ViewportToWorldPoint(_battleCam.WorldToViewportPoint(v2.transform.position));
		unitA.gameObject.SetActive(value: true);
		unitB.gameObject.SetActive(value: true);
		float num = _actionCam.orthographicSize / _battleCam.orthographicSize;
		Vector3 sA = v1.characterRotationCenter.localScale * num;
		Vector3 sB = v2.characterRotationCenter.localScale * num;
		Vector3 dstA = stdPosA;
		Vector3 dstB = stdPosB;
		int dstRotA = 0;
		int dstRotB = 0;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 5f;
			unitA.transform.position = Vector3.Lerp(pA, dstA, elapsed);
			unitB.transform.position = Vector3.Lerp(pB, dstB, elapsed);
			unitA.transform.localScale = Vector3.Lerp(sA, stdScaleA, elapsed);
			unitB.transform.localScale = Vector3.Lerp(sB, stdScaleB, elapsed);
			float z = Mathf.Lerp(0f, dstRotA, elapsed);
			float z2 = Mathf.Lerp(0f, dstRotB, elapsed);
			Vector3 eulerAngles = unitA.transform.rotation.eulerAngles;
			eulerAngles.z = z;
			Vector3 eulerAngles2 = unitB.transform.rotation.eulerAngles;
			eulerAngles2.z = z2;
			unitA.transform.rotation = Quaternion.Euler(eulerAngles);
			unitB.transform.rotation = Quaternion.Euler(eulerAngles2);
			leftBottomUI.transform.position = unitA.transform.position;
			rightBottonUI.transform.position = unitB.transform.position;
			yield return YieldCache.waitFrame;
		}
		yield return YieldCache.WaitForSeconds(0.2f);
		_bAPosArranged = true;
	}

	private IEnumerator DoActions()
	{
		_bActionEndOnce = false;
		if (_leftUnitResult.resultList.Count == 0)
		{
			unitA.isActionEnd = true;
			unitB.isActionEnd = true;
		}
		while (_leftUnitResult.resultList.Count > 0)
		{
			unitA.BeforeAction(_leftUnitResult.resultList[0]);
			unitB.BeforeAction(_rightUnitResult.resultList[0]);
			yield return new WaitUntil(() => IsReadyAction);
			frameSc.SpeedUpEffect();
			unitA.spriteRoot.transform.localPosition = Vector3.zero;
			unitB.spriteRoot.transform.localPosition = Vector3.zero;
			SingletonBehavior<DiceEffectManager>.Instance.CreateAttackEffect(_leftUnitResult.unit.model, 2f);
			SingletonBehavior<DiceEffectManager>.Instance.CreateAttackEffect(_rightUnitResult.unit.model, 2f);
			ResultData r = _leftUnitResult.resultList[0];
			ResultData r2 = _rightUnitResult.resultList[0];
			_ = Vector3.zero;
			_ = Vector3.zero;
			bool flag = false;
			Vector3 dstPos;
			Vector3 dstPos2;
			if (r.actionType == ActionType.Atk)
			{
				if (r2.actionType == ActionType.Atk)
				{
					if (r.result == Result.Draw)
					{
						dstPos = (unitA.transform.position + unitB.transform.position) * 0.5f;
						dstPos.x -= 1f;
						dstPos2 = (unitA.transform.position + unitB.transform.position) * 0.5f;
						dstPos2.x += 1f;
						flag = true;
					}
					else if (r.result == Result.Win)
					{
						Vector3 position = unitB.transform.position;
						position.x += 3f;
						dstPos = position;
						dstPos2 = position;
						dstPos2.x += 1.5f;
					}
					else
					{
						Vector3 position2 = unitA.transform.position;
						position2.x -= 3f;
						dstPos = position2;
						dstPos.x -= 1.5f;
						dstPos2 = position2;
					}
				}
				else
				{
					Vector3 position3 = unitB.transform.position;
					position3.x += 3f;
					dstPos = position3;
					dstPos2 = position3;
					dstPos2.x += 1.5f;
				}
			}
			else if (r.actionType == ActionType.Def)
			{
				if (r2.actionType == ActionType.Def)
				{
					dstPos = unitA.transform.position;
					dstPos2 = unitB.transform.position;
					flag = true;
				}
				else
				{
					dstPos = unitA.transform.position;
					dstPos.x -= 1.5f;
					dstPos2 = unitA.transform.position;
				}
			}
			else if (r2.actionType == ActionType.Atk)
			{
				Vector3 position4 = unitA.transform.position;
				position4.x -= 3f;
				dstPos = position4;
				dstPos.x -= 1.5f;
				dstPos2 = position4;
			}
			else
			{
				dstPos = unitA.transform.position;
				dstPos2 = unitB.transform.position;
			}
			unitA.DoAction(r, dstPos);
			unitB.DoAction(r2, dstPos2);
			_leftUnitResult.resultList.RemoveAt(0);
			_rightUnitResult.resultList.RemoveAt(0);
			if (flag)
			{
				float ee = 0f;
				float src = _actionCam.orthographicSize;
				float dst = 8f;
				while (ee < 1f)
				{
					ee += Time.deltaTime * 4f;
					_actionCam.orthographicSize = Mathf.Lerp(src, dst, ee);
					yield return YieldCache.waitFrame;
				}
				ee = 0f;
				while (ee < 1f)
				{
					ee += Time.deltaTime * 4f;
					_actionCam.orthographicSize = Mathf.Lerp(dst, src, ee);
					yield return YieldCache.waitFrame;
				}
				_actionCam.orthographicSize = src;
			}
			else
			{
				if ((r.result == Result.Win && r2.result == Result.Lose) || r.result != Result.Lose || r2.result == Result.Win)
				{
				}
				yield return YieldCache.WaitForSeconds(1f);
			}
		}
		yield return new WaitUntil(() => unitA.isActionEnd && unitB.isActionEnd);
		_bActionEndOnce = true;
	}

	private void Start()
	{
		if (_battleCam == null)
		{
			_battleCam = SingletonBehavior<BattleCamManager>.Instance.mainCam;
		}
	}

	private void Update()
	{
		Vector3 b = (unitA.transform.position + unitB.transform.position) * 0.5f;
		b.y = _actionCam.transform.position.y;
		b.z = _actionCam.transform.position.z;
		if (leftBottomUI.isActiveAndEnabled)
		{
			leftBottomUI.transform.position = unitA.spriteRoot.position;
		}
		if (rightBottonUI.isActiveAndEnabled)
		{
			rightBottonUI.transform.position = unitB.spriteRoot.position;
		}
		_actionCam.transform.position = Vector3.Lerp(_actionCam.transform.position, b, Time.deltaTime * 5f);
		if (_bWaitPlayerRolling)
		{
			_elapsedCamMoving += Time.deltaTime * 0.1f;
			Vector3 eulerAngles = _actionCam.transform.localRotation.eulerAngles;
			eulerAngles.y = _camRotCurve_waitRolling.Evaluate(_elapsedCamMoving);
			_actionCam.transform.localRotation = Quaternion.Euler(eulerAngles);
			if (_elapsedCamMoving > 10f)
			{
				_elapsedCamMoving = 0f;
			}
			_elapsedUnitMoving += Time.deltaTime;
			if (_elapsedUnitMoving <= 60f)
			{
				if (_leftUnitResult.unit.model.currentDiceAction?.currentBehavior != null && _leftUnitResult.unit.model.currentDiceAction.currentBehavior.behaviourInCard.Type == BehaviourType.Atk)
				{
					unitA.spriteRoot.Translate(Vector3.right * Time.deltaTime * 0.01f, Space.World);
				}
				if (_rightUnitResult.unit.model.currentDiceAction?.currentBehavior != null && _rightUnitResult.unit.model.currentDiceAction.currentBehavior.behaviourInCard.Type == BehaviourType.Atk)
				{
					unitB.spriteRoot.Translate(Vector3.left * Time.deltaTime * 0.01f, Space.World);
				}
			}
			else
			{
				_elapsedUnitMoving = 100f;
			}
		}
		if (leftBottomUI.gameObject.activeSelf)
		{
			leftBottomUI.SetTargetHp((int)_leftUnitResult.unit.model.hp);
			leftBottomUI.SetTargetBreakGauge(_leftUnitResult.unit.model.breakDetail.breakGauge);
		}
		if (rightBottonUI.gameObject.activeSelf)
		{
			rightBottonUI.SetTargetHp((int)_rightUnitResult.unit.model.hp);
			rightBottonUI.SetTargetBreakGauge(_rightUnitResult.unit.model.breakDetail.breakGauge);
		}
	}
}
