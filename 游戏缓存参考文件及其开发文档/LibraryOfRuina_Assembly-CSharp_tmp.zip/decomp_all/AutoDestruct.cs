using UnityEngine;

public class AutoDestruct : MonoBehaviour
{
	public float time = 0.25f;

	private float _elapsedTime;

	[SerializeField]
	private bool _bDestroyWhenDisable;

	public void DestroyWhenDisable()
	{
		_bDestroyWhenDisable = true;
	}

	private void Start()
	{
	}

	private void Update()
	{
		_elapsedTime += Time.deltaTime;
		if (_elapsedTime > time)
		{
			Object.Destroy(base.gameObject);
		}
	}

	private void OnDisable()
	{
		if (_bDestroyWhenDisable)
		{
			Object.Destroy(base.gameObject);
		}
	}
}
