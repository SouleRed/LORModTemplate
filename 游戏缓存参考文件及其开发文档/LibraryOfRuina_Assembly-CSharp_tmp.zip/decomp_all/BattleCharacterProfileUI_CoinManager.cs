using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleCharacterProfileUI_CoinManager : MonoBehaviour
{
	public float defaultWidth;

	public float spacing;

	public List<BattleCharacterProfileUI_Coin> coinList;

	public void Init(BattleUnitModel unit)
	{
		int count = unit.emotionDetail.NegativeCoins.Count;
		int count2 = unit.emotionDetail.PositiveCoins.Count;
		for (int i = 0; i < coinList.Count; i++)
		{
			Image coinImg = coinList[i].coinImg;
			if (i < count)
			{
				coinImg.enabled = true;
				coinImg.color = SingletonBehavior<BattleManagerUI>.Instance.negativeCoinColor;
			}
			else if (i < count + count2)
			{
				coinImg.enabled = true;
				coinImg.color = SingletonBehavior<BattleManagerUI>.Instance.positiveCoinColor;
			}
			else
			{
				coinImg.enabled = false;
			}
		}
	}

	public Image OnAcquireCoin(bool isPositive, int negativeIdx, int positiveIdx)
	{
		Image result = null;
		for (int i = 0; i < coinList.Count; i++)
		{
			Image coinImg = coinList[i].coinImg;
			if (i < negativeIdx)
			{
				coinImg.enabled = true;
				coinImg.color = SingletonBehavior<BattleManagerUI>.Instance.negativeCoinColor;
				if (!isPositive)
				{
					result = coinImg;
				}
			}
			else if (i < negativeIdx + positiveIdx)
			{
				coinImg.enabled = true;
				coinImg.color = SingletonBehavior<BattleManagerUI>.Instance.positiveCoinColor;
				if (isPositive)
				{
					result = coinImg;
				}
			}
			else
			{
				coinImg.enabled = false;
			}
		}
		return result;
	}

	public void UpdateCoins(BattleUnitModel unit)
	{
		int maximumCoinNumber = unit.emotionDetail.MaximumCoinNumber;
		if (maximumCoinNumber > 0)
		{
			_ = unit.emotionDetail.PositiveCoins;
			IList<EmotionCoin> negativeCoins = unit.emotionDetail.NegativeCoins;
			float width = (defaultWidth + spacing * (float)(maximumCoinNumber - 1)) / (float)maximumCoinNumber;
			for (int i = 0; i < coinList.Count; i++)
			{
				BattleCharacterProfileUI_Coin battleCharacterProfileUI_Coin = coinList[i];
				battleCharacterProfileUI_Coin.Set(width, (i < negativeCoins.Count) ? SingletonBehavior<BattleManagerUI>.Instance.negativeCoinColor : SingletonBehavior<BattleManagerUI>.Instance.positiveCoinColor);
				battleCharacterProfileUI_Coin.gameObject.SetActive(i < maximumCoinNumber);
			}
		}
	}

	public void SetDefaultCoinScale()
	{
		foreach (BattleCharacterProfileUI_Coin coin in coinList)
		{
			coin.SetDefaultImgScale();
		}
	}
}
