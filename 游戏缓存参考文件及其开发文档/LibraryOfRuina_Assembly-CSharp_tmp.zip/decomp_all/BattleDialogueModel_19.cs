using LOR_XML;

public class BattleDialogueModel_19 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_19(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Hokma";
		_characterId_RB1 = "H_P_Librarian_";
		_stageId_RB1 = 70009;
		_characterId_BS = "Ho_Librarian";
		_sephirahType = SephirahType.Hokma;
		_characterId_RB2 = _characterId_BS;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (Singleton<StageController>.Instance.GetStageModel().ClassInfo.id == _stageId_RB1 && dlgType == DialogType.BATTLE_VICTORY)
		{
			result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
		}
		return result;
	}
}
