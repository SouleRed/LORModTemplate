using UnityEngine;

public class BattleAttackEffectTester : MonoBehaviour
{
	public Transform self;

	public Transform target;

	public GameObject[] atkEffects;

	public AttackType at;

	private float elapsed;

	private void Start()
	{
	}

	private void Update()
	{
		elapsed += Time.deltaTime;
		if (elapsed > 0.5f)
		{
			Direction unitDir = ((!(self.position.x > target.position.x)) ? Direction.RIGHT : Direction.LEFT);
			CreateAtkEffect(unitDir, target.position - self.position);
			elapsed = 0f;
		}
	}

	private void OnGUI()
	{
		if (GUI.Button(new Rect(Screen.width - 160, Screen.height - 160, 150f, 100f), "Make Atk Effect"))
		{
			Direction unitDir = ((!(self.position.x > target.position.x)) ? Direction.RIGHT : Direction.LEFT);
			CreateAtkEffect(unitDir, target.position - self.position);
		}
	}

	private void CreateAtkEffect(Direction unitDir, Vector3 atkDir)
	{
		GameObject gameObject = null;
		GameObject obj = Object.Instantiate(at switch
		{
			AttackType.Hori => atkEffects[0], 
			AttackType.Vert => atkEffects[1], 
			AttackType.Stab => atkEffects[2], 
			_ => atkEffects[0], 
		}, self);
		obj.SetActive(value: true);
		obj.transform.right = -atkDir;
		obj.transform.Translate(0f, 0.5f, 0f);
	}
}
