using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class AssetBundleManagerRemake : Singleton<AssetBundleManagerRemake>
{
	public class AssetResourceCacheData
	{
		public AssetBundle asset;

		public string name;

		public GameObject resObject;

		public int refCount;
	}

	private AssetBundle _cardAssetBundle;

	private Dictionary<string, AssetResourceCacheData> _characterResourceCache = new Dictionary<string, AssetResourceCacheData>();

	public void Init()
	{
	}

	public void UnloadAllCharacterCache()
	{
		foreach (KeyValuePair<string, AssetResourceCacheData> item in _characterResourceCache)
		{
			item.Value.asset.Unload(unloadAllLoadedObjects: true);
		}
		_characterResourceCache.Clear();
	}

	private static string GetAssetPath(string name)
	{
		return Path.Combine(Application.streamingAssetsPath, "AssetBundles", name);
	}

	private static string GetCharacterResourcePath(int id)
	{
		return Path.Combine(Application.streamingAssetsPath, "AssetBundles", "char", "char_" + id + ".pres");
	}

	public void LoadCardAssetBundle()
	{
		if (!(_cardAssetBundle != null))
		{
			_cardAssetBundle = AssetBundle.LoadFromFile(GetAssetPath("card_art.pres"));
		}
	}

	public Sprite LoadCardSprite(string name)
	{
		if (_cardAssetBundle == null)
		{
			LoadCardAssetBundle();
		}
		if (_cardAssetBundle == null)
		{
			return null;
		}
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		return _cardAssetBundle.LoadAsset<Sprite>(name);
	}

	private GameObject GetSdResourceObject(string resourceName)
	{
		if (_characterResourceCache.TryGetValue(resourceName, out var value))
		{
			value.refCount++;
			return value.resObject;
		}
		int id = Singleton<ResourceInfoManager>.Instance.GetId(resourceName);
		if (id == -1)
		{
			return null;
		}
		value = new AssetResourceCacheData();
		AssetBundle assetBundle = AssetBundle.LoadFromFile(GetCharacterResourcePath(id));
		if (assetBundle == null)
		{
			return null;
		}
		GameObject gameObject = assetBundle.LoadAsset<GameObject>(resourceName);
		if (gameObject == null)
		{
			Debug.LogError("load asset failed : " + resourceName);
			assetBundle.Unload(unloadAllLoadedObjects: true);
			return null;
		}
		value.asset = assetBundle;
		value.name = resourceName;
		value.refCount = 1;
		value.resObject = gameObject;
		_characterResourceCache.Add(resourceName, value);
		return value.resObject;
	}

	public void ReleaseSdObject(string resourceName)
	{
		if (_characterResourceCache.TryGetValue(resourceName, out var value))
		{
			value.refCount--;
			if (value.refCount <= 0)
			{
				value.asset.Unload(unloadAllLoadedObjects: true);
				_characterResourceCache.Remove(resourceName);
			}
		}
	}

	public GameObject LoadSdPrefab(string resourceNAme)
	{
		GameObject gameObject = GetSdResourceObject(resourceNAme);
		if (gameObject == null)
		{
			Debug.LogError("sd not found : " + resourceNAme);
			gameObject = Resources.Load<GameObject>("Prefabs/Characters/[Prefab]Appearance_Custom");
		}
		return gameObject;
	}

	public GameObject LoadCharacterPrefab(string charName, string s, out string resourceName)
	{
		GameObject gameObject = null;
		string text = "[Prefab]Appearance_" + charName + s;
		gameObject = GetSdResourceObject(text);
		if (gameObject == null)
		{
			text = "[Prefab]Appearance_" + charName;
			gameObject = GetSdResourceObject(text);
			if (gameObject == null)
			{
				text = "[Prefab]Appearance_" + charName + "_N";
				gameObject = GetSdResourceObject(text);
			}
		}
		if (gameObject != null)
		{
			resourceName = text;
		}
		else
		{
			resourceName = "";
		}
		if (gameObject == null)
		{
			gameObject = (GameObject)Resources.Load("Prefabs/Characters/[Prefab]Appearance_" + charName + s);
			if (gameObject == null)
			{
				gameObject = (GameObject)Resources.Load("Prefabs/Characters/[Prefab]Appearance_" + charName);
				if (gameObject == null)
				{
					gameObject = (GameObject)Resources.Load("Prefabs/Characters/[Prefab]Appearance_" + charName + "_N");
				}
			}
		}
		if (gameObject == null)
		{
			gameObject = Resources.Load<GameObject>("Prefabs/Characters/[Prefab]Appearance_Custom");
		}
		return gameObject;
	}

	public GameObject LoadCharacterPrefab_DefaultMotion(string charName, string s, out string resName)
	{
		GameObject gameObject = null;
		string[] obj = new string[3]
		{
			"[Prefab]DefaultMotion_" + charName + s,
			"[Prefab]DefaultMotion_" + charName,
			"[Prefab]DefaultMotion_" + charName + "_N"
		};
		resName = "";
		string[] array = obj;
		foreach (string text in array)
		{
			GameObject sdResourceObject = GetSdResourceObject(text);
			if (sdResourceObject != null)
			{
				gameObject = sdResourceObject;
				resName = text;
				break;
			}
		}
		if (gameObject == null)
		{
			gameObject = Resources.Load<GameObject>("Prefabs/Characters/[Prefab]Appearance_Custom");
		}
		return gameObject;
	}

	public GameObject LoadCharacterPrefab_DefaultMotion_Nullable(string charName, string s, out string resName)
	{
		GameObject result = null;
		string[] obj = new string[3]
		{
			"[Prefab]DefaultMotion_" + charName + s,
			"[Prefab]DefaultMotion_" + charName,
			"[Prefab]DefaultMotion_" + charName + "_N"
		};
		resName = "";
		string[] array = obj;
		foreach (string text in array)
		{
			GameObject sdResourceObject = GetSdResourceObject(text);
			if (sdResourceObject != null)
			{
				result = sdResourceObject;
				resName = text;
				break;
			}
		}
		return result;
	}
}
