using System.Collections;
using System.Collections.Generic;
using LOR_XML;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BattleActUI : MonoBehaviour
{
	public bool isAnimPlaying;

	[SerializeField]
	private Image img_bgMask;

	[SerializeField]
	private Image frame;

	[SerializeField]
	private Image bg;

	[SerializeField]
	private Image img_textShape;

	[SerializeField]
	private TextMeshProUGUI txtActTitle;

	[SerializeField]
	private TextMeshProUGUI txtActNumber;

	[SerializeField]
	private Animator animator;

	private bool _bAppear;

	public void StartAct(int actLv, List<BattleUnitModel> unitList)
	{
		SingletonBehavior<BattleSoundManager>.Instance.PlaySound(EffectSoundType.ROUND_START);
		string text = TextDataModel.GetText("BattleUI_StartBattle_Act", actLv);
		txtActNumber.text = text;
		string text2 = "Unknown";
		switch (Singleton<StageController>.Instance.CurrentFloor)
		{
		case SephirahType.Malkuth:
			text2 = TextDataModel.GetText("ui_malkuthfloor");
			break;
		case SephirahType.Yesod:
			text2 = TextDataModel.GetText("ui_yesodfloor");
			break;
		case SephirahType.Hod:
			text2 = TextDataModel.GetText("ui_hodfloor");
			break;
		case SephirahType.Netzach:
			text2 = TextDataModel.GetText("ui_netzachfloor");
			break;
		case SephirahType.Tiphereth:
			text2 = TextDataModel.GetText("ui_tipherethfloor");
			break;
		case SephirahType.Chesed:
			text2 = TextDataModel.GetText("ui_chesedfloor");
			break;
		case SephirahType.Gebura:
			text2 = TextDataModel.GetText("ui_geburafloor");
			break;
		case SephirahType.Hokma:
			text2 = TextDataModel.GetText("ui_hokmafloor");
			break;
		case SephirahType.Binah:
			text2 = TextDataModel.GetText("ui_binahfloor");
			break;
		case SephirahType.Keter:
			text2 = TextDataModel.GetText("ui_keterfloor");
			break;
		}
		string empty = string.Empty;
		empty = ((Singleton<StageController>.Instance.stageType != StageType.Invitation) ? TextDataModel.GetText("BattleUI_StartBattle_WaveInfo", Singleton<StageController>.Instance.CurrentWave) : TextDataModel.GetText("BattleUI_StartBattle_WaveInfo", Singleton<StageController>.Instance.CurrentWave));
		txtActTitle.text = text2 + " - " + empty;
		animator.gameObject.SetActive(value: true);
		_bAppear = false;
		animator.ResetTrigger("Appear");
		animator.ResetTrigger("Disappear");
		animator.SetTrigger("Appear");
		isAnimPlaying = true;
		StartCoroutine(AnimRoutine(actLv, unitList));
	}

	public void OnAppearAnimEnd()
	{
		_bAppear = true;
	}

	public void OnDisappearAnimEnd()
	{
		_bAppear = false;
		isAnimPlaying = false;
	}

	private void Start()
	{
		SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txtActTitle, FontType.FONT_HEAD);
		SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txtActNumber, FontType.FONT_HEAD);
	}

	private void OnEnable()
	{
		SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txtActTitle, FontType.FONT_HEAD);
		SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txtActNumber, FontType.FONT_HEAD);
	}

	private IEnumerator AnimRoutine(int actLv, List<BattleUnitModel> unitList)
	{
		yield return new WaitUntil(() => _bAppear);
		animator.SetTrigger("Disappear");
		yield return new WaitUntil(() => !_bAppear);
		EndActAnim(actLv, unitList);
	}

	public void EndActAnim(int actLv, List<BattleUnitModel> unitList)
	{
		isAnimPlaying = false;
		animator.gameObject.SetActive(value: false);
		if (actLv != 1)
		{
			return;
		}
		foreach (BattleUnitModel unit in unitList)
		{
			List<BattleUnitModel> aliveList = BattleObjectManager.instance.GetAliveList((unit.faction != Faction.Player) ? Faction.Player : Faction.Enemy);
			unit.view.DisplayDlg(DialogType.START_BATTLE, aliveList);
		}
	}

	private IEnumerator FadeAct(int actLv, List<BattleUnitModel> unitList)
	{
		string text = "제 " + actLv + "막";
		txtActNumber.text = text;
		frame.enabled = true;
		bg.enabled = true;
		txtActTitle.enabled = true;
		txtActNumber.enabled = true;
		float elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 2f;
			Color color = frame.color;
			Color color2 = bg.color;
			Color color3 = txtActTitle.color;
			Color color4 = txtActNumber.color;
			color.a = elapsed;
			color2.a = elapsed;
			color3.a = elapsed;
			color4.a = elapsed;
			frame.color = color;
			bg.color = color2;
			txtActTitle.color = color3;
			txtActNumber.color = color4;
			yield return YieldCache.waitFrame;
		}
		yield return YieldCache.WaitForSeconds(1f);
		elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime;
			Color color5 = frame.color;
			Color color6 = bg.color;
			Color color7 = txtActTitle.color;
			Color color8 = txtActNumber.color;
			color5.a = 1f - elapsed;
			color6.a = 1f - elapsed;
			color7.a = 1f - elapsed;
			color8.a = 1f - elapsed;
			frame.color = color5;
			bg.color = color6;
			txtActTitle.color = color7;
			txtActNumber.color = color8;
			yield return YieldCache.waitFrame;
		}
		frame.enabled = false;
		bg.enabled = false;
		txtActTitle.enabled = false;
		txtActNumber.enabled = false;
	}
}
