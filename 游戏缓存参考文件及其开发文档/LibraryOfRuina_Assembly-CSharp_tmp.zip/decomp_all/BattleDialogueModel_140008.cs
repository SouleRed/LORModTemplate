using LOR_XML;

public class BattleDialogueModel_140008 : BattleDialogueModel
{
	private bool _bCheckNoahDead;

	public BattleDialogueModel_140008(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bCheckNoahDead = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		switch (dlgType)
		{
		case DialogType.BATTLE_VICTORY:
			result = ((!_bCheckNoahDead) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_" + RandomUtil.Range(0, 1)) : GetBattleDlgSpecialEvent("SPECIAL_EVENT_2"));
			break;
		case DialogType.COLLEAGUE_DEATH:
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 140010);
			if (battleUnitModel != null && battleUnitModel.IsDead() && !_bCheckNoahDead)
			{
				_bCheckNoahDead = true;
			}
			break;
		}
		case DialogType.KILLS_OPPONENT:
			result = ((!_bCheckNoahDead) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_" + RandomUtil.Range(3, 6)) : GetBattleDlgSpecialEvent("SPECIAL_EVENT_" + RandomUtil.Range(7, 9)));
			break;
		}
		return result;
	}
}
