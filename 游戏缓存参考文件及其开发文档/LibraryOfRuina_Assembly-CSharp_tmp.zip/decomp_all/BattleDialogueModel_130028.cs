using LOR_XML;

public class BattleDialogueModel_130028 : BattleDialogueModel
{
	public BattleDialogueModel_130028(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.DEATH)
		{
			result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
		}
		return result;
	}
}
