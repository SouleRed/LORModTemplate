using LOR_XML;

public class BattleDialogueModel_150029 : BattleDialogueModel
{
	public BattleDialogueModel_150029(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		return base.GetBattleDlg(dlgType);
	}
}
