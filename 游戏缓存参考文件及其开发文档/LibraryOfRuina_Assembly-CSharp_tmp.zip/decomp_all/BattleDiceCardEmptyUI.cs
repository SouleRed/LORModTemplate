using UnityEngine;

public class BattleDiceCardEmptyUI : MonoBehaviour
{
}
