using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_130007 : BattleDialogueModel
{
	private bool _bCheckYunaDead;

	private bool _bCheckPhilipDead;

	public BattleDialogueModel_130007(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bCheckPhilipDead = false;
		_bCheckYunaDead = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = string.Empty;
		switch (dlgType)
		{
		case DialogType.COLLEAGUE_DEATH:
		{
			List<BattleUnitModel> list = BattleObjectManager.instance.GetList(Faction.Enemy);
			BattleUnitModel battleUnitModel = list.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130008);
			BattleUnitModel battleUnitModel2 = list.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130009);
			if (battleUnitModel2 == null)
			{
				_bCheckPhilipDead = true;
			}
			if (battleUnitModel == null)
			{
				_bCheckYunaDead = true;
			}
			if (battleUnitModel2 != null && battleUnitModel2.IsDead() && !_bCheckPhilipDead)
			{
				_bCheckPhilipDead = true;
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_4");
			}
			if (battleUnitModel != null && battleUnitModel.IsDead() && !_bCheckYunaDead)
			{
				_bCheckYunaDead = true;
				result = ((!_bCheckPhilipDead) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_2") : GetBattleDlgSpecialEvent("SPECIAL_EVENT_3"));
			}
			break;
		}
		case DialogType.DEATH:
			result = ((!_bCheckYunaDead) ? base.GetBattleDlg(dlgType) : GetBattleDlgSpecialEvent("SPECIAL_EVENT_1"));
			break;
		case DialogType.BATTLE_VICTORY:
			result = ((!_bCheckYunaDead || !_bCheckPhilipDead) ? base.GetBattleDlg(dlgType) : GetBattleDlgSpecialEvent("SPECIAL_EVENT_0"));
			break;
		default:
			result = base.GetBattleDlg(dlgType);
			break;
		}
		return result;
	}
}
