using UnityEngine;

public class AutoDisable : MonoBehaviour
{
	public bool ActiveAtStart;

	public float time = 1f;

	private float _elapsedTime;

	private void Start()
	{
		base.gameObject.SetActive(ActiveAtStart);
	}

	private void OnEnable()
	{
		_elapsedTime = 0f;
	}

	private void Update()
	{
		_elapsedTime += Time.deltaTime;
		if (_elapsedTime > time)
		{
			base.gameObject.SetActive(value: false);
		}
	}
}
