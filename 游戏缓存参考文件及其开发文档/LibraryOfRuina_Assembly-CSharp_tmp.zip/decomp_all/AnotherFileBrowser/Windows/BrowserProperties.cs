namespace AnotherFileBrowser.Windows;

public class BrowserProperties
{
	public string title;

	public string initialDir;

	public string filter;

	public int filterIndex;

	public bool restoreDirectory = true;

	public BrowserProperties()
	{
	}

	public BrowserProperties(string title)
	{
		this.title = title;
	}
}
