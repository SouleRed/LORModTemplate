using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Ookii.Dialogs;
using UnityEngine;

namespace AnotherFileBrowser.Windows;

public class FileBrowser
{
	[DllImport("user32.dll")]
	private static extern IntPtr GetActiveWindow();

	public void OpenFileBrowser(BrowserProperties browserProperties, Action<string> filepath)
	{
		VistaOpenFileDialog vistaOpenFileDialog = new VistaOpenFileDialog();
		vistaOpenFileDialog.Multiselect = false;
		vistaOpenFileDialog.Title = ((browserProperties.title == null) ? "Select a File" : browserProperties.title);
		vistaOpenFileDialog.InitialDirectory = ((browserProperties.initialDir == null) ? "C:\\" : browserProperties.initialDir);
		vistaOpenFileDialog.Filter = ((browserProperties.filter == null) ? "All files (*.*)|*.*" : browserProperties.filter);
		vistaOpenFileDialog.FilterIndex = browserProperties.filterIndex + 1;
		vistaOpenFileDialog.RestoreDirectory = browserProperties.restoreDirectory;
		if (vistaOpenFileDialog.ShowDialog(new WindowWrapper(GetActiveWindow())) == DialogResult.OK)
		{
			Debug.Log(vistaOpenFileDialog.InitialDirectory);
			filepath(vistaOpenFileDialog.FileName);
		}
	}

	public void OpenMultiSelectFileBrowser(BrowserProperties browserProperties, Action<string[]> filepath)
	{
		VistaOpenFileDialog vistaOpenFileDialog = new VistaOpenFileDialog();
		vistaOpenFileDialog.Multiselect = true;
		vistaOpenFileDialog.Title = ((browserProperties.title == null) ? "Select a File" : browserProperties.title);
		vistaOpenFileDialog.InitialDirectory = ((browserProperties.initialDir == null) ? "C:\\" : browserProperties.initialDir);
		vistaOpenFileDialog.Filter = ((browserProperties.filter == null) ? "All files (*.*)|*.*" : browserProperties.filter);
		vistaOpenFileDialog.FilterIndex = browserProperties.filterIndex + 1;
		vistaOpenFileDialog.RestoreDirectory = browserProperties.restoreDirectory;
		if (vistaOpenFileDialog.ShowDialog(new WindowWrapper(GetActiveWindow())) == DialogResult.OK)
		{
			filepath(vistaOpenFileDialog.FileNames);
		}
	}

	public void OpenFolderBrowser(BrowserProperties browserProperties, Action<string> folderpath)
	{
		VistaFolderBrowserDialog vistaFolderBrowserDialog = new VistaFolderBrowserDialog();
		vistaFolderBrowserDialog.Description = browserProperties.title;
		vistaFolderBrowserDialog.UseDescriptionForTitle = true;
		if (vistaFolderBrowserDialog.ShowDialog(new WindowWrapper(GetActiveWindow())) == DialogResult.OK)
		{
			folderpath(vistaFolderBrowserDialog.SelectedPath);
		}
	}

	public void SaveFileBrowser(BrowserProperties browserProperties, string defaultFileName, string defaultExt, Action<string> savepath)
	{
		VistaSaveFileDialog vistaSaveFileDialog = new VistaSaveFileDialog();
		vistaSaveFileDialog.FileName = defaultFileName;
		vistaSaveFileDialog.DefaultExt = defaultExt;
		vistaSaveFileDialog.CheckPathExists = true;
		vistaSaveFileDialog.OverwritePrompt = true;
		vistaSaveFileDialog.Title = browserProperties.title;
		vistaSaveFileDialog.InitialDirectory = ((browserProperties.initialDir == null) ? "C:\\" : browserProperties.initialDir);
		vistaSaveFileDialog.Filter = browserProperties.filter;
		vistaSaveFileDialog.FilterIndex = browserProperties.filterIndex + 1;
		vistaSaveFileDialog.RestoreDirectory = browserProperties.restoreDirectory;
		if (vistaSaveFileDialog.ShowDialog(new WindowWrapper(GetActiveWindow())) == DialogResult.OK)
		{
			savepath(vistaSaveFileDialog.FileName);
		}
	}
}
