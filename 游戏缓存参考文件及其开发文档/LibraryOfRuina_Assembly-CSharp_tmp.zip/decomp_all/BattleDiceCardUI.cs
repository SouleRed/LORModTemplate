using System.Collections;
using System.Collections.Generic;
using LOR_BattleUnit_UI;
using LOR_DiceSystem;
using TMPro;
using UI;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BattleDiceCardUI : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, IPointerDownHandler, IDragHandler, IEndDragHandler
{
	public enum Option
	{
		HideDiceAbilityInfo
	}

	public enum ClickableState
	{
		CanClick_emotion,
		CanClick,
		CannotClick,
		NotEnoughCost,
		NoTarget
	}

	[Header("Resource")]
	[SerializeField]
	private RectTransform vibeRect;

	[SerializeField]
	private Sprite[] costNumberSprite;

	[Header("Color")]
	[SerializeField]
	private Color[] refColors_Cost;

	[Header("References")]
	public TextMeshProUGUI txt_cardName;

	public Image[] img_Frames;

	public Image[] img_linearDodges;

	public GameObject selfAbilityArea;

	public TextMeshProUGUI txt_selfAbility;

	public List<BattleDiceCard_BehaviourDescUI> ui_behaviourDescList;

	public List<Image> img_behaviourDetatilList;

	public Animator anim;

	public Image img_artwork;

	public Image img_icon;

	public RefineHsv hsv_rangeIcon;

	[SerializeField]
	private RefineHsv hsv_Cost;

	private float _glowElapsedTime;

	[Header("added icons")]
	public BattleDiceCardBufUI[] bufIconListUI;

	[Header("Keyword")]
	public KeywordListUI KeywordListUI;

	[Header("Resist")]
	[SerializeField]
	private List<RefineHsv> hsv_behaviourIcons;

	[SerializeField]
	private List<TextMeshProUGUI> txt_Resist;

	[SerializeField]
	private List<TextMeshProUGUI> txt_bpResist;

	[Header("Frames")]
	[SerializeField]
	private GameObject[] ob_NormalFrames;

	[SerializeField]
	private GameObject[] ob_EgoFrames;

	[Header("Pad")]
	public UICustomSelectable selectable;

	[Header("Other Card")]
	public bool isProfileCard;

	[SerializeField]
	private bool isEmotionSelectedPopup;

	[HideInInspector]
	public Canvas _parentCanvas;

	private Transform mouseTransform;

	private int _defaultIdx;

	private BattleDiceCardModel _cardModel;

	private bool _bClicked;

	private bool _bAvailable;

	private bool _bFirstClicked;

	private bool _bEntered;

	private BattleUnitTargetArrowUI arrow;

	private Color colorFrame;

	private Color colorLineardodge;

	private Color colorLineardodge_deactive;

	public Vector3 scaleOrigin;

	[SerializeField]
	private NumbersData costNumbers;

	private int _cost;

	private int _originCost;

	private bool _editor;

	private bool isRunningVibeCard;

	private float vibeCounter;

	private Vector2 rangeIconOriginPos = new Vector2(305f, 189f);

	private Vector2 rangeIconEgoPos = new Vector2(335f, 189f);

	private EmotionEgoXmlInfo egoxmldata;

	[Header("Ego Gauge")]
	[SerializeField]
	private GameObject ob_EgoCoolTime;

	[SerializeField]
	private RectTransform rect_Gauge;

	[SerializeField]
	private Image img_Bg;

	[SerializeField]
	private Image img_BgGlow;

	[SerializeField]
	private RefineHsv hsv_bgGlow;

	[SerializeField]
	private Animator anim_gaugebgglow;

	[SerializeField]
	private Graphic[] graphics_EgoLockFrames;

	[SerializeField]
	private RefineHsv[] hsv_EgoLockFrames;

	private bool isEgoCoolTimeLock;

	private readonly float gaugeLength = 950f;

	public BattleDiceCardModel CardModel => _cardModel;

	public bool IsClicked => _bClicked;

	public bool IsEntered => _bEntered;

	public EmotionEgoXmlInfo EgoXmlData => egoxmldata;

	public void EditorMode()
	{
		_editor = true;
		base.transform.localScale = (scaleOrigin = new Vector3(1f, 1f, 1f));
		anim?.SetBool("hOvered", value: true);
	}

	public void OnDrag(PointerEventData eventData)
	{
	}

	public void OnEndDrag(PointerEventData eventData)
	{
	}

	private IEnumerator VibeCard(float time)
	{
		isRunningVibeCard = true;
		_ = base.transform.localPosition;
		vibeCounter = 0f;
		while (vibeCounter <= time)
		{
			vibeCounter += TimeManager.GetUIDeltaTime();
			vibeRect.localPosition = Random.insideUnitSphere * ((!IsEntered) ? (5f / vibeCounter) : (((double)vibeCounter < 0.1) ? 50f : (10f / vibeCounter)));
			yield return YieldCache.waitFrame;
		}
		isRunningVibeCard = false;
	}

	public void OnPointerDown(PointerEventData eventData)
	{
		OnPdSubmit(eventData);
	}

	public void OnPdSubmit(BaseEventData data)
	{
		if (UIControlManager.GetInpuTypeOf(data) == InputType.ControllerInput || data is PointerEventData { button: PointerEventData.InputButton.Left })
		{
			switch (GetClickableState())
			{
			case ClickableState.CanClick_emotion:
				SingletonBehavior<BattleManagerUI>.Instance.ui_levelup.OnSelectEgoCard(this);
				break;
			case ClickableState.CanClick:
				OnClick();
				break;
			case ClickableState.NotEnoughCost:
				PlayVibeCard();
				break;
			case ClickableState.NoTarget:
				PlayVibeCard();
				break;
			case ClickableState.CannotClick:
				PlayVibeCard();
				break;
			}
		}
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		ShowDetail();
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		HideDetail();
	}

	public void OnPdCursorEnter()
	{
		ShowDetail();
	}

	public void OnPdCursorExit()
	{
		HideDetail();
	}

	public void ShowDetail()
	{
		if (isProfileCard || _editor || SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.IsCardSelected())
		{
			return;
		}
		if (!isEmotionSelectedPopup && _cardModel != null && _cardModel.XmlData.IsEgo())
		{
			if (isEgoCoolTimeLock)
			{
				return;
			}
			if (_cardModel.XmlData.IsFloorEgo())
			{
				if (!Singleton<SpecialCardListModel>.Instance.ExistEgoCardHand(_cardModel))
				{
					return;
				}
			}
			else
			{
				_cardModel.XmlData.IsPersonal();
			}
		}
		_bEntered = true;
		anim?.SetBool("hOvered", value: true);
		if (!isEmotionSelectedPopup)
		{
			base.transform.SetSiblingIndex(base.transform.parent.childCount - 1);
			SetCostHightlighted(CardModel.GetCost());
			KeywordListUI.Activate();
		}
		base.transform.localScale = scaleOrigin * 1.25f;
		SetLinearDodgeColor(activated: true);
		SingletonBehavior<BattleSoundManager>.Instance.PlaySound(EffectSoundType.CARD_OVER);
		KeywordListUI.Init(CardModel.XmlData, CardModel.GetBehaviourList());
	}

	public void HideDetail()
	{
		if (!isProfileCard && !_editor && !SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.IsCardSelected())
		{
			_bEntered = false;
			SetLinearDodgeColor(activated: false);
			anim?.SetBool("hOvered", value: false);
			KeywordListUI.Deactivate();
			base.transform.SetSiblingIndex(_defaultIdx);
			base.transform.localScale = scaleOrigin;
			SetCostHightlighted(0);
			KeywordListUI.Deactivate();
		}
	}

	public bool IsActivatedObject()
	{
		return base.gameObject.activeSelf;
	}

	public ClickableState GetClickableState()
	{
		if (isEmotionSelectedPopup)
		{
			return ClickableState.CanClick_emotion;
		}
		if (isProfileCard)
		{
			return ClickableState.CannotClick;
		}
		if (Singleton<StageController>.Instance.Phase == StageController.StagePhase.RoundStartPhase_System)
		{
			return ClickableState.CannotClick;
		}
		if (_editor)
		{
			return ClickableState.CannotClick;
		}
		if (SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SelectedModel.turnState == BattleUnitTurnState.BREAK)
		{
			return ClickableState.CannotClick;
		}
		if (_cardModel == null)
		{
			return ClickableState.CannotClick;
		}
		if (_cardModel.XmlData.IsEgo())
		{
			if (isEgoCoolTimeLock)
			{
				return ClickableState.CannotClick;
			}
			if (_cardModel.XmlData.IsFloorEgo())
			{
				if (!Singleton<SpecialCardListModel>.Instance.ExistEgoCardHand(_cardModel))
				{
					return ClickableState.CannotClick;
				}
			}
			else
			{
				_cardModel.XmlData.IsPersonal();
			}
		}
		if (_bEntered && !_bFirstClicked)
		{
			BattleUnitModel selectedModel = SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SelectedModel;
			if (selectedModel == null)
			{
				return ClickableState.CannotClick;
			}
			if (!selectedModel.CheckCardAvailable(CardModel))
			{
				return ClickableState.NotEnoughCost;
			}
			if (!BattleObjectManager.instance.GetAliveList().Exists(CheckTargetable))
			{
				return ClickableState.NoTarget;
			}
			return ClickableState.CanClick;
		}
		return ClickableState.CannotClick;
	}

	public void PlayVibeCard()
	{
		vibeCounter = 0f;
		if (!isRunningVibeCard)
		{
			StartCoroutine(VibeCard(0.4f));
		}
		SingletonBehavior<BattleSoundManager>.Instance.PlaySound(EffectSoundType.CARD_LOCK);
	}

	public void OnClick()
	{
		BattleUnitModel selectedModel = SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SelectedModel;
		if (selectedModel == null || _cardModel == null)
		{
			return;
		}
		SingletonBehavior<BattleCamManager>.Instance.OnClickCardInHand();
		_bFirstClicked = true;
		SetLinearDodgeColor(activated: true);
		SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SetSelectedCardUI(this);
		((Singleton<StageController>.Instance.AllyFormationDirection == Direction.RIGHT) ? SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformationPlayer : SingletonBehavior<BattleManagerUI>.Instance.ui_unitInformation).OpenUnitInformationBySelectedCard(selectedModel, CardModel);
		base.transform.SetSiblingIndex(base.transform.parent.childCount - 1);
		if (arrow != null)
		{
			if (arrow.gameObject != null)
			{
				Object.Destroy(arrow.gameObject);
			}
			arrow = null;
		}
		SingletonBehavior<BattleSoundManager>.Instance.PlaySound(EffectSoundType.CARD_SELECT);
		SpeedDiceUI selectedAllyDice = SingletonBehavior<BattleManagerUI>.Instance.selectedAllyDice;
		if (selectedAllyDice != null)
		{
			arrow = SingletonBehavior<BattleManagerUI>.Instance.ui_TargetArrow.DrawPreviewTargetLine(selectedAllyDice.transform, mouseTransform, Faction.Player, isParrying: false);
		}
		BattleUIInputController.Instance.UpdateChracterSlots(setFocus: true, CheckTargetable, isCardTarget: true);
		if (SingletonBehavior<BattleTutorialManagerUI>.Instance.IsRunningTutorial && SingletonBehavior<BattleTutorialManagerUI>.Instance.selectCardFuncForTutorial != null)
		{
			SingletonBehavior<BattleTutorialManagerUI>.Instance.selectCardFuncForTutorial();
		}
	}

	private bool CheckTargetable(BattleUnitModel target)
	{
		BattleUnitModel selectedModel = SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SelectedModel;
		if (selectedModel == null)
		{
			return false;
		}
		if (selectedModel == target)
		{
			return false;
		}
		return BattleUnitModel.IsTargetableUnit(_cardModel, selectedModel, target);
	}

	public void SetCard(BattleDiceCardModel cardModel, params Option[] options)
	{
		bool isHide = false;
		if (options.Contains(Option.HideDiceAbilityInfo))
		{
			isHide = true;
		}
		egoxmldata = null;
		_cardModel = cardModel;
		bool flag = _cardModel.XmlData.IsEgo();
		GameObject[] array = ob_NormalFrames;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(!flag);
		}
		array = ob_EgoFrames;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(flag);
		}
		if (LorId.IsModId(cardModel.XmlData.workshopID))
		{
			txt_cardName.text = cardModel.XmlData.workshopName;
		}
		else
		{
			txt_cardName.text = Singleton<BattleCardDescXmlList>.Instance.GetCardName(cardModel.GetTextId());
		}
		SetDefaultPreviewResistText();
		_cost = CardModel.GetCost();
		_originCost = CardModel.GetOriginCost();
		Sprite[] cardCostAddGlow = costNumberSprite;
		if (_cost < _originCost || _cost > _originCost)
		{
			cardCostAddGlow = UISpriteDataManager.instance.CardCostAddGlow;
		}
		costNumbers.SetOneValue(CardModel.GetCost(), cardCostAddGlow);
		Sprite rangeIconSprite = UISpriteDataManager.instance.GetRangeIconSprite(cardModel.GetSpec().Ranged);
		img_icon.sprite = rangeIconSprite;
		img_icon.rectTransform.anchoredPosition = (flag ? rangeIconEgoPos : rangeIconOriginPos);
		List<DiceBehaviour> behaviourList = cardModel.GetBehaviourList();
		int b = 4 - behaviourList.Count;
		int num = 0;
		string text = "";
		text = Singleton<BattleCardDescXmlList>.Instance.GetAbilityDesc(cardModel.GetID());
		if (string.IsNullOrEmpty(text))
		{
			List<string> abilityDesc = Singleton<BattleCardAbilityDescXmlList>.Instance.GetAbilityDesc(cardModel.XmlData);
			if (abilityDesc.Count > 0)
			{
				text = string.Join("\n", abilityDesc);
			}
		}
		else
		{
			string defaultAbilityDescString = Singleton<BattleCardAbilityDescXmlList>.Instance.GetDefaultAbilityDescString(cardModel.XmlData);
			if (!string.IsNullOrEmpty(defaultAbilityDescString))
			{
				text = defaultAbilityDescString + "\n" + text;
			}
		}
		if (!string.IsNullOrEmpty(text))
		{
			selfAbilityArea.SetActive(value: true);
			txt_selfAbility.text = TextUtil.TransformConditionKeyword(text);
			float preferredHeight = txt_selfAbility.preferredHeight;
			num = ((!(preferredHeight < 260f)) ? ((preferredHeight < 480f) ? 1 : ((!(preferredHeight < 700f)) ? 3 : 2)) : 0);
			num = Mathf.Min(num, b);
			RectTransform component = selfAbilityArea.GetComponent<RectTransform>();
			if (component != null)
			{
				switch (num)
				{
				case 3:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 880f);
					break;
				case 2:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 660f);
					break;
				case 1:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 440f);
					break;
				default:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 220f);
					break;
				}
			}
		}
		else
		{
			selfAbilityArea.SetActive(value: false);
		}
		for (int j = 0; j < behaviourList.Count; j++)
		{
			ui_behaviourDescList[j].SetBehaviourInfo(behaviourList[j], cardModel.GetID(), cardModel.GetBehaviourList(), isHide);
			ui_behaviourDescList[j].gameObject.SetActive(value: true);
			Sprite sprite = ((behaviourList[j].Type == BehaviourType.Standby) ? UISpriteDataManager.instance.CardStandbyBehaviourDetailIcons[(int)behaviourList[j].Detail] : UISpriteDataManager.instance._cardBehaviourDetailIcons[(int)behaviourList[j].Detail]);
			img_behaviourDetatilList[j].sprite = sprite;
			img_behaviourDetatilList[j].gameObject.SetActive(value: true);
		}
		for (int k = behaviourList.Count; k < ui_behaviourDescList.Count; k++)
		{
			ui_behaviourDescList[k].gameObject.SetActive(value: false);
			img_behaviourDetatilList[k].gameObject.SetActive(value: false);
		}
		colorFrame = (flag ? UIColorManager.Manager.CardEgoCostColor : UIColorManager.Manager.GetCardRarityColor(cardModel.GetRarity()));
		colorLineardodge = (flag ? UIColorManager.Manager.CardEgoLinearColor : UIColorManager.Manager.GetCardRarityLinearColor(cardModel.GetRarity()));
		colorLineardodge_deactive = colorLineardodge;
		colorLineardodge_deactive.a = 1f;
		hsv_Cost._ValueBrightness = (flag ? 1.5f : 1f);
		hsv_Cost.CallUpdate();
		SetFrameColor(colorFrame);
		SetLinearDodgeColor(colorLineardodge);
		SetRangeIconHsv(flag ? UIColorManager.Manager.CardRangeHsvValue[5] : UIColorManager.Manager.CardRangeHsvValue[(int)_cardModel.GetRarity()]);
		KeywordListUI.Deactivate();
		if (!_editor)
		{
			Sprite sprite2 = null;
			sprite2 = ((!LorId.IsModId(cardModel.XmlData.workshopID)) ? Singleton<AssetBundleManagerRemake>.Instance.LoadCardSprite(cardModel.GetArtworkSrc()) : Singleton<CustomizingCardArtworkLoader>.Instance.GetSpecificArtworkSprite(cardModel.XmlData.workshopID, cardModel.GetArtworkSrc()));
			if (sprite2 != null)
			{
				img_artwork.sprite = sprite2;
			}
			else
			{
				Debug.Log("Can't find sprite");
			}
			isEgoCoolTimeLock = false;
			SetEgoCoolTimeGauge();
			EnableAddedIcons();
		}
	}

	public void SetEgoCardForPopup(EmotionEgoXmlInfo egoxmlinfo)
	{
		egoxmldata = egoxmlinfo;
		BattleDiceCardModel battleDiceCardModel = (_cardModel = BattleDiceCardModel.CreatePlayingCard(ItemXmlDataList.instance.GetCardItem(egoxmlinfo.CardId)));
		isEgoCoolTimeLock = false;
		if (ob_EgoCoolTime != null && ob_EgoCoolTime.activeSelf)
		{
			ob_EgoCoolTime.SetActive(value: false);
		}
		bool flag = _cardModel.XmlData.IsEgo();
		GameObject[] array = ob_NormalFrames;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(value: false);
		}
		array = ob_EgoFrames;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(value: true);
		}
		if (LorId.IsModId(battleDiceCardModel.XmlData.workshopID))
		{
			txt_cardName.text = battleDiceCardModel.XmlData.workshopName;
		}
		else
		{
			txt_cardName.text = Singleton<BattleCardDescXmlList>.Instance.GetCardName(battleDiceCardModel.GetTextId());
		}
		SetDefaultPreviewResistText();
		_cost = CardModel.GetCost();
		_originCost = CardModel.GetOriginCost();
		Sprite[] cardCostAddGlow = costNumberSprite;
		if (_cost < _originCost || _cost > _originCost)
		{
			cardCostAddGlow = UISpriteDataManager.instance.CardCostAddGlow;
		}
		costNumbers.SetOneValue(CardModel.GetCost(), cardCostAddGlow);
		Sprite rangeIconSprite = UISpriteDataManager.instance.GetRangeIconSprite(_cardModel.GetSpec().Ranged);
		img_icon.sprite = rangeIconSprite;
		img_icon.rectTransform.anchoredPosition = rangeIconEgoPos;
		List<DiceBehaviour> behaviourList = battleDiceCardModel.GetBehaviourList();
		int b = 4 - behaviourList.Count;
		int num = 0;
		string text = "";
		text = Singleton<BattleCardDescXmlList>.Instance.GetAbilityDesc(battleDiceCardModel.GetID());
		if (string.IsNullOrEmpty(text))
		{
			List<string> abilityDesc = Singleton<BattleCardAbilityDescXmlList>.Instance.GetAbilityDesc(battleDiceCardModel.XmlData);
			if (abilityDesc.Count > 0)
			{
				text = string.Join("\n", abilityDesc);
			}
		}
		else
		{
			string defaultAbilityDescString = Singleton<BattleCardAbilityDescXmlList>.Instance.GetDefaultAbilityDescString(battleDiceCardModel.XmlData);
			if (!string.IsNullOrEmpty(defaultAbilityDescString))
			{
				text = defaultAbilityDescString + "\n" + text;
			}
		}
		if (!string.IsNullOrEmpty(text))
		{
			selfAbilityArea.SetActive(value: true);
			txt_selfAbility.text = TextUtil.TransformConditionKeyword(text);
			float preferredHeight = txt_selfAbility.preferredHeight;
			num = ((!(preferredHeight < 260f)) ? ((preferredHeight < 480f) ? 1 : ((!(preferredHeight < 700f)) ? 3 : 2)) : 0);
			num = Mathf.Min(num, b);
			RectTransform component = selfAbilityArea.GetComponent<RectTransform>();
			if (component != null)
			{
				switch (num)
				{
				case 3:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 880f);
					break;
				case 2:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 660f);
					break;
				case 1:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 440f);
					break;
				default:
					component.sizeDelta = new Vector2(component.sizeDelta.x, 220f);
					break;
				}
			}
		}
		else
		{
			selfAbilityArea.SetActive(value: false);
		}
		for (int j = 0; j < behaviourList.Count; j++)
		{
			ui_behaviourDescList[j].SetBehaviourInfo(behaviourList[j], battleDiceCardModel.GetID(), battleDiceCardModel.GetBehaviourList());
			ui_behaviourDescList[j].gameObject.SetActive(value: true);
			Sprite sprite = ((behaviourList[j].Type == BehaviourType.Standby) ? UISpriteDataManager.instance.CardStandbyBehaviourDetailIcons[(int)behaviourList[j].Detail] : UISpriteDataManager.instance._cardBehaviourDetailIcons[(int)behaviourList[j].Detail]);
			img_behaviourDetatilList[j].sprite = sprite;
			img_behaviourDetatilList[j].gameObject.SetActive(value: true);
		}
		for (int k = behaviourList.Count; k < ui_behaviourDescList.Count; k++)
		{
			ui_behaviourDescList[k].gameObject.SetActive(value: false);
			img_behaviourDetatilList[k].gameObject.SetActive(value: false);
		}
		colorFrame = UIColorManager.Manager.CardEgoCostColor;
		colorLineardodge = UIColorManager.Manager.CardEgoLinearColor;
		colorLineardodge_deactive = colorLineardodge;
		colorLineardodge_deactive.a = 1f;
		hsv_Cost._ValueBrightness = (flag ? 1.5f : 1f);
		hsv_Cost.CallUpdate();
		SetRangeIconHsv(UIColorManager.Manager.CardRangeHsvValue[5]);
		SetFrameColor(colorFrame);
		SetLinearDodgeColor(colorLineardodge);
		KeywordListUI.Deactivate();
		if (!_editor)
		{
			Sprite sprite2 = null;
			sprite2 = ((!LorId.IsModId(battleDiceCardModel.XmlData.workshopID)) ? Singleton<AssetBundleManagerRemake>.Instance.LoadCardSprite(battleDiceCardModel.GetArtworkSrc()) : Singleton<CustomizingCardArtworkLoader>.Instance.GetSpecificArtworkSprite(battleDiceCardModel.XmlData.workshopID, battleDiceCardModel.GetArtworkSrc()));
			if (sprite2 != null)
			{
				img_artwork.sprite = sprite2;
			}
			else
			{
				Debug.Log("Can't find sprite");
			}
			DisableAddedIcons();
		}
	}

	private void DisableAddedIcons()
	{
		for (int i = 0; i < bufIconListUI.Length; i++)
		{
			bufIconListUI[i].SetEnable(b: false);
		}
	}

	private void EnableAddedIcons()
	{
		List<BattleDiceCardBuf> bufList = _cardModel.GetBufList();
		int num = 0;
		foreach (BattleDiceCardBuf item in bufList)
		{
			if (num >= bufIconListUI.Length)
			{
				break;
			}
			if (!(item.GetBufIcon() == null))
			{
				bufIconListUI[num].SetBufIcon(item);
				bufIconListUI[num].SetEnable(b: true);
				num++;
			}
		}
		for (int i = num; i < bufIconListUI.Length; i++)
		{
			bufIconListUI[i].SetEnable(b: false);
		}
	}

	public void ResetSiblingIndex()
	{
		base.transform.SetSiblingIndex(_defaultIdx);
	}

	public void SetDefault()
	{
		_bFirstClicked = false;
		_bEntered = false;
		SetLinearDodgeColor(activated: false);
		anim?.SetBool("hOvered", value: false);
		KeywordListUI.Deactivate();
		base.transform.localScale = scaleOrigin;
		if (arrow != null)
		{
			if (arrow.gameObject != null)
			{
				Object.Destroy(arrow.gameObject);
			}
			arrow = null;
		}
		SetCostHightlighted(0);
	}

	public void SetLinearDodgeColor(bool activated)
	{
		if (activated)
		{
			SetLinearDodgeColor(colorLineardodge);
		}
		else
		{
			SetLinearDodgeColor(colorLineardodge_deactive);
		}
	}

	private void SetLinearDodgeColor(Color c)
	{
		for (int i = 0; i < img_linearDodges.Length; i++)
		{
			img_linearDodges[i].color = c;
		}
	}

	private void SetFrameColor(Color c)
	{
		for (int i = 0; i < img_Frames.Length; i++)
		{
			img_Frames[i].color = c;
		}
		if (_cost == _originCost)
		{
			costNumbers.SetContentColor(c);
			hsv_Cost._HueShift = 0f;
			hsv_Cost.CallUpdate();
		}
		else if (_cost < _originCost)
		{
			costNumbers.SetContentColor(Color.white);
			hsv_Cost._HueShift = 0f;
			hsv_Cost.CallUpdate();
		}
		else if (_cost > _originCost)
		{
			costNumbers.SetContentColor(Color.white);
			hsv_Cost._HueShift = 150f;
			hsv_Cost.CallUpdate();
		}
	}

	private void SetRangeIconHsv(Vector3 hsvvalue)
	{
		img_icon.color = Color.white;
		if (hsv_rangeIcon == null)
		{
			hsv_rangeIcon = img_icon.GetComponent<RefineHsv>();
		}
		if (hsv_rangeIcon == null)
		{
			Debug.LogError("Hsv Not Reference");
			return;
		}
		hsv_rangeIcon._HueShift = hsvvalue.x;
		hsv_rangeIcon._Saturation = hsvvalue.y;
		hsv_rangeIcon._ValueBrightness = hsvvalue.z;
		hsv_rangeIcon.CallUpdate();
	}

	private void SetCostHightlighted(int cost)
	{
		BattleUnitModel selectedModel = SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.SelectedModel;
		if (selectedModel != null)
		{
			BattlePlayingCardDataInUnitModel battlePlayingCardDataInUnitModel = selectedModel.cardSlotDetail.cardAry[(selectedModel.cardOrder != -1) ? selectedModel.cardOrder : 0];
			selectedModel.view.costUI.SetHightlightedCurrentCostCard(cost, battlePlayingCardDataInUnitModel?.card.GetCost() ?? 0);
		}
	}

	private void Awake()
	{
		_defaultIdx = base.transform.GetSiblingIndex();
		if (SingletonBehavior<BattleManagerUI>.Instance != null)
		{
			mouseTransform = SingletonBehavior<BattleManagerUI>.Instance.ui_unitCardsInHand.mouseFollowingTransform;
		}
		scaleOrigin = base.transform.localScale;
	}

	private void Start()
	{
		string text = Singleton<LocalizedTextLoader>.Instance.CurrentLanguage.ToLower();
		if (text == "cn" || text == "trcn")
		{
			SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txt_cardName, FontType.FONT_HEAD);
		}
		else
		{
			SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txt_cardName, FontType.FONT_BODY);
		}
		SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txt_selfAbility, FontType.FONT_BODY);
	}

	private void OnEnable()
	{
		string text = Singleton<LocalizedTextLoader>.Instance.CurrentLanguage.ToLower();
		if (text == "cn" || text == "trcn")
		{
			SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txt_cardName, FontType.FONT_HEAD);
		}
		else
		{
			SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txt_cardName, FontType.FONT_BODY);
		}
		SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txt_selfAbility, FontType.FONT_BODY);
	}

	private void OnDisable()
	{
		SetDefault();
	}

	private void Update()
	{
		if (base.transform.localScale.magnitude < scaleOrigin.magnitude)
		{
			base.transform.localScale = scaleOrigin;
		}
		if (_cardModel != null)
		{
			_glowElapsedTime += TimeManager.GetUIDeltaTime();
			if (_glowElapsedTime > 1f)
			{
				_glowElapsedTime = 0f;
			}
		}
	}

	public void SetPreviewResist(BattleUnitModel targetunit, BattleDiceCardModel parryingCard = null)
	{
		SetDefaultPreviewResistText();
		if (targetunit == null)
		{
			return;
		}
		List<DiceBehaviour> behaviourList = _cardModel.GetBehaviourList();
		for (int i = 0; i < behaviourList.Count; i++)
		{
			string resistHP_Text = targetunit.GetResistHP_Text(behaviourList[i].Detail);
			txt_Resist[i].text = resistHP_Text;
			AtkResist resistHP = targetunit.GetResistHP(behaviourList[i].Detail);
			float saturation = 1f;
			switch (resistHP)
			{
			case AtkResist.Weak:
				saturation = 1f;
				break;
			case AtkResist.Vulnerable:
				saturation = 0.8f;
				break;
			case AtkResist.Normal:
				saturation = 0.6f;
				break;
			case AtkResist.Endure:
				saturation = 0.4f;
				break;
			case AtkResist.Resist:
				saturation = 0.2f;
				break;
			}
			hsv_behaviourIcons[i]._Saturation = saturation;
			hsv_behaviourIcons[i].CallUpdate();
			string resistBP_Text = targetunit.GetResistBP_Text(behaviourList[i].Detail);
			txt_bpResist[i].text = resistBP_Text;
		}
	}

	public void SetDefaultPreviewResistText()
	{
		foreach (TextMeshProUGUI item in txt_Resist)
		{
			item.text = "";
		}
		foreach (TextMeshProUGUI item2 in txt_bpResist)
		{
			item2.text = "";
		}
		foreach (RefineHsv hsv_behaviourIcon in hsv_behaviourIcons)
		{
			hsv_behaviourIcon._Saturation = 1f;
			hsv_behaviourIcon.CallUpdate();
		}
	}

	public void SetEgoCoolTimeGauge()
	{
		if (ob_EgoCoolTime == null)
		{
			return;
		}
		if (!_cardModel.XmlData.IsEgo())
		{
			ob_EgoCoolTime.SetActive(value: false);
			SetEgoFrameLockColor(on: false);
			return;
		}
		if ((isProfileCard || isEmotionSelectedPopup) && ob_EgoCoolTime != null && ob_EgoCoolTime.activeSelf)
		{
			ob_EgoCoolTime.gameObject.SetActive(value: false);
			return;
		}
		ob_EgoCoolTime.gameObject.SetActive(value: true);
		float num = 0f;
		if (_cardModel.MaxCooltimeValue != 0f)
		{
			num = _cardModel.CurrentCooltimeValue / _cardModel.MaxCooltimeValue;
		}
		if (num >= 1f)
		{
			num = 1f;
			ob_EgoCoolTime.gameObject.SetActive(value: false);
			SetEgoFrameLockColor(on: false);
			return;
		}
		rect_Gauge.anchoredPosition = new Vector2(gaugeLength * num, 0f);
		hsv_bgGlow.CallUpdate();
		if (num < 0.7f)
		{
			Color color = img_BgGlow.color;
			color.a = 1f;
			img_BgGlow.color = color;
			anim_gaugebgglow.enabled = false;
			hsv_bgGlow._ValueBrightness = 0.3f;
			Color white = Color.white;
			white.a = 0.3f;
			img_Bg.color = white;
		}
		else
		{
			hsv_bgGlow._ValueBrightness = num * 1.2f;
			anim_gaugebgglow.enabled = true;
			Color white2 = Color.white;
			white2.a = 0.7f;
			img_Bg.color = white2;
		}
		SetEgoLock();
	}

	public void SetEgoLock()
	{
		isEgoCoolTimeLock = true;
		Color uIColor = UIColorManager.Manager.GetUIColor(UIColor.Disabled);
		SetFrameColor(uIColor);
		SetLinearDodgeColor(uIColor);
		SetEgoFrameLockColor(on: true);
		SetRangeIconHsv(new Vector3(0f, 0f, 1f));
	}

	public void SetEgoFrameLockColor(bool on)
	{
		Color color = (on ? UIColorManager.Manager.GetUIColor(UIColor.Disabled) : Color.white);
		Graphic[] array = graphics_EgoLockFrames;
		foreach (Graphic graphic in array)
		{
			if (!(graphic == null))
			{
				graphic.color = color;
			}
		}
		float saturation = ((!on) ? 1 : 0);
		RefineHsv[] array2 = hsv_EgoLockFrames;
		foreach (RefineHsv obj in array2)
		{
			obj._Saturation = saturation;
			obj.CallUpdate();
		}
		foreach (RefineHsv hsv_behaviourIcon in hsv_behaviourIcons)
		{
			hsv_behaviourIcon._Saturation = saturation;
			hsv_behaviourIcon.CallUpdate();
		}
	}
}
