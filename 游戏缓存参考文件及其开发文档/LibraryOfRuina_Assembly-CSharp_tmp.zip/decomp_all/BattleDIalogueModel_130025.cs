using System.Collections.Generic;
using LOR_XML;

public class BattleDIalogueModel_130025 : BattleDialogueModel
{
	private bool _bCheckPamelaDead;

	private bool _bcheckOscarDead;

	public BattleDIalogueModel_130025(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.COLLEAGUE_DEATH)
		{
			List<BattleUnitModel> list = BattleObjectManager.instance.GetList(Faction.Enemy);
			BattleUnitModel battleUnitModel = list.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130024);
			if (battleUnitModel != null && battleUnitModel.IsDead() && _bCheckPamelaDead)
			{
				_bCheckPamelaDead = true;
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
			BattleUnitModel battleUnitModel2 = list.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130026);
			if (battleUnitModel2 != null && battleUnitModel2.IsDead() && _bcheckOscarDead)
			{
				_bcheckOscarDead = true;
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_1");
			}
		}
		return result;
	}
}
