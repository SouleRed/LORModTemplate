using System.Collections.Generic;

public class BattleBufUIDataList
{
	public List<BattleBufUIData> bufReadyList = new List<BattleBufUIData>();

	public List<BattleBufUIData> bufReadyReadyList = new List<BattleBufUIData>();

	public List<BattleBufUIData> bufActivatedList = new List<BattleBufUIData>();
}
