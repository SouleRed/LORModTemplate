using LOR_DiceSystem;

public class BattleDiceBehaviourUI
{
	public DiceBehaviour behaviourInCard;

	public BattleDiceCardModel cardmodel;

	public bool isDestroyed;

	public DiceUITiming destroyedTiming;

	public bool isSkip;

	public DiceUITiming skipTiming;

	private int _index = -1;

	public bool isRemoveInList;

	public bool isWinAgainstFarAtk;

	public DiceUITiming addedTimingWinAgainstFarAtk;

	public int Index => _index;

	public BattleDiceBehaviourUI(BattleDiceBehavior be)
	{
		behaviourInCard = be.behaviourInCard;
		_index = be.Index;
		cardmodel = be.card.card;
		isDestroyed = be.DiceDestroyed;
		destroyedTiming = be.destroyedTiming;
		isWinAgainstFarAtk = be.winAgainstFarAtk;
		addedTimingWinAgainstFarAtk = DiceUITiming.AttackAfter;
	}

	public BattleDiceBehaviourUI(BattleDiceBehaviourUI be)
	{
		behaviourInCard = be.behaviourInCard;
		_index = be.Index;
		cardmodel = be.cardmodel;
	}

	public void Copy(BattleDiceBehaviourUI b)
	{
		behaviourInCard = b.behaviourInCard;
		isDestroyed = b.isDestroyed;
		isSkip = b.isSkip;
		_index = b.Index;
	}
}
