using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_140003 : BattleDialogueModel
{
	public BattleDialogueModel_140003(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType, List<BattleUnitModel> targets)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.COLLEAGUE_DEATH)
		{
			BattleUnitModel battleUnitModel = targets.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 140001);
			BattleUnitModel battleUnitModel2 = targets.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 140002);
			if (battleUnitModel != null)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_1");
			}
			if (battleUnitModel2 != null)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
		}
		return result;
	}
}
