using UnityEngine;

public class AnimatorEventListener : MonoBehaviour
{
	public BattleUnitView view;

	private void Damge(int id)
	{
		view.Damage(id);
	}

	private void Parrying()
	{
		view.Parrying();
	}
}
