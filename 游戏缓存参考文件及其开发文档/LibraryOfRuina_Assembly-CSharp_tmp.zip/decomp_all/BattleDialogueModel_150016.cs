using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_150016 : BattleDialogueModel
{
	public BattleDialogueModel_150016(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType, List<BattleUnitModel> targets)
	{
		string empty = string.Empty;
		if (dlgType == DialogType.COLLEAGUE_DEATH)
		{
			BattleUnitModel battleUnitModel = targets[0];
			if (battleUnitModel != null)
			{
				LorId enemyUnitId = battleUnitModel.UnitData.unitData.EnemyUnitId;
				if (enemyUnitId == 51001 || enemyUnitId == 51002)
				{
					int num = Random.Range(0, 2);
					return GetBattleDlgSpecialEvent("SPECIAL_EVENT_" + num);
				}
				int num2 = Random.Range(2, 5);
				return GetBattleDlgSpecialEvent("SPECIAL_EVENT_" + num2);
			}
			return base.GetBattleDlg(dlgType);
		}
		return base.GetBattleDlg(dlgType);
	}
}
