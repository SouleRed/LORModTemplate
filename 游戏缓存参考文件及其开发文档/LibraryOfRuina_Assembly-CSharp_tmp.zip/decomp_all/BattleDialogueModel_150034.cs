using LOR_XML;

public class BattleDialogueModel_150034 : BattleDialogueModel
{
	public BattleDialogueModel_150034(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep2", "R_Corp_Rudolph_2_2_Meet_Gebura");
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}
}
