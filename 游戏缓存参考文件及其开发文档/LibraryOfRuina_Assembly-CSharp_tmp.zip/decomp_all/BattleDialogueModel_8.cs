using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_8 : BattleDialogueModel_Sephirah
{
	private bool _bKilledPurpleTear;

	private bool _bKilledOrangeCross;

	private bool _bKillElena;

	private SpecialBattleDialog _specialDialogs;

	public BattleDialogueModel_8(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bKilledPurpleTear = false;
		_bKillElena = false;
		_bKilledOrangeCross = false;
		_specialDialogs = new SpecialBattleDialog();
		_specialDialogs.SetBattleDialog("LibraryOfRuina", "Binah");
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		LorId id = Singleton<StageController>.Instance.GetStageModel().ClassInfo.id;
		if (id == 50009)
		{
			return GetBattleDlg_RedMist(dlgType);
		}
		if (id == 50012)
		{
			return GetBattleDlg_PurpleTear(dlgType);
		}
		if (id == 60007)
		{
			return "";
		}
		if (id == 70008)
		{
			return GetElena1stBattleDlg(dlgType);
		}
		if (id == 60003)
		{
			return GetBattleDlg_BS(dlgType, SephirahType.Binah, "Binah");
		}
		if (id == 60004)
		{
			return GetBattleDlg_RB2(dlgType, SephirahType.Binah, "Binah");
		}
		return GetNormalBattleDlg(dlgType);
	}

	private string GetBattleDlg_RedMist(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "RedMist";
		string character = "Binah_MeetRedMist";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = dialogDictionary[dlgType];
			if (list.Count > 0)
			{
				text = list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetBattleDlg_PurpleTear(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "PupleTear";
		string character = "Binah_MeetPupleTear";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50035);
			if (!_bKilledPurpleTear && battleUnitModel != null && battleUnitModel.IsDead())
			{
				_bKilledPurpleTear = true;
				if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
				{
					BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
					if (battleDialog != null)
					{
						text = battleDialog.dialogContent;
					}
				}
			}
			else if (dialogDictionary.ContainsKey(dlgType))
			{
				List<BattleDialog> list = dialogDictionary[dlgType];
				if (list != null && list.Count > 0)
				{
					text = list[Random.Range(0, list.Count)].dialogContent;
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetElena1stBattleDlg(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "The Blue Reverberation2 Binah";
		string character = "B_E_Binah";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 1308011);
			BattleUnitModel battleUnitModel2 = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 1308021);
			if (!_bKillElena && battleUnitModel != null && battleUnitModel.IsDead())
			{
				_bKillElena = true;
				if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
				{
					BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_1");
					if (battleDialog != null)
					{
						text = battleDialog.dialogContent;
					}
				}
			}
			else if (!_bKilledOrangeCross && battleUnitModel2 != null && battleUnitModel2.IsDead())
			{
				_bKilledOrangeCross = true;
				if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
				{
					BattleDialog battleDialog2 = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
					if (battleDialog2 != null)
					{
						text = battleDialog2.dialogContent;
					}
				}
			}
			else if (dialogDictionary.ContainsKey(dlgType))
			{
				List<BattleDialog> list = dialogDictionary[dlgType];
				if (list != null && list.Count > 0)
				{
					text = list[Random.Range(0, list.Count)].dialogContent;
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetNormalBattleDlg(DialogType dlgType)
	{
		if (_xmlInfo.characterID != "Binah")
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("LibraryOfRuina", "Binah");
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}
}
