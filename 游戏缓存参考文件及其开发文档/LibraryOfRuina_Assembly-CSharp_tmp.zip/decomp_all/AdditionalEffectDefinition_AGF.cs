using System.Collections.Generic;

public static class AdditionalEffectDefinition_AGF
{
	public class SoundEffectInfo
	{
		public int chapterID;

		public int episodeIdx;

		public Dictionary<int, string> soundEffectDic;
	}

	public static List<SoundEffectInfo> soundEffectInfoList = new List<SoundEffectInfo>();

	public static void InitDictionary()
	{
		Dictionary<int, string> dictionary = new Dictionary<int, string>();
		dictionary.Add(30, "손가락딱");
		dictionary.Add(43, "손가락딱");
		dictionary.Add(46, "손가락딱");
		SoundEffectInfo item = new SoundEffectInfo
		{
			chapterID = 10,
			episodeIdx = 0,
			soundEffectDic = dictionary
		};
		soundEffectInfoList.Add(item);
		Dictionary<int, string> dictionary2 = new Dictionary<int, string>();
		dictionary2.Add(0, "손가락딱");
		SoundEffectInfo item2 = new SoundEffectInfo
		{
			chapterID = 10,
			episodeIdx = 1,
			soundEffectDic = dictionary2
		};
		soundEffectInfoList.Add(item2);
		Dictionary<int, string> dictionary3 = new Dictionary<int, string>();
		dictionary3.Add(56, "Story_Breathe");
		dictionary3.Add(58, "Story_GearMove");
		dictionary3.Add(69, "Story_Machine");
		dictionary3.Add(83, "Story_GearOn");
		dictionary3.Add(87, "Story_GearMove");
		dictionary3.Add(96, "Story_GunFire");
		dictionary3.Add(108, "Story_GunDown");
		dictionary3.Add(111, "Story_GunGuard");
		dictionary3.Add(124, "Story_Run");
		dictionary3.Add(133, "Story_Run");
		dictionary3.Add(141, "Story_Buss");
		dictionary3.Add(160, "Story_Sign");
		dictionary3.Add(163, "Story_Warf");
		dictionary3.Add(165, "손가락딱");
		dictionary3.Add(193, "손가락딱");
		dictionary3.Add(205, "손가락딱");
		SoundEffectInfo item3 = new SoundEffectInfo
		{
			chapterID = 11,
			episodeIdx = 0,
			soundEffectDic = dictionary3
		};
		soundEffectInfoList.Add(item3);
		Dictionary<int, string> dictionary4 = new Dictionary<int, string>();
		dictionary4.Add(0, "손가락딱");
		SoundEffectInfo item4 = new SoundEffectInfo
		{
			chapterID = 11,
			episodeIdx = 1,
			soundEffectDic = dictionary4
		};
		soundEffectInfoList.Add(item4);
		Dictionary<int, string> dictionary5 = new Dictionary<int, string>();
		dictionary5.Add(0, "Story_Coffee");
		SoundEffectInfo item5 = new SoundEffectInfo
		{
			chapterID = 12,
			episodeIdx = 0,
			soundEffectDic = dictionary5
		};
		soundEffectInfoList.Add(item5);
	}

	public static string GetSoundEffectName(int chapter, int episodeIdx, int dlgId)
	{
		if (soundEffectInfoList.Exists((SoundEffectInfo x) => x.chapterID == chapter && x.episodeIdx == episodeIdx))
		{
			Dictionary<int, string> soundEffectDic = soundEffectInfoList.Find((SoundEffectInfo x) => x.chapterID == chapter && x.episodeIdx == episodeIdx).soundEffectDic;
			string value = string.Empty;
			if (soundEffectDic.TryGetValue(dlgId, out value))
			{
				return value;
			}
		}
		return string.Empty;
	}

	public static bool IsLastDialogWithHessed(int chapter, int episodeIdx, int dlgId)
	{
		if (chapter == 12 && episodeIdx == 0)
		{
			return dlgId == 6;
		}
		return false;
	}
}
