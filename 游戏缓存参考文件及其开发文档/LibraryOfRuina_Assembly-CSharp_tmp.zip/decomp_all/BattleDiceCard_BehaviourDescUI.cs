using System.Collections.Generic;
using LOR_DiceSystem;
using TMPro;
using UI;
using UnityEngine;
using UnityEngine.UI;

public class BattleDiceCard_BehaviourDescUI : MonoBehaviour
{
	[Header("Colors")]
	[SerializeField]
	private Color[] refsColors_FaceColor;

	[Header("Reference")]
	public Image img_detail;

	public TextMeshProUGUI txt_ability;

	public TextMeshProUGUI txt_range;

	public void SetBehaviourInfo(DiceBehaviour behaviour, LorId cardId, List<DiceBehaviour> behaviourList, bool isHide = false)
	{
		BehaviourType type = behaviour.Type;
		int dice = behaviour.Dice;
		BehaviourDetail detail = behaviour.Detail;
		string text = "";
		if (isHide)
		{
			text = "???";
		}
		else
		{
			text = Singleton<BattleCardAbilityDescXmlList>.Instance.GetAbilityDesc(behaviour);
			if (string.IsNullOrEmpty(text))
			{
				text = Singleton<BattleCardDescXmlList>.Instance.GetBehaviourDesc(cardId, behaviourList.IndexOf(behaviour));
			}
		}
		if (dice >= 100)
		{
			Debug.LogError("현재 2자리 수 이상 표시 되지 않습니다.");
		}
		txt_ability.text = TextUtil.TransformConditionKeyword(text);
		Color color = Color.white;
		switch (behaviour.Rwbp)
		{
		case RWBPType.R:
			color = refsColors_FaceColor[0];
			break;
		case RWBPType.P:
			color = refsColors_FaceColor[1];
			break;
		}
		txt_ability.color = color;
		SetText(behaviour);
		Sprite sprite = ((type == BehaviourType.Standby) ? UISpriteDataManager.instance.CardStandbyBehaviourDetailIcons[(int)detail] : UISpriteDataManager.instance._cardBehaviourDetailIcons[(int)detail]);
		img_detail.sprite = sprite;
	}

	private void OnEnable()
	{
		SingletonBehavior<LocalizedFontSetter>.Instance.SetLocalizedFont(txt_ability, FontType.FONT_BODY);
	}

	private void SetText(DiceBehaviour behaviour)
	{
		if (!(txt_range == null))
		{
			txt_range.text = $"{behaviour.GetMinText()}-{behaviour.GetMaxText()}";
			Color color = UIColorManager.Manager.BehaviourColors[(int)behaviour.Type];
			txt_range.color = color;
		}
	}
}
