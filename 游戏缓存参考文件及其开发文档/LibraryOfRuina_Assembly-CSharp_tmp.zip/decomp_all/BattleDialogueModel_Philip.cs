using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_Philip : BattleDialogueModel
{
	public BattleDialogueModel_Philip(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string empty = string.Empty;
		switch (dlgType)
		{
		case DialogType.DEATH:
		{
			int num = ((Random.Range(0f, 1f) <= 0.5f) ? 1 : 2);
			return GetBattleDlgSpecialEvent("SPECIAL_EVENT_" + num);
		}
		case DialogType.BATTLE_VICTORY:
			if (BattleObjectManager.instance.GetAliveList(Faction.Enemy).Count == 1)
			{
				return GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
			return base.GetBattleDlg(dlgType);
		default:
			return base.GetBattleDlg(dlgType);
		}
	}
}
