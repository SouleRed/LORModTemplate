using System;
using System.Collections.Generic;
using System.Reflection;
using LOR_XML;
using Mod;
using UnityEngine;

public class AssemblyManager : Singleton<AssemblyManager>
{
	private class TypeDictionary<T> where T : class
	{
		private Dictionary<string, Type> _dict = new Dictionary<string, Type>();

		public bool Add(string key, Type value)
		{
			if (_dict.ContainsKey(key))
			{
				Singleton<ModContentManager>.Instance.AddErrorLog("Aleady Exists : " + key);
				return false;
			}
			_dict.Add(key, value);
			return true;
		}

		public bool TryGetValue(string key, out Type value)
		{
			return _dict.TryGetValue(key, out value);
		}

		public T CreateInstance(string key)
		{
			try
			{
				if (string.IsNullOrEmpty(key))
				{
					return null;
				}
				if (_dict.TryGetValue(key.Trim(), out var value))
				{
					return Activator.CreateInstance(value) as T;
				}
			}
			catch (Exception e)
			{
				Singleton<ModContentManager>.Instance.AddErrorLog(e);
			}
			return null;
		}
	}

	private Dictionary<string, List<Assembly>> _assemblyDict = new Dictionary<string, List<Assembly>>();

	private TypeDictionary<DiceCardSelfAbilityBase> _diceCardSelfAbilityDict = new TypeDictionary<DiceCardSelfAbilityBase>();

	private TypeDictionary<DiceCardAbilityBase> _diceCardAbilityDict = new TypeDictionary<DiceCardAbilityBase>();

	private TypeDictionary<BehaviourActionBase> _behaviourActionDict = new TypeDictionary<BehaviourActionBase>();

	private TypeDictionary<PassiveAbilityBase> _passiveAbilityDict = new TypeDictionary<PassiveAbilityBase>();

	private TypeDictionary<DiceCardPriorityBase> _diceCardPriorityDict = new TypeDictionary<DiceCardPriorityBase>();

	private TypeDictionary<EnemyUnitAggroSetter> _enemyUnitAggroSetterDict = new TypeDictionary<EnemyUnitAggroSetter>();

	private TypeDictionary<EnemyTeamStageManager> _enemyTeamStageManagerDict = new TypeDictionary<EnemyTeamStageManager>();

	private TypeDictionary<EnemyUnitTargetSetter> _enemyUnitTargetSetterDict = new TypeDictionary<EnemyUnitTargetSetter>();

	private List<ModInitializer> _initializer = new List<ModInitializer>();

	public void Initialize()
	{
		Assembly executingAssembly = Assembly.GetExecutingAssembly();
		LoadTypesFromAssembly(executingAssembly);
	}

	public void CallAllInitializer()
	{
		foreach (ModInitializer item in _initializer)
		{
			try
			{
				item.OnInitializeMod();
			}
			catch (Exception e)
			{
				Singleton<ModContentManager>.Instance.AddErrorLog(e);
			}
		}
	}

	private void LoadTypesFromAssembly(Assembly assembly)
	{
		Type[] types = assembly.GetTypes();
		foreach (Type type in types)
		{
			string name = type.Name;
			if (type.IsSubclassOf(typeof(DiceCardSelfAbilityBase)) && name.StartsWith("DiceCardSelfAbility_"))
			{
				_diceCardSelfAbilityDict.Add(name.Substring("DiceCardSelfAbility_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(DiceCardAbilityBase)) && name.StartsWith("DiceCardAbility_"))
			{
				_diceCardAbilityDict.Add(name.Substring("DiceCardAbility_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(BehaviourActionBase)) && name.StartsWith("BehaviourAction_"))
			{
				_behaviourActionDict.Add(name.Substring("BehaviourAction_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(PassiveAbilityBase)) && name.StartsWith("PassiveAbility_"))
			{
				_passiveAbilityDict.Add(name.Substring("PassiveAbility_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(DiceCardPriorityBase)) && name.StartsWith("DiceCardPriority_"))
			{
				_diceCardPriorityDict.Add(name.Substring("DiceCardPriority_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(EnemyUnitAggroSetter)) && name.StartsWith("EnemyUnitAggroSetter_"))
			{
				_enemyUnitAggroSetterDict.Add(name.Substring("EnemyUnitAggroSetter_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(EnemyTeamStageManager)) && name.StartsWith("EnemyTeamStageManager_"))
			{
				_enemyTeamStageManagerDict.Add(name.Substring("EnemyTeamStageManager_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(EnemyUnitTargetSetter)) && name.StartsWith("EnemyUnitTargetSetter_"))
			{
				_enemyUnitTargetSetterDict.Add(name.Substring("EnemyUnitTargetSetter_".Length), type);
			}
			else if (type.IsSubclassOf(typeof(ModInitializer)))
			{
				_initializer.Add(Activator.CreateInstance(type) as ModInitializer);
			}
		}
	}

	public void LoadAllAssembly(string uid, string[] filenames, out Dictionary<string, BattleCardAbilityDesc> abilityText)
	{
		abilityText = new Dictionary<string, BattleCardAbilityDesc>();
		if (_assemblyDict.ContainsKey(uid))
		{
			return;
		}
		List<Assembly> list = new List<Assembly>();
		foreach (string text in filenames)
		{
			try
			{
				List<Assembly> list2 = new List<Assembly>(AppDomain.CurrentDomain.GetAssemblies());
				Assembly assembly = Assembly.LoadFile(text);
				if (assembly != null)
				{
					Debug.Log("load : " + text);
					if (list2.Contains(assembly))
					{
						Singleton<ModContentManager>.Instance.AddWarningLog("The same assembly name already exists. : " + assembly.GetName().Name);
						continue;
					}
					Type[] types = assembly.GetTypes();
					foreach (Type type in types)
					{
						string text2 = type.Name;
						bool flag = false;
						if (type.IsSubclassOf(typeof(DiceCardAbilityBase)))
						{
							if (text2.StartsWith("DiceCardAbility_"))
							{
								text2 = text2.Substring("DiceCardAbility_".Length);
							}
							flag = true;
						}
						if (type.IsSubclassOf(typeof(DiceCardSelfAbilityBase)))
						{
							if (text2.StartsWith("DiceCardSelfAbility_"))
							{
								text2 = text2.Substring("DiceCardSelfAbility_".Length);
							}
							flag = true;
						}
						if (!flag)
						{
							continue;
						}
						FieldInfo field = type.GetField("Desc");
						if (field != null)
						{
							string text3 = field.GetValue(null) as string;
							if (!string.IsNullOrEmpty(text3) && !abilityText.ContainsKey(text2))
							{
								abilityText.Add(text2, new BattleCardAbilityDesc
								{
									id = text2,
									desc = new List<string> { text3 }
								});
							}
						}
					}
					list.Add(assembly);
				}
				else
				{
					Singleton<ModContentManager>.Instance.AddErrorLog("load fail : " + text);
				}
			}
			catch (Exception e)
			{
				Singleton<ModContentManager>.Instance.AddErrorLog(e);
			}
		}
		foreach (Assembly item in list)
		{
			LoadTypesFromAssembly(item);
		}
		if (list.Count > 0)
		{
			_assemblyDict.Add(uid, list);
		}
	}

	public DiceCardSelfAbilityBase CreateInstance_DiceCardSelfAbility(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		return _diceCardSelfAbilityDict.CreateInstance(name);
	}

	public DiceCardAbilityBase CreateInstance_DiceCardAbility(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		return _diceCardAbilityDict.CreateInstance(name);
	}

	public BehaviourActionBase CreateInstance_BehaviourAction(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		return _behaviourActionDict.CreateInstance(name);
	}

	public PassiveAbilityBase CreateInstance_PassiveAbility(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		return _passiveAbilityDict.CreateInstance(name);
	}

	public DiceCardPriorityBase CreateInstance_DiceCardPriority(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		return _diceCardPriorityDict.CreateInstance(name);
	}

	public EnemyUnitAggroSetter CreateInstance_EnemyUnitAggroSetter(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		EnemyUnitAggroSetter enemyUnitAggroSetter = _enemyUnitAggroSetterDict.CreateInstance(name);
		if (enemyUnitAggroSetter == null)
		{
			enemyUnitAggroSetter = new EnemyUnitAggroSetter();
		}
		return enemyUnitAggroSetter;
	}

	public EnemyTeamStageManager CreateInstance_EnemyTeamStageManager(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		EnemyTeamStageManager enemyTeamStageManager = _enemyTeamStageManagerDict.CreateInstance(name);
		if (enemyTeamStageManager == null)
		{
			enemyTeamStageManager = new EnemyTeamStageManager();
		}
		return enemyTeamStageManager;
	}

	public EnemyUnitTargetSetter CreateInstance_EnemyUnitTargetSetter(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		EnemyUnitTargetSetter enemyUnitTargetSetter = _enemyUnitTargetSetterDict.CreateInstance(name);
		if (enemyUnitTargetSetter == null)
		{
			enemyUnitTargetSetter = new EnemyUnitTargetSetter();
		}
		return enemyUnitTargetSetter;
	}
}
