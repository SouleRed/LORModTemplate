using LOR_XML;

public class BattleDialogueModel_150013 : BattleDialogueModel
{
	private bool _bGeburaDead;

	private bool _bRolandDead;

	public BattleDialogueModel_150013(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bGeburaDead = false;
		_bRolandDead = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		ResetDialogData(dlgType);
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.KILLS_OPPONENT)
		{
			if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura)
			{
				if (!_bGeburaDead)
				{
					BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 6);
					if (battleUnitModel != null && battleUnitModel.IsDead())
					{
						_bGeburaDead = true;
						result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
					}
				}
			}
			else if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Keter && !_bRolandDead)
			{
				BattleUnitModel battleUnitModel2 = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 10);
				if (battleUnitModel2 != null && battleUnitModel2.IsDead())
				{
					_bRolandDead = true;
					result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
				}
			}
		}
		return result;
	}

	private void ResetDialogData(DialogType dlgType)
	{
		if (dlgType != DialogType.START_BATTLE)
		{
			return;
		}
		switch (Singleton<StageController>.Instance.CurrentFloor)
		{
		case SephirahType.Gebura:
			if (_xmlInfo.characterID != "Argalia_MeetGebura")
			{
				BattleDialogCharacter characterData2 = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("BlueReverberation1", "Argalia_MeetGebura");
				Init(characterData2);
			}
			break;
		case SephirahType.Keter:
			if (_xmlInfo.characterID != "Argalia_MeetRoland")
			{
				BattleDialogCharacter characterData3 = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("BlueReverberation1", "Argalia_MeetRoland");
				Init(characterData3);
			}
			break;
		default:
			if (_xmlInfo.characterID != "Argalia_nomal")
			{
				BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("BlueReverberation1", "Argalia_nomal");
				Init(characterData);
			}
			break;
		}
	}
}
