using LOR_XML;

public class BattleDialogueModel_150030 : BattleDialogueModel
{
	public BattleDialogueModel_150030(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		return base.GetBattleDlg(dlgType);
	}
}
