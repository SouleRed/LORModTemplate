using UnityEngine;
using UnityEngine.UI;

public class BattleCharacterProfileUI_Coin : MonoBehaviour
{
	public RectTransform rt;

	public Image coinImg;

	public void Set(float width, Color color)
	{
		Vector2 sizeDelta = rt.sizeDelta;
		sizeDelta.x = width;
		rt.sizeDelta = sizeDelta;
		coinImg.color = color;
	}

	public void SetDefaultImgScale()
	{
		if (coinImg.enabled)
		{
			coinImg.rectTransform.localScale = Vector3.one;
		}
	}
}
