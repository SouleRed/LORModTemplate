using System.Collections;
using UnityEngine;

public class AwakeEgoEffect : MonoBehaviour
{
	public AnimationCurve intensityCurve;

	public Light light;

	public AnimationCurve completeCurve;

	public static AwakeEgoEffect curEgoEffect;

	public static void CreateEffect(BattleUnitModel model)
	{
		curEgoEffect = Util.LoadPrefab("BattleEffect/AwakeEGO/EgoEffect", model.view.transform).GetComponent<AwakeEgoEffect>();
		curEgoEffect.StartCoroutine(curEgoEffect.ChangeIntensity());
	}

	public static void EndEffect()
	{
		curEgoEffect.StopAllCoroutines();
		curEgoEffect.StartCoroutine(curEgoEffect.CompleteAwakening());
	}

	internal IEnumerator CompleteAwakening()
	{
		float elapsed = 0f;
		light.intensity = 65f;
		while (elapsed < 0.5f)
		{
			elapsed += Time.deltaTime;
			light.intensity -= Time.deltaTime * 30f;
			yield return YieldCache.waitFrame;
		}
		Object.Destroy(light.gameObject);
		Object.Destroy(base.gameObject);
	}

	internal IEnumerator ChangeIntensity(float time = float.MaxValue)
	{
		float elapsed = 0f;
		while (elapsed <= time)
		{
			elapsed += Time.deltaTime;
			float intensity = intensityCurve.Evaluate(elapsed);
			light.intensity = intensity;
			yield return YieldCache.waitFrame;
		}
	}
}
