using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_Sephirah : BattleDialogueModel
{
	protected const int _stageId_BS = 60003;

	protected const int _stageId_RB2 = 60004;

	public BattleDialogueModel_Sephirah(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public virtual string GetBattleDlg_BS(DialogType dlgType, SephirahType sephirah, string sephirahName)
	{
		string result = string.Empty;
		switch (dlgType)
		{
		case DialogType.DEATH:
			result = TextDataModel.GetText($"Roland_Black_{sephirahName}_Die");
			break;
		case DialogType.START_BATTLE:
		{
			List<SephirahType> usedFloorList = Singleton<StageController>.Instance.GetStageModel().GetUsedFloorList();
			SephirahType sephirahType = usedFloorList.Find((SephirahType x) => x == sephirah);
			if (sephirahType == sephirah)
			{
				int num = usedFloorList.IndexOf(sephirahType) + 1;
				result = TextDataModel.GetText($"Roland_Black_{sephirahName}_{num}");
			}
			break;
		}
		}
		return result;
	}

	public virtual string GetBattleDlg_RB2(DialogType dlgType, SephirahType sephirah, string sephirahName)
	{
		string result = string.Empty;
		switch (dlgType)
		{
		case DialogType.DEATH:
			result = TextDataModel.GetText($"BlueReverberation_{sephirahName}_Die");
			break;
		case DialogType.START_BATTLE:
		{
			List<SephirahType> usedFloorList = Singleton<StageController>.Instance.GetStageModel().GetUsedFloorList();
			SephirahType sephirahType = usedFloorList.Find((SephirahType x) => x == sephirah);
			if (sephirahType == sephirah)
			{
				int num = usedFloorList.IndexOf(sephirahType);
				int num2 = 1;
				num2 = ((num < 1) ? 1 : ((num >= 4) ? 3 : 2));
				result = TextDataModel.GetText($"BlueReverberation_{sephirahName}_{num2}");
			}
			break;
		}
		}
		return result;
	}
}
