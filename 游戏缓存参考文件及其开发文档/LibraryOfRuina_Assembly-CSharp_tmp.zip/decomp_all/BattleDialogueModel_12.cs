using LOR_XML;

public class BattleDialogueModel_12 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_12(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Yesod";
		_characterId_RB1 = "Y_E_Librarian_";
		_stageId_RB1 = 70002;
		_characterId_BS = "Y_Librarian";
		_sephirahType = SephirahType.Yesod;
		_characterId_RB2 = _characterId_BS;
	}
}
