using UnityEngine;

public class BattleCardPreviewSlider : MonoBehaviour
{
	[SerializeField]
	private CanvasGroup CG;

	[SerializeField]
	private Animator cardSlideAnim;

	[SerializeField]
	private _2dxFX_HSV[] showHideIcons;

	[SerializeField]
	private CanvasGroup cardUICG;

	public void OnClickHideShowCardPreview()
	{
		cardSlideAnim.enabled = true;
		if (cardUICG.alpha == 0f)
		{
			cardSlideAnim.SetTrigger("Show");
		}
		else
		{
			cardSlideAnim.SetTrigger("Hide");
		}
	}

	public void OnEnterHideShowButton()
	{
		_2dxFX_HSV[] array = showHideIcons;
		for (int i = 0; i < array.Length; i++)
		{
			array[i]._HueShift = 215f;
		}
	}

	public void OnExitHideShowButton()
	{
		_2dxFX_HSV[] array = showHideIcons;
		for (int i = 0; i < array.Length; i++)
		{
			array[i]._HueShift = 0f;
		}
	}

	public void OnEndCardPreview()
	{
		cardSlideAnim.enabled = false;
	}

	public void SetActive(bool b)
	{
		CG.alpha = (b ? 1 : 0);
		CG.blocksRaycasts = b;
		CG.interactable = b;
		cardUICG.gameObject.SetActive(b);
	}
}
