using LOR_XML;

public class BattleDialogueModel_13 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_13(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Hod";
		_characterId_RB1 = "H_G_Librarian_";
		_stageId_RB1 = 70003;
		_characterId_BS = "H_Librarian";
		_sephirahType = SephirahType.Hod;
		_characterId_RB2 = _characterId_BS;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (Singleton<StageController>.Instance.GetStageModel().ClassInfo.id == _stageId_RB1 && dlgType == DialogType.BATTLE_VICTORY)
		{
			result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
		}
		return result;
	}
}
