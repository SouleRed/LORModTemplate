using LOR_XML;

public class BattleDialogueModel_18 : BattleDialogueModel_Librarian
{
	private bool _bKilledOrangeCross;

	private bool _bKillElena;

	public BattleDialogueModel_18(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Binah";
		_characterId_RB1 = "B_E_Librarian_";
		_stageId_RB1 = 70008;
		_bKillElena = false;
		_bKilledOrangeCross = false;
		_characterId_BS = "B_Librarian";
		_sephirahType = SephirahType.Binah;
		_characterId_RB2 = _characterId_BS;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (Singleton<StageController>.Instance.GetStageModel().ClassInfo.id == _stageId_RB1)
		{
			if (!_bKilledOrangeCross)
			{
				BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 1308021);
				if (battleUnitModel != null && battleUnitModel.IsDead())
				{
					_bKilledOrangeCross = true;
					result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
				}
			}
			else if (!_bKillElena)
			{
				BattleUnitModel battleUnitModel2 = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 1308011);
				if (battleUnitModel2 != null && battleUnitModel2.IsDead())
				{
					_bKillElena = true;
					result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_1");
				}
			}
		}
		return result;
	}
}
