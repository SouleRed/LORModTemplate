using System;
using System.Collections.Generic;
using Battle.CreatureEffect;
using LOR_DiceSystem;

public class BattleCardTotalResult
{
	public BattlePlayingCardDataInUnitModel playingCard;

	public BattleDiceCardModel usedCard;

	public List<BattleDiceBehavior> usedDiceList = new List<BattleDiceBehavior>();

	public BattleCardBehaviourResult.BehaviourEvent useCardEvent;

	public BattleCardBehaviourResult.BehaviourEvent endCardActionEvent;

	private List<BattleCardBehaviourResult> _behaviourResultList = new List<BattleCardBehaviourResult>();

	private bool _didCardAction;

	public List<BattleDiceBehaviourUI> prevBehaviour = new List<BattleDiceBehaviourUI>();

	public Queue<BattleCardBehaviourResult> BehaviourResultQueue
	{
		get
		{
			Queue<BattleCardBehaviourResult> queue = new Queue<BattleCardBehaviourResult>();
			foreach (BattleCardBehaviourResult behaviourResult in _behaviourResultList)
			{
				queue.Enqueue(behaviourResult);
			}
			return queue;
		}
	}

	public IList<BattleCardBehaviourResult> BehaviourResultList => _behaviourResultList;

	private BattleCardBehaviourResult _curbehaviourResult
	{
		get
		{
			if (_behaviourResultList.Count == 0)
			{
				_behaviourResultList.Add(new BattleCardBehaviourResult());
			}
			return _behaviourResultList[_behaviourResultList.Count - 1];
		}
	}

	public BattleCardBehaviourResult CurbehaviourResult => _curbehaviourResult;

	public BattleCardTotalResult(BattlePlayingCardDataInUnitModel playingCard)
	{
		this.playingCard = playingCard;
		usedCard = playingCard?.card;
	}

	public void InitNextBehaviour()
	{
		_behaviourResultList.Add(new BattleCardBehaviourResult());
	}

	public void SetBehaviour(BattleDiceBehavior behaviour)
	{
		_curbehaviourResult.hasBehaviour = behaviour != null;
		_curbehaviourResult.behaviourRawData = behaviour?.behaviourInCard;
		_curbehaviourResult.playingCard = behaviour?.card;
		_curbehaviourResult.cardModel = behaviour?.card?.card;
		_curbehaviourResult.behaviourIdx = behaviour?.Index ?? (-1);
		_curbehaviourResult.behaviour = behaviour;
	}

	public void SetVanillaDiceFace(int min, int max)
	{
		_curbehaviourResult.vanillaDiceMin = min;
		_curbehaviourResult.vanillaDiceFace = max;
	}

	public void SetResultDiceFace(int min, int face)
	{
		_curbehaviourResult.resultDiceMin = min;
		_curbehaviourResult.resultDiceMax = face;
	}

	public void SetVanillaDiceValue(int value)
	{
		_curbehaviourResult.vanillaDiceValue = value;
		_curbehaviourResult.vanillaDiceValueList.Add(value);
	}

	public void SetResultDiceValue(int value)
	{
		_curbehaviourResult.resultDiceValue = value;
	}

	public void SetBufs(BattleUnitBuf buf)
	{
		if (buf.positiveType == BufPositiveType.Positive)
		{
			_curbehaviourResult.bufBeforeRoll.Add(buf.bufActivatedName);
		}
		else
		{
			_curbehaviourResult.debufBeforeRoll.Add(buf.bufActivatedName);
		}
	}

	public void SetNewBufs(BattleUnitBuf buf)
	{
		if (buf.positiveType == BufPositiveType.Positive)
		{
			_curbehaviourResult.bufAfterRoll.Add(buf.bufActivatedName);
			_curbehaviourResult.bufDataAfterRoll.Add(buf);
		}
		else
		{
			_curbehaviourResult.debufAfterRoll.Add(buf.bufActivatedName);
			_curbehaviourResult.bufDataAfterRoll.Add(buf);
		}
	}

	public void SetGift(GiftModel gift)
	{
		_curbehaviourResult.giftAbilityBeforeRoll.Add(gift.GetName());
	}

	public void SetPassiveAbility(PassiveAbilityBase passive)
	{
		_curbehaviourResult.bookAbilityAfterRoll.Add(passive.desc);
		_curbehaviourResult.bookAbilityDataAfterRoll.Add(passive);
	}

	public void SetPassiveAbilityDesc(string desc)
	{
		_curbehaviourResult.bookAbilityAfterRoll.Add(desc);
	}

	public void SetDiceDestroyed(bool b)
	{
		_curbehaviourResult.isDestroyed = b;
	}

	public void SetEmotionAbility(BattleEmotionCardModel emotionPassive)
	{
		_curbehaviourResult.emotionAbilityBeforeRoll.Add(emotionPassive.ToString());
	}

	public void SetEmotionAbility(bool activateByResult, BattleEmotionCardModel emotionPassive, int index, ResultOption option = ResultOption.Default, params int[] param)
	{
		string[] array = new string[param.Length];
		for (int i = 0; i < param.Length; i++)
		{
			if (option == ResultOption.Sign)
			{
				int num = param[i];
				if (num > 0)
				{
					array[i] = "+" + num;
				}
				else
				{
					array[i] = num.ToString();
				}
			}
			else
			{
				array[i] = param[i].ToString();
			}
		}
		string typoText = emotionPassive.GetTypoText(index, array);
		if (!(typoText == ""))
		{
			if (activateByResult)
			{
				_curbehaviourResult.emotionAbilityAfterRoll.Add(typoText);
				_curbehaviourResult.emotionAbilityDataAfterRoll.Add(emotionPassive);
			}
			else
			{
				_curbehaviourResult.emotionAbilityAfterRoll.Add(typoText);
				_curbehaviourResult.emotionAbilityDataAfterRoll.Add(emotionPassive);
			}
			if (!_curbehaviourResult.activatedEmotionCardDictionary.ContainsKey(emotionPassive.XmlInfo.Name))
			{
				_curbehaviourResult.activatedEmotionCardDictionary.Add(emotionPassive.XmlInfo.Name, emotionPassive);
			}
		}
	}

	public void SetEmotionAbilityEffect(string resPath)
	{
		_curbehaviourResult.addedAbnormalityEffectList.Add(resPath);
	}

	public void SetCreatureAbilityEffect(string resPath, float time = -1f)
	{
		_curbehaviourResult.addedCreatureEffectList.Add(new BattleCardBehaviourResult.CreatureEffectInfo
		{
			path = resPath,
			time = time
		});
	}

	public void SetNewCreatureAbilityEffect(string resPath, float time = -1f)
	{
		string path = "New_IllusionCardFX/" + resPath;
		_curbehaviourResult.addedCreatureEffectList.Add(new BattleCardBehaviourResult.CreatureEffectInfo
		{
			path = path,
			time = time
		});
	}

	public void ApplyCreatureEffect(CreatureEffect effect)
	{
		if (!_curbehaviourResult.creatureEffects.Contains(effect))
		{
			_curbehaviourResult.creatureEffects.Add(effect);
		}
	}

	public void SetCreatureEffectSound(string src)
	{
		_curbehaviourResult.craetureEffectSounds.Add(src);
	}

	public void SetAttackEffectFilter(Type filter)
	{
		_curbehaviourResult.addedAttackFilterList.Add(filter);
	}

	public void SetDiceBehaviourAbility(bool activateByResult, BattleDiceBehavior diceBehaviour, BattleDiceCardModel cardModel)
	{
		LorId iD = cardModel.GetID();
		int num = cardModel.GetBehaviourList().IndexOf(diceBehaviour.behaviourInCard);
		string value = Singleton<BattleCardAbilityDescXmlList>.Instance.GetAbilityDesc(diceBehaviour.behaviourInCard);
		if (string.IsNullOrEmpty(value))
		{
			value = Singleton<BattleCardDescXmlList>.Instance.GetBehaviourDesc(iD, num);
		}
		if (activateByResult)
		{
			if (!_curbehaviourResult.behaviourAbilityAfterRoll.ContainsKey(num))
			{
				_curbehaviourResult.behaviourAbilityAfterRoll.Add(num, value);
			}
		}
		else if (!_curbehaviourResult.behaviourAbilityAfterRoll.ContainsKey(num))
		{
			_curbehaviourResult.behaviourAbilityAfterRoll.Add(num, value);
		}
	}

	public void SetBehaviourResult(DiceBehaviourResultData result)
	{
		_curbehaviourResult.diceBehaviourResult = result;
	}

	public void SetDeathState(bool isDead)
	{
		_curbehaviourResult.isDead = isDead;
	}

	public void SetBreakState(bool isBreaked)
	{
		_curbehaviourResult.isBreaked = isBreaked;
	}

	public void SetDamageGiven(int dmg)
	{
		_curbehaviourResult.dmgListGiven.Add(dmg);
	}

	public void SetDamageTaken(int dmg, int maxValue, BehaviourDetail detail, AtkResist atkResist = AtkResist.Normal)
	{
		_curbehaviourResult.dmgListTaken.Add(new DmgTakenData(detail, dmg, maxValue, atkResist));
	}

	public void SetBreakDmgGiven(int breakDmg)
	{
		_curbehaviourResult.breakListGiven.Add(breakDmg);
	}

	public void SetBreakDmgTaken(int breakDmg, BehaviourDetail detail, AtkResist atkResist)
	{
		_curbehaviourResult.breakListTaken.Add(new DmgTakenData(detail, breakDmg, -1, atkResist));
	}

	public void SetIsBlocked(bool blocked)
	{
		_curbehaviourResult.isBlockedDice = blocked;
	}

	public void SetRecoveredHp(int amount)
	{
		_curbehaviourResult.recoveredHpList.Add(amount);
	}

	public void SetRecoveredBp(int amount)
	{
		_curbehaviourResult.recoveredBpList.Add(amount);
	}

	public void SetCurrentHp(float curHp)
	{
		_curbehaviourResult.curHp = curHp;
	}

	public void SetCurrentBreakGauge(int breakGauge)
	{
		_curbehaviourResult.curBreakGauge = breakGauge;
	}

	public void SetRecoveredLight(int amount)
	{
		_curbehaviourResult.recoveredLight += amount;
	}

	public void AddEmotionCoin(EmotionCoinType coinType, int count)
	{
		_curbehaviourResult.SetEmotionCoinAdded(coinType, count);
	}

	public void AddBufEffect(string src)
	{
		_curbehaviourResult.AddBufEffect(src);
	}

	public void SetSucceedAtkEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		BattleCardBehaviourResult curbehaviourResult = _curbehaviourResult;
		curbehaviourResult.succeedAtkEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(curbehaviourResult.succeedAtkEvent, e);
	}

	public void SetSucceedDefEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		BattleCardBehaviourResult curbehaviourResult = _curbehaviourResult;
		curbehaviourResult.succeedDefEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(curbehaviourResult.succeedDefEvent, e);
	}

	public void SetRolldiceEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		BattleCardBehaviourResult curbehaviourResult = _curbehaviourResult;
		curbehaviourResult.rolldiceEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(curbehaviourResult.rolldiceEvent, e);
	}

	public void SetAfterActionEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		BattleCardBehaviourResult curbehaviourResult = _curbehaviourResult;
		curbehaviourResult.afterActionEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(curbehaviourResult.afterActionEvent, e);
	}

	public void SetTakeDamagedEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		BattleCardBehaviourResult curbehaviourResult = _curbehaviourResult;
		curbehaviourResult.takeDamageEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(curbehaviourResult.takeDamageEvent, e);
	}

	public void SetUseCardEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		useCardEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(useCardEvent, e);
	}

	public void SetEndCardActionEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		endCardActionEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(endCardActionEvent, e);
	}

	public void SetPrintEffectEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		BattleCardBehaviourResult curbehaviourResult = _curbehaviourResult;
		curbehaviourResult.printAtkEffectEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(curbehaviourResult.printAtkEffectEvent, e);
	}

	public void SetPrintDamagedEffectEvent(BattleCardBehaviourResult.BehaviourEvent e)
	{
		BattleCardBehaviourResult curbehaviourResult = _curbehaviourResult;
		curbehaviourResult.printDamagedEffectEvent = (BattleCardBehaviourResult.BehaviourEvent)Delegate.Combine(curbehaviourResult.printDamagedEffectEvent, e);
	}

	public void SetParam(int param)
	{
		_curbehaviourResult.iParam = param;
	}

	public void CompareDiceBehavioursUI(List<BattleDiceBehaviourUI> behaviours, CompareBehaviourUIType type)
	{
		prevBehaviour.Clear();
		switch (type)
		{
		case CompareBehaviourUIType.Before:
			prevBehaviour.AddRange(GetBehavioursDiceState(CompareBehaviourUIType.Start));
			break;
		case CompareBehaviourUIType.End:
		{
			List<BattleDiceBehaviourUI> behavioursDiceState = GetBehavioursDiceState(CompareBehaviourUIType.Start);
			prevBehaviour.AddRange(behavioursDiceState);
			break;
		}
		}
		foreach (BattleDiceBehaviourUI b in behaviours)
		{
			if (prevBehaviour.Count == 0)
			{
				continue;
			}
			BattleDiceBehaviourUI battleDiceBehaviourUI = prevBehaviour.Find((BattleDiceBehaviourUI x) => x.Index == b.Index);
			if (battleDiceBehaviourUI != null)
			{
				if (battleDiceBehaviourUI.isSkip)
				{
					b.isRemoveInList = true;
				}
				else if (battleDiceBehaviourUI.isDestroyed)
				{
					b.isRemoveInList = true;
				}
			}
		}
		foreach (BattleDiceBehaviourUI item in behaviours.FindAll((BattleDiceBehaviourUI x) => x.isRemoveInList))
		{
			behaviours.Remove(item);
		}
	}

	public void SetBehaviourDiceResultUI(CompareBehaviourUIType type)
	{
		if (playingCard.currentBehavior == null)
		{
			return;
		}
		List<BattleDiceBehaviourUI> behavioursDiceState = GetBehavioursDiceState(type);
		behavioursDiceState.Clear();
		foreach (BattleDiceBehavior item2 in playingCard.cardBehaviorQueue)
		{
			BattleDiceBehaviourUI item = new BattleDiceBehaviourUI(item2);
			behavioursDiceState.Add(item);
		}
		CompareDiceBehavioursUI(behavioursDiceState, type);
	}

	public void SetSkip(DiceUITiming timing = DiceUITiming.Start)
	{
		List<BattleDiceBehaviourUI> behavioursDiceState = GetBehavioursDiceState(CompareBehaviourUIType.Start);
		if (behavioursDiceState == null)
		{
			return;
		}
		foreach (BattleDiceBehaviourUI item in behavioursDiceState)
		{
			if (item.behaviourInCard.Type == BehaviourType.Def || item.behaviourInCard.Type == BehaviourType.Standby)
			{
				item.isSkip = true;
				item.skipTiming = timing;
			}
		}
	}

	public List<BattleDiceBehaviourUI> GetBehavioursDiceState(CompareBehaviourUIType type)
	{
		List<BattleDiceBehaviourUI> result = new List<BattleDiceBehaviourUI>();
		switch (type)
		{
		case CompareBehaviourUIType.Start:
			result = _curbehaviourResult.currentAllDiceState.StartBehaviours;
			break;
		case CompareBehaviourUIType.Before:
			result = _curbehaviourResult.currentAllDiceState.BeforeActionBehaviours;
			break;
		case CompareBehaviourUIType.End:
			result = _curbehaviourResult.currentAllDiceState.EndBehaviours;
			break;
		}
		return result;
	}

	public void SetCurrentBuf(BattleBufUIDataList bufDataList)
	{
		_curbehaviourResult.bufDataList.bufReadyList.Clear();
		foreach (BattleBufUIData bufReady in bufDataList.bufReadyList)
		{
			_curbehaviourResult.bufDataList.bufReadyList.Add(bufReady);
		}
		_curbehaviourResult.bufDataList.bufActivatedList.Clear();
		foreach (BattleBufUIData bufActivated in bufDataList.bufActivatedList)
		{
			_curbehaviourResult.bufDataList.bufActivatedList.Add(bufActivated);
		}
	}
}
