using System.Collections.Generic;
using UnityEngine;

public class BattleEffectLayer : MonoBehaviour
{
	private static BattleEffectLayer _instance;

	private List<TimeScalableEffect> _effectList;

	private float _globalEffectTimeScale = 1f;

	public static BattleEffectLayer instance => _instance;

	private void Awake()
	{
		_instance = this;
		_effectList = new List<TimeScalableEffect>();
	}

	private void Start()
	{
	}

	public void OnFixedUpdate(float deltaTime)
	{
		List<TimeScalableEffect> list = new List<TimeScalableEffect>();
		foreach (TimeScalableEffect effect in _effectList)
		{
			effect.OnFixedUpdate(deltaTime);
			if (effect.IsFinished())
			{
				list.Add(effect);
			}
		}
		foreach (TimeScalableEffect item in list)
		{
			_effectList.Remove(item);
			Object.Destroy(item.gameObject);
		}
	}

	public void SetTimeScale(float timeScale)
	{
		_globalEffectTimeScale = timeScale;
		foreach (TimeScalableEffect effect in _effectList)
		{
			effect.SetTimeScale(timeScale);
		}
	}
}
