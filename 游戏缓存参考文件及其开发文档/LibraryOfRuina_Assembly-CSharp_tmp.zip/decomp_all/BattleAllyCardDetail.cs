using System;
using System.Collections.Generic;
using LOR_DiceSystem;
using UnityEngine;

public class BattleAllyCardDetail
{
	private BattleUnitModel _self;

	private int _maxHand = 10;

	private int _maxDrawHand = 8;

	private List<BattleDiceCardModel> _cardInDeck;

	private List<BattleDiceCardModel> _cardInHand;

	private List<BattleDiceCardModel> _cardInUse;

	private List<BattleDiceCardModel> _cardInDiscarded;

	private List<BattleDiceCardModel> _cardInReserved;

	public int maxHandCount => _maxHand;

	public BattleAllyCardDetail(BattleUnitModel self)
	{
		_self = self;
	}

	public void Init(List<DiceCardXmlInfo> deck)
	{
		_cardInDeck = new List<BattleDiceCardModel>();
		_cardInHand = new List<BattleDiceCardModel>();
		_cardInDiscarded = new List<BattleDiceCardModel>();
		_cardInUse = new List<BattleDiceCardModel>();
		_cardInReserved = new List<BattleDiceCardModel>();
		for (int i = 0; i < deck.Count; i++)
		{
			BattleDiceCardModel battleDiceCardModel = BattleDiceCardModel.CreatePlayingCard(deck[i]);
			Util.PreLoadPrefab("EGOs/[Prefab]" + battleDiceCardModel.GetSkin());
			Util.PreLoadPrefab("CreatureMaps/CreatureMap_" + battleDiceCardModel.GetMap());
			battleDiceCardModel.owner = _self;
			_cardInDeck.Add(battleDiceCardModel);
		}
		Shuffle();
	}

	public void SetMaxHand(int handCount)
	{
		_maxHand = handCount;
	}

	public void SetMaxDrawHand(int handCount)
	{
		_maxDrawHand = handCount;
	}

	public bool IsHighlander()
	{
		List<LorId> list = new List<LorId>();
		foreach (BattleDiceCardModel item in GetAllDeck())
		{
			LorId iD = item.GetID();
			if (!ExceptHighlanderID(iD))
			{
				if (list.Contains(iD))
				{
					return false;
				}
				list.Add(iD);
			}
		}
		return true;
	}

	public bool Exsist6CardsInHand_andCopy()
	{
		List<BattleDiceCardModel> hand = GetHand();
		int num = 0;
		int count = hand.Count;
		while (hand.Count > 0 && num < count)
		{
			BattleDiceCardModel battleDiceCardModel = hand[0];
			LorId cardId = battleDiceCardModel.GetID();
			List<BattleDiceCardModel> list = hand.FindAll((BattleDiceCardModel x) => cardId == x.GetID());
			if (list.Count >= 6 && list.Exists((BattleDiceCardModel x) => x.isCopiedCard))
			{
				return true;
			}
			hand.RemoveAll((BattleDiceCardModel x) => cardId == x.GetID());
			num++;
		}
		return false;
	}

	public bool ExceptHighlanderID(LorId cardId)
	{
		if (cardId.IsBasic() && cardId.id > 9900000)
		{
			return true;
		}
		return false;
	}

	public void AddCardToDeck(List<BattleDiceCardModel> cards)
	{
		_cardInDeck?.AddRange(cards);
	}

	public void AddCardToHand(BattleDiceCardModel card, bool front = false)
	{
		card.CreateDiceCardSelfAbilityScript()?.OnAddToHand(_self);
		if (front)
		{
			_cardInHand.Insert(0, card);
		}
		else
		{
			_cardInHand.Add(card);
		}
	}

	public void DiscardCardsInUse()
	{
		_cardInHand.AddRange(_cardInReserved);
		foreach (BattleDiceCardModel item in _cardInReserved)
		{
			_cardInUse.Remove(item);
		}
		new List<BattleDiceCardModel>();
		List<BattleDiceCardModel> list = _cardInUse.FindAll((BattleDiceCardModel x) => x.exhaust);
		list.AddRange(_cardInHand.FindAll((BattleDiceCardModel x) => x.exhaust));
		list.AddRange(_cardInDiscarded.FindAll((BattleDiceCardModel x) => x.exhaust));
		foreach (BattleDiceCardModel item2 in list)
		{
			ExhaustACardAnywhere(item2);
		}
		_cardInReserved.Clear();
		_cardInDiscarded.AddRange(_cardInUse);
		_cardInUse.Clear();
	}

	public void ExhaustAllCards()
	{
		_cardInReserved.Clear();
		_cardInUse.Clear();
		_cardInHand.Clear();
		_cardInDiscarded.Clear();
		_cardInDeck.Clear();
	}

	public void ExhaustACard(BattleDiceCardModel card)
	{
		if (card != null)
		{
			CardRange ranged = card.GetSpec().Ranged;
			DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(card.GetID());
			if (cardItem != null)
			{
				ranged = cardItem.Spec.Ranged;
			}
			if (ranged == CardRange.Far && card.owner.passiveDetail.HasPassive<PassiveAbility_251201>())
			{
				card.exhaust = false;
				return;
			}
		}
		_cardInHand.Remove(card);
	}

	public void ExhaustACardAnywhere(BattleDiceCardModel card)
	{
		if (card != null)
		{
			CardRange ranged = card.GetSpec().Ranged;
			DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(card.GetID());
			if (cardItem != null)
			{
				ranged = cardItem.Spec.Ranged;
			}
			if (ranged == CardRange.Far && card.owner.passiveDetail.HasPassive<PassiveAbility_251201>())
			{
				card.exhaust = false;
				return;
			}
		}
		bool flag = _cardInReserved.Remove(card);
		flag = _cardInUse.Remove(card) || flag;
		flag = _cardInHand.Remove(card) || flag;
		flag = _cardInDiscarded.Remove(card) || flag;
		flag = _cardInDeck.Remove(card) || flag;
	}

	public void ExhaustCard(int id)
	{
		ExhaustCard(new LorId(id));
	}

	public void ExhaustCard(LorId id)
	{
		List<BattleDiceCardModel> list = _cardInReserved.FindAll((BattleDiceCardModel x) => x.GetID() == id);
		if (list != null && list.Count > 0)
		{
			foreach (BattleDiceCardModel item in list)
			{
				_cardInReserved.Remove(item);
			}
			list.Clear();
		}
		list = _cardInUse.FindAll((BattleDiceCardModel x) => x.GetID() == id);
		if (list != null && list.Count > 0)
		{
			foreach (BattleDiceCardModel item2 in list)
			{
				_cardInUse.Remove(item2);
			}
		}
		list = _cardInHand.FindAll((BattleDiceCardModel x) => x.GetID() == id);
		if (list != null && list.Count > 0)
		{
			foreach (BattleDiceCardModel item3 in list)
			{
				_cardInHand.Remove(item3);
			}
		}
		list = _cardInDiscarded.FindAll((BattleDiceCardModel x) => x.GetID() == id);
		if (list != null && list.Count > 0)
		{
			foreach (BattleDiceCardModel item4 in list)
			{
				_cardInDiscarded.Remove(item4);
			}
		}
		list = _cardInDeck.FindAll((BattleDiceCardModel x) => x.GetID() == id);
		if (list == null || list.Count <= 0)
		{
			return;
		}
		foreach (BattleDiceCardModel item5 in list)
		{
			_cardInDeck.Remove(item5);
		}
	}

	public BattleDiceCardModel ExhaustCardInHand(int id)
	{
		return ExhaustCardInHand(new LorId(id));
	}

	public BattleDiceCardModel ExhaustCardInHand(LorId id)
	{
		BattleDiceCardModel battleDiceCardModel = _cardInHand.Find((BattleDiceCardModel x) => x.GetID() == id);
		if (battleDiceCardModel != null)
		{
			_cardInHand.Remove(battleDiceCardModel);
		}
		return battleDiceCardModel;
	}

	public BattleDiceCardModel ExhaustCardInHand(BattleDiceCardModel card)
	{
		BattleDiceCardModel battleDiceCardModel = _cardInHand.Find((BattleDiceCardModel x) => x == card);
		if (battleDiceCardModel != null)
		{
			_cardInHand.Remove(battleDiceCardModel);
		}
		return battleDiceCardModel;
	}

	public BattleDiceCardModel ReturnCardInHandToDeck(BattleDiceCardModel card)
	{
		BattleDiceCardModel battleDiceCardModel = _cardInHand.Find((BattleDiceCardModel x) => x == card);
		if (battleDiceCardModel != null)
		{
			_cardInDeck.Add(battleDiceCardModel);
			Shuffle();
			_cardInHand.Remove(battleDiceCardModel);
		}
		return battleDiceCardModel;
	}

	public BattleDiceCardModel ExhaustRandomCardInHand()
	{
		if (_cardInHand.Count <= 0)
		{
			return null;
		}
		BattleDiceCardModel battleDiceCardModel = _cardInHand[UnityEngine.Random.Range(0, _cardInHand.Count)];
		_cardInHand.Remove(battleDiceCardModel);
		return battleDiceCardModel;
	}

	public void ExhaustAllCardsInHand()
	{
		if (_cardInHand.Count > 0)
		{
			_cardInHand.Clear();
		}
	}

	public BattleDiceCardModel ExhaustCardInDeck(LorId id)
	{
		BattleDiceCardModel battleDiceCardModel = _cardInDeck.Find((BattleDiceCardModel x) => x.GetID() == id);
		if (battleDiceCardModel != null)
		{
			_cardInDeck.Remove(battleDiceCardModel);
		}
		return battleDiceCardModel;
	}

	public BattleDiceCardModel ExhaustRandomCardInDeck()
	{
		if (_cardInDeck.Count <= 0)
		{
			return null;
		}
		BattleDiceCardModel battleDiceCardModel = _cardInDeck[UnityEngine.Random.Range(0, _cardInDeck.Count)];
		_cardInDeck.Remove(battleDiceCardModel);
		return battleDiceCardModel;
	}

	public void DrawCards(int count)
	{
		if (count > _cardInDeck.Count + _cardInDiscarded.Count)
		{
			count = _cardInDeck.Count + _cardInDiscarded.Count;
		}
		for (int i = 0; i < count; i++)
		{
			if (_cardInHand.Count >= _maxDrawHand)
			{
				break;
			}
			if (_cardInDeck.Count == 0)
			{
				_cardInDeck.AddRange(_cardInDiscarded);
				_cardInDiscarded.Clear();
				Shuffle();
			}
			if (_cardInDeck.Count <= 0)
			{
				Debug.LogError(_self.id + " : Where is my deck?");
				break;
			}
			BattleDiceCardModel battleDiceCardModel = _cardInDeck[_cardInDeck.Count - 1];
			AddCardToHand(battleDiceCardModel);
			_cardInDeck.Remove(battleDiceCardModel);
		}
	}

	public void DrawCardsAllSpecific(LorId cardId, BattleDiceCardModel exclude = null)
	{
		List<BattleDiceCardModel> list = _cardInDeck.FindAll((BattleDiceCardModel x) => x.GetID() == cardId && x != exclude);
		list.AddRange(_cardInDiscarded.FindAll((BattleDiceCardModel x) => x.GetID() == cardId && x != exclude));
		while (list.Count > 0 && _cardInHand.Count < _maxDrawHand)
		{
			BattleDiceCardModel battleDiceCardModel = RandomUtil.SelectOne(list);
			if (_cardInDeck.Contains(battleDiceCardModel))
			{
				AddCardToHand(battleDiceCardModel);
				_cardInDeck.Remove(battleDiceCardModel);
			}
			else if (_cardInDiscarded.Contains(battleDiceCardModel))
			{
				AddCardToHand(battleDiceCardModel);
				_cardInDiscarded.Remove(battleDiceCardModel);
			}
			list.Remove(battleDiceCardModel);
		}
	}

	public void ReturnAllToDeck()
	{
		_cardInDeck.AddRange(_cardInHand);
		_cardInDeck.AddRange(_cardInDiscarded);
		_cardInHand.Clear();
		_cardInDiscarded.Clear();
		Shuffle();
	}

	public void UseCard(BattleDiceCardModel card)
	{
		_cardInUse.Add(card);
		_cardInReserved.Add(card);
		_cardInHand.Remove(card);
	}

	public bool SpendCard(BattleDiceCardModel card)
	{
		if (_cardInReserved.Contains(card))
		{
			_cardInReserved.Remove(card);
			return true;
		}
		return false;
	}

	public void AddSoulCard(int emotionLevel)
	{
		BattleDiceCardModel battleDiceCardModel = _self.Book.CreateSoulCard(emotionLevel);
		if (battleDiceCardModel != null)
		{
			battleDiceCardModel.owner = _self;
		}
		if (battleDiceCardModel != null)
		{
			AddCardToHand(battleDiceCardModel);
		}
	}

	public BattleDiceCardModel AddNewCard(int cardId, bool front = false)
	{
		return AddNewCard(new LorId(cardId), front);
	}

	public BattleDiceCardModel AddNewCard(LorId cardId, bool front = false)
	{
		DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(cardId);
		if (cardItem != null)
		{
			BattleDiceCardModel battleDiceCardModel = BattleDiceCardModel.CreatePlayingCard(cardItem);
			battleDiceCardModel.owner = _self;
			DiceCardSelfAbilityBase diceCardSelfAbilityBase = battleDiceCardModel.CreateDiceCardSelfAbilityScript();
			if (diceCardSelfAbilityBase != null && !diceCardSelfAbilityBase.BeforeAddToHand(_self, battleDiceCardModel))
			{
				return null;
			}
			if (_cardInHand.Count >= _maxHand)
			{
				return null;
			}
			AddCardToHand(battleDiceCardModel, front);
			return battleDiceCardModel;
		}
		return null;
	}

	public BattleDiceCardModel AddTempCard(int cardId)
	{
		return AddTempCard(new LorId(cardId));
	}

	public BattleDiceCardModel AddTempCard(LorId cardId)
	{
		DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(cardId);
		if (cardItem != null)
		{
			BattleDiceCardModel battleDiceCardModel = BattleDiceCardModel.CreatePlayingCard(cardItem);
			battleDiceCardModel.owner = _self;
			DiceCardSelfAbilityBase diceCardSelfAbilityBase = battleDiceCardModel.CreateDiceCardSelfAbilityScript();
			if (diceCardSelfAbilityBase != null && !diceCardSelfAbilityBase.BeforeAddToHand(_self, battleDiceCardModel))
			{
				return null;
			}
			if (_cardInHand.Count >= _maxHand)
			{
				return null;
			}
			AddCardToHand(battleDiceCardModel);
			battleDiceCardModel.temporary = true;
			battleDiceCardModel.exhaust = true;
			return battleDiceCardModel;
		}
		return null;
	}

	public BattleDiceCardModel AddNewCardToDeck(int cardId, bool front = false)
	{
		return AddNewCardToDeck(new LorId(cardId), front);
	}

	public BattleDiceCardModel AddNewCardToDeck(LorId cardId, bool front = false)
	{
		DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(cardId);
		if (cardItem != null)
		{
			BattleDiceCardModel battleDiceCardModel = BattleDiceCardModel.CreatePlayingCard(cardItem);
			battleDiceCardModel.owner = _self;
			DiceCardSelfAbilityBase diceCardSelfAbilityBase = battleDiceCardModel.CreateDiceCardSelfAbilityScript();
			if (diceCardSelfAbilityBase != null && !diceCardSelfAbilityBase.BeforeAddToHand(_self, battleDiceCardModel))
			{
				return null;
			}
			if (front)
			{
				_cardInDeck.Insert(0, battleDiceCardModel);
			}
			else
			{
				int index = RandomUtil.Range(0, _cardInDeck.Count);
				_cardInDeck.Insert(index, battleDiceCardModel);
			}
			return battleDiceCardModel;
		}
		return null;
	}

	public BattleDiceCardModel AddNewCardToDiscarded(int cardId)
	{
		return AddNewCardToDiscarded(new LorId(cardId));
	}

	public BattleDiceCardModel AddNewCardToDiscarded(LorId cardId)
	{
		DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(cardId);
		if (cardItem != null)
		{
			BattleDiceCardModel battleDiceCardModel = BattleDiceCardModel.CreatePlayingCard(cardItem);
			battleDiceCardModel.owner = _self;
			DiceCardSelfAbilityBase diceCardSelfAbilityBase = battleDiceCardModel.CreateDiceCardSelfAbilityScript();
			if (diceCardSelfAbilityBase != null && !diceCardSelfAbilityBase.BeforeAddToHand(_self, battleDiceCardModel))
			{
				return null;
			}
			_cardInDiscarded.Add(battleDiceCardModel);
			return battleDiceCardModel;
		}
		return null;
	}

	public void ReturnCardToHand(BattleDiceCardModel appliedCard)
	{
		_ = _cardInHand.Count;
		_self.cardSlotDetail.ReserveCost(-appliedCard.GetCost());
		_cardInUse.Remove(appliedCard);
		_cardInReserved.Remove(appliedCard);
		_cardInHand.Add(appliedCard);
	}

	public void DiscardACardByAbility(BattleDiceCardModel card)
	{
		DiscardACardByAbility(new List<BattleDiceCardModel> { card });
	}

	public void DiscardACardByAbility(List<BattleDiceCardModel> cardList)
	{
		foreach (BattleDiceCardModel card in cardList)
		{
			if (_cardInHand.Contains(card))
			{
				_cardInHand.Remove(card);
				_cardInDiscarded.Add(card);
			}
		}
		_self.OnDiscardByAbility(cardList);
		foreach (BattleDiceCardModel card2 in cardList)
		{
			if (card2.exhaust)
			{
				ExhaustACardAnywhere(card2);
			}
		}
	}

	public void DiscardACardRandomlyByAbility(int num)
	{
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>();
		List<BattleDiceCardModel> list2 = new List<BattleDiceCardModel>();
		list2.AddRange(_cardInHand);
		for (int i = 0; i < num; i++)
		{
			if (list2.Count <= 0)
			{
				break;
			}
			int index = UnityEngine.Random.Range(0, list2.Count);
			BattleDiceCardModel item = _cardInHand[index];
			list2.RemoveAt(index);
			list.Add(item);
		}
		DiscardACardByAbility(list);
	}

	public void DiscardInHand(int num)
	{
		for (int i = 0; i < _cardInHand.Count; i++)
		{
			if (i < num)
			{
				BattleDiceCardModel item = _cardInHand[i];
				_cardInDiscarded.Add(item);
				_cardInHand.Remove(item);
			}
		}
	}

	public BattleDiceCardModel DisCardACardRandom()
	{
		if (_cardInHand.Count <= 0)
		{
			return null;
		}
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>();
		list.AddRange(_cardInHand);
		BattleDiceCardModel battleDiceCardModel = RandomUtil.SelectOne(list);
		List<BattleDiceCardModel> list2 = new List<BattleDiceCardModel>();
		list2.Add(battleDiceCardModel);
		DiscardACardByAbility(list2);
		return battleDiceCardModel;
	}

	public BattleDiceCardModel DiscardACardHighest()
	{
		if (_cardInHand.Count <= 0)
		{
			return null;
		}
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>();
		list.AddRange(_cardInHand);
		list.Sort((BattleDiceCardModel x, BattleDiceCardModel y) => x.GetCost() - y.GetCost());
		int targetCost = list[list.Count - 1].GetCost();
		List<BattleDiceCardModel> list2 = list.FindAll((BattleDiceCardModel x) => x.GetCost() == targetCost);
		if (list2.Count <= 0)
		{
			Debug.LogError("???");
			return null;
		}
		BattleDiceCardModel battleDiceCardModel = RandomUtil.SelectOne(list2);
		List<BattleDiceCardModel> list3 = new List<BattleDiceCardModel>();
		list3.Add(battleDiceCardModel);
		DiscardACardByAbility(list3);
		return battleDiceCardModel;
	}

	public BattleDiceCardModel DiscardACardLowest()
	{
		if (_cardInHand.Count <= 0)
		{
			return null;
		}
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>();
		list.AddRange(_cardInHand);
		list.Sort((BattleDiceCardModel x, BattleDiceCardModel y) => x.GetCost() - y.GetCost());
		int targetCost = list[0].GetCost();
		List<BattleDiceCardModel> list2 = list.FindAll((BattleDiceCardModel x) => x.GetCost() == targetCost);
		if (list2.Count <= 0)
		{
			Debug.LogError("???");
			return null;
		}
		BattleDiceCardModel battleDiceCardModel = RandomUtil.SelectOne(list2);
		List<BattleDiceCardModel> list3 = new List<BattleDiceCardModel>();
		list3.Add(battleDiceCardModel);
		DiscardACardByAbility(list3);
		return battleDiceCardModel;
	}

	public List<BattleDiceCardModel> GetHand()
	{
		return new List<BattleDiceCardModel>(_cardInHand);
	}

	public List<BattleDiceCardModel> GetDiscarded()
	{
		return new List<BattleDiceCardModel>(_cardInDiscarded);
	}

	public List<BattleDiceCardModel> GetDeck()
	{
		return new List<BattleDiceCardModel>(_cardInDeck);
	}

	public List<BattleDiceCardModel> GetUse()
	{
		return new List<BattleDiceCardModel>(_cardInUse);
	}

	public List<BattleDiceCardModel> GetAllDeck()
	{
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>();
		list.AddRange(_cardInHand);
		list.AddRange(_cardInDiscarded);
		list.AddRange(_cardInDeck);
		list.AddRange(_cardInUse);
		return list;
	}

	public BattleDiceCardModel GetRandomCardInHand(Predicate<BattleDiceCardModel> condition = null)
	{
		List<BattleDiceCardModel> list = _cardInHand;
		if (condition != null)
		{
			list = _cardInHand.FindAll(condition);
		}
		if (list.Count == 0)
		{
			return null;
		}
		return RandomUtil.SelectOne(list.ToArray());
	}

	public void Shuffle()
	{
		for (int i = 0; i < _cardInDeck.Count - 1; i++)
		{
			int index = UnityEngine.Random.Range(i, _cardInDeck.Count);
			BattleDiceCardModel value = _cardInDeck[i];
			_cardInDeck[i] = _cardInDeck[index];
			_cardInDeck[index] = value;
		}
	}

	public void PlayTurnAutoForEnemy(int currentDiceSlotIdx, int speed)
	{
		if (_self.turnState == BattleUnitTurnState.BREAK || _self.IsBreakLifeZero() || _self.IsKnockout())
		{
			return;
		}
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>(_cardInHand);
		List<BattleDiceCardModel> list2 = new List<BattleDiceCardModel>();
		list.RemoveAll((BattleDiceCardModel x) => x.GetSpec().Ranged == CardRange.Instance);
		foreach (BattleDiceCardModel item in list)
		{
			if (_self.CheckCardAvailable(item) && item.GetPriority(speed) > -10)
			{
				list2.Add(item);
			}
		}
		List<KeyValuePair<int, BattleDiceCardModel>> list3 = new List<KeyValuePair<int, BattleDiceCardModel>>();
		if (_self.cardSlotDetail.PlayPoint >= _self.cardSlotDetail.GetMaxPlayPoint())
		{
			foreach (BattleDiceCardModel item2 in list2)
			{
				int priority = item2.GetPriority(speed);
				priority += _self.GetPriority(item2, speed);
				if (item2.GetCost() == 0)
				{
					list3.Add(new KeyValuePair<int, BattleDiceCardModel>(priority - 10, item2));
				}
				else
				{
					list3.Add(new KeyValuePair<int, BattleDiceCardModel>(priority, item2));
				}
			}
		}
		else
		{
			foreach (BattleDiceCardModel item3 in list2)
			{
				int priority2 = item3.GetPriority(speed);
				priority2 += _self.GetPriority(item3, speed);
				list3.Add(new KeyValuePair<int, BattleDiceCardModel>(priority2, item3));
			}
		}
		if (list3.Count > 0)
		{
			list3.Sort((KeyValuePair<int, BattleDiceCardModel> x, KeyValuePair<int, BattleDiceCardModel> y) => y.Key - x.Key);
			int targetPriority = list3[0].Key;
			List<BattleDiceCardModel> list4 = new List<BattleDiceCardModel>();
			foreach (KeyValuePair<int, BattleDiceCardModel> item4 in list3.FindAll((KeyValuePair<int, BattleDiceCardModel> x) => x.Key == targetPriority))
			{
				list4.Add(item4.Value);
			}
			BattleDiceCardModel origin = RandomUtil.SelectOne(list4);
			origin = _self.OnSelectCardAuto(origin, currentDiceSlotIdx);
			BattleUnitModel targetByCard = BattleObjectManager.instance.GetTargetByCard(_self, origin, currentDiceSlotIdx, _self.TeamKill());
			int targetSlot = 0;
			if (targetByCard != null)
			{
				targetSlot = UnityEngine.Random.Range(0, targetByCard.speedDiceResult.Count);
				targetSlot = _self.ChangeTargetSlot(origin, targetByCard, currentDiceSlotIdx, targetSlot, _self.TeamKill());
			}
			if (targetByCard != null)
			{
				UseCard(origin);
				_self.cardSlotDetail.AddCard(origin, targetByCard, targetSlot, isEnemyAuto: true);
				return;
			}
		}
		_ = list2.Count;
	}

	public void PlayTurnAutoForPlayer(int idx)
	{
		if (_self.turnState == BattleUnitTurnState.BREAK || _self.IsBreakLifeZero() || _self.IsKnockout())
		{
			return;
		}
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>(_cardInHand);
		List<BattleDiceCardModel> list2 = new List<BattleDiceCardModel>();
		list.RemoveAll((BattleDiceCardModel x) => x.GetSpec().Ranged == CardRange.Instance);
		foreach (BattleDiceCardModel item in list)
		{
			if (_self.CheckCardAvailableForPlayer(item))
			{
				list2.Add(item);
			}
		}
		List<KeyValuePair<int, BattleDiceCardModel>> list3 = new List<KeyValuePair<int, BattleDiceCardModel>>();
		if (_self.cardSlotDetail.PlayPoint - _self.cardSlotDetail.ReservedPlayPoint >= _self.cardSlotDetail.GetMaxPlayPoint())
		{
			foreach (BattleDiceCardModel item2 in list2)
			{
				if (item2.GetCost() == 0)
				{
					list3.Add(new KeyValuePair<int, BattleDiceCardModel>(item2.GetPriority() - 10, item2));
				}
				else
				{
					list3.Add(new KeyValuePair<int, BattleDiceCardModel>(item2.GetPriority(), item2));
				}
			}
		}
		else
		{
			foreach (BattleDiceCardModel item3 in list2)
			{
				list3.Add(new KeyValuePair<int, BattleDiceCardModel>(item3.GetPriority(), item3));
			}
		}
		if (list3.Count > 0)
		{
			list3.Sort((KeyValuePair<int, BattleDiceCardModel> x, KeyValuePair<int, BattleDiceCardModel> y) => y.Key - x.Key);
			int targetPriority = list3[0].Key;
			List<BattleDiceCardModel> list4 = new List<BattleDiceCardModel>();
			foreach (KeyValuePair<int, BattleDiceCardModel> item4 in list3.FindAll((KeyValuePair<int, BattleDiceCardModel> x) => x.Key == targetPriority))
			{
				list4.Add(item4.Value);
			}
			BattleDiceCardModel card = RandomUtil.SelectOne(list4);
			BattleUnitModel targetByCardForPlayer = BattleObjectManager.instance.GetTargetByCardForPlayer(_self, card, idx, _self.TeamKill());
			int max = targetByCardForPlayer.speedDiceResult.Count;
			if (!targetByCardForPlayer.IsTargetable_theLast() && targetByCardForPlayer.speedDiceResult.Count > 1)
			{
				max = 1;
			}
			int targetSlot = UnityEngine.Random.Range(0, max);
			if (targetByCardForPlayer != null)
			{
				targetSlot = UnityEngine.Random.Range(0, max);
				targetSlot = _self.ChangeTargetSlot(card, targetByCardForPlayer, idx, targetSlot, _self.TeamKill());
			}
			if (targetByCardForPlayer != null)
			{
				_self.cardSlotDetail.AddCard(card, targetByCardForPlayer, targetSlot);
				return;
			}
		}
		_ = list2.Count;
	}

	public void OnRoundStart()
	{
		foreach (BattleDiceCardModel item in GetAllDeck())
		{
			item.OnRoundStart();
		}
		BattleDiceCardModel[] array = _cardInHand.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].OnRoundStart_inHand(_self);
		}
	}

	public void OnBreakState()
	{
		BattleDiceCardModel[] array = _cardInHand.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].OnBreakState_inHand(_self);
		}
	}

	public void OnDrawCard()
	{
		foreach (BattleDiceCardModel item in GetAllDeck())
		{
			item.OnDrawCard();
		}
	}

	public void OnUseCard(BattlePlayingCardDataInUnitModel curCard)
	{
		BattleDiceCardModel[] array = _cardInHand.ToArray();
		foreach (BattleDiceCardModel battleDiceCardModel in array)
		{
			if (curCard.card != battleDiceCardModel)
			{
				battleDiceCardModel.OnUseOtherCard_inHand(_self, curCard);
			}
		}
	}

	public void OnLoseParrying(BattleDiceBehavior behavior)
	{
		BattleDiceCardModel[] array = _cardInHand.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].OnLoseParrying_inHand(_self, behavior);
		}
	}

	public void OnWinParrying(BattleDiceBehavior behavior)
	{
		BattleDiceCardModel[] array = _cardInHand.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].OnWinParrying_inHand(_self, behavior);
		}
	}

	public void OnRoundEnd_before()
	{
		BattleDiceCardModel[] array = GetAllDeck().ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].OnRoundEnd(_self);
		}
		array = _cardInHand.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].OnRoundEnd_inHand(_self);
		}
	}

	public void OnRoundEnd()
	{
		foreach (BattleDiceCardModel item in GetAllDeck())
		{
			item.OnRoundEnd();
		}
		List<BattleDiceCardModel> list = new List<BattleDiceCardModel>();
		list.AddRange(GetAllDeck().FindAll((BattleDiceCardModel x) => x.temporary));
		foreach (BattleDiceCardModel item2 in list)
		{
			if (_cardInUse.Contains(item2))
			{
				_cardInUse.Remove(item2);
			}
			if (_cardInDeck.Contains(item2))
			{
				_cardInDeck.Remove(item2);
			}
			if (_cardInHand.Contains(item2))
			{
				_cardInHand.Remove(item2);
			}
			if (_cardInDiscarded.Contains(item2))
			{
				_cardInDiscarded.Remove(item2);
			}
			if (_cardInReserved.Contains(item2))
			{
				_cardInReserved.Remove(item2);
			}
		}
	}
}
