using System;
using System.Collections.Generic;
using LOR_DiceSystem;
using UnityEngine;

public class BattleDiceBehavior
{
	public DiceBehaviour behaviourInCard;

	public List<DiceCardAbilityBase> abilityList = new List<DiceCardAbilityBase>();

	public BattlePlayingCardDataInUnitModel card;

	public bool isBonusEvasion;

	public bool isBonusAttack;

	public bool winAgainstFarAtk;

	public bool isUsed;

	public bool forbiddenBonusDice;

	protected int _diceResultValue;

	protected int _damageReductionByGuard;

	protected bool _isParrying;

	protected BattleDiceBehavior _targetDice;

	protected bool _ignoreKnockback;

	protected bool _diceDestroyed;

	private int _diceFinalResultValue;

	private bool _isBlocked;

	private int _diceResultDamage;

	private int _diceDamageAll;

	public DiceUITiming destroyedTiming;

	public bool breakState;

	public bool passingEvasion;

	private DiceStatBonus _statBonus = new DiceStatBonus();

	private DiceStatBonus _firstStatBonus;

	public List<DiceFlag> _flags = new List<DiceFlag>();

	private List<BattleUnitModel> _aliveOpponentList = new List<BattleUnitModel>();

	private int _index;

	private DiceEffectType _effectType = DiceEffectType.None;

	public BattleUnitModel owner => card.owner;

	public BehaviourType Type => behaviourInCard.Type;

	public BehaviourDetail Detail => behaviourInCard.Detail;

	public int DiceResultValue => _diceFinalResultValue;

	public int DiceVanillaValue => _diceResultValue;

	public bool DiceDestroyed => _diceDestroyed;

	public int DiceResultDamage => _diceResultDamage;

	public BattleDiceBehavior TargetDice => _targetDice;

	public int DiceFaceAdder => _statBonus.face;

	public int DamageAdder => _statBonus.dmg;

	public int BreakAdder => _statBonus.breakDmg;

	public int PowerAdder => _statBonus.power;

	public int GuardBreakAdder => _statBonus.guardBreakAdder;

	public int GuardBreakMultiplier => _statBonus.guardBreakMultiplier;

	public bool IsBlocked => _isBlocked;

	public int Index => _index;

	public DiceEffectType EffectType => _effectType;

	public bool CheckUsedBehaviourState()
	{
		if (breakState || DiceDestroyed)
		{
			return false;
		}
		return true;
	}

	public void SetIndex(int index)
	{
		_index = index;
	}

	public void AddAbility(DiceCardAbilityBase ability)
	{
		ability.behavior = this;
		abilityList.Add(ability);
	}

	public void UpdateDiceFinalValue()
	{
		if (abilityList.Exists((DiceCardAbilityBase x) => x.Invalidity))
		{
			_diceFinalResultValue = 0;
			return;
		}
		int diceResultValue = _diceResultValue;
		if (_statBonus.ignorePower)
		{
			return;
		}
		if (card != null)
		{
			if (card.ignorePower)
			{
				_diceFinalResultValue = Mathf.Max(1, diceResultValue);
				return;
			}
			if (owner != null && owner.IsNullifyPower())
			{
				_diceFinalResultValue = Mathf.Max(1, diceResultValue);
				return;
			}
		}
		int num = _statBonus.power;
		if (abilityList.Find((DiceCardAbilityBase x) => x.IsDoublePower()) != null)
		{
			num += _statBonus.power;
		}
		if (owner != null && owner.IsHalfPower())
		{
			num /= 2;
		}
		diceResultValue += num;
		_diceFinalResultValue = Mathf.Max(1, diceResultValue);
	}

	public int GetDiceVanillaMax()
	{
		return behaviourInCard.Dice;
	}

	public int GetDiceVanillaMin()
	{
		return behaviourInCard.Min;
	}

	public int GetDiceMin()
	{
		int min = behaviourInCard.Min;
		min += _statBonus.min;
		return Mathf.Max(1, min);
	}

	public int GetDiceMax()
	{
		int dice = behaviourInCard.Dice;
		dice += _statBonus.face * 3;
		dice += _statBonus.max;
		return Mathf.Max(1, dice);
	}

	public void BeforeRollDice(BattleDiceBehavior targetDice)
	{
		_targetDice = targetDice;
		if (_firstStatBonus != null)
		{
			_statBonus = _firstStatBonus.Copy();
		}
		else
		{
			_firstStatBonus = _statBonus.Copy();
		}
		OnEventDiceAbility(DiceCardAbilityBase.DiceCardPassiveType.BeforeRollDice);
	}

	public void CopyAbilityAndStat(BattleDiceBehavior behavior)
	{
		abilityList = behavior.abilityList;
		foreach (DiceCardAbilityBase ability in abilityList)
		{
			ability.behavior = this;
		}
		_statBonus = behavior._statBonus.Copy();
		_firstStatBonus = behavior._firstStatBonus.Copy();
	}

	public void RollDice()
	{
		int diceMin = GetDiceMin();
		int diceMax = GetDiceMax();
		int num = Mathf.Min(diceMin, diceMax);
		_diceResultValue = DiceStatCalculator.MakeDiceResult(diceMin, diceMax, 0);
		owner.passiveDetail.ChangeDiceResult(this, ref _diceResultValue);
		owner.emotionDetail.ChangeDiceResult(this, ref _diceResultValue);
		owner.bufListDetail.ChangeDiceResult(this, ref _diceResultValue);
		if (_diceResultValue < num)
		{
			_diceResultValue = num;
		}
		int num2 = 0;
		int num3 = 0;
		if (num != diceMax)
		{
			if (_diceResultValue >= diceMax)
			{
				num2++;
			}
			else if (_diceResultValue <= num)
			{
				num3++;
			}
		}
		if (_diceResultValue < 1)
		{
			_diceResultValue = 1;
		}
		if (num2 > 0)
		{
			int count = owner.emotionDetail.CreateEmotionCoin(EmotionCoinType.Positive, num2);
			owner.battleCardResultLog?.AddEmotionCoin(EmotionCoinType.Positive, count);
		}
		else if (num3 > 0)
		{
			int count2 = owner.emotionDetail.CreateEmotionCoin(EmotionCoinType.Negative, num3);
			owner.battleCardResultLog?.AddEmotionCoin(EmotionCoinType.Negative, count2);
		}
		card.OnRollDice(this);
		OnEventDiceAbility(DiceCardAbilityBase.DiceCardPassiveType.RollDice);
		isUsed = true;
	}

	public bool IsParrying()
	{
		return _targetDice != null;
	}

	public void SetDamageRedution(int value)
	{
		_damageReductionByGuard = value;
	}

	public void SetBlocked(bool b)
	{
		_isBlocked = b;
	}

	public void AddDiceFace(int value)
	{
		_statBonus.face += value;
	}

	public void SetDiceEffect(DiceEffectType type)
	{
		_effectType = type;
	}

	public void DestroyDice(DiceUITiming timing)
	{
		if (!_diceDestroyed)
		{
			if (abilityList.Exists((DiceCardAbilityBase x) => x.IsImmuneDestory))
			{
				return;
			}
			_diceDestroyed = true;
			destroyedTiming = timing;
		}
		Singleton<StageController>.Instance.IsLogState();
	}

	public void ApplyDiceStatBonus(DiceStatBonus bonus)
	{
		_statBonus.dmg += bonus.dmg;
		_statBonus.breakDmg += bonus.breakDmg;
		_statBonus.power += bonus.power;
		_statBonus.face += bonus.face;
		_statBonus.min += bonus.min;
		_statBonus.max += bonus.max;
		_statBonus.dmgRate += bonus.dmgRate;
		_statBonus.breakRate += bonus.breakRate;
		_statBonus.guardBreakAdder += bonus.guardBreakAdder;
		_statBonus.guardBreakMultiplier *= bonus.guardBreakMultiplier;
		if (bonus.ignorePower)
		{
			_statBonus.ignorePower = true;
		}
	}

	public void AddFlag(DiceFlag flag)
	{
		_flags.Add(flag);
	}

	public bool HasFlag(DiceFlag flag)
	{
		return _flags.Exists((DiceFlag x) => x == flag);
	}

	public void GiveDamage(BattleUnitModel target)
	{
		if (target == null)
		{
			return;
		}
		bool flag = target.IsDead();
		DiceStatBonus statBonus = _statBonus.Copy();
		abilityList.ForEach(delegate(DiceCardAbilityBase x)
		{
			x.BeforeGiveDamage();
		});
		abilityList.ForEach(delegate(DiceCardAbilityBase x)
		{
			x.BeforeGiveDamage(target);
		});
		owner.BeforeGiveDamage(this);
		int diceResultValue = DiceResultValue;
		if (diceResultValue >= 30 && card.target.bufListDetail.GetActivatedBuf(KeywordBuf.ClawCounter) != null)
		{
			SetBlocked(b: true);
			card.target.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_clawCounter));
		}
		if (_isBlocked)
		{
			_statBonus = statBonus;
			owner.battleCardResultLog.SetIsBlocked(blocked: true);
			return;
		}
		double num = diceResultValue - _damageReductionByGuard + _statBonus.dmg + owner.UnitData.unitData.giftInventory.GetStatBonus_Dmg(behaviourInCard.Detail);
		num -= (double)target.GetDamageReduction(this);
		int num2 = _statBonus.dmgRate + target.GetDamageIncreaseRate();
		float num3 = 1f + (float)num2 / 100f;
		if (num3 < 0f)
		{
			num3 = 0f;
		}
		num *= (double)num3;
		num *= (double)target.GetDamageRate();
		if (target.emotionDetail.IsTakeDamageDouble())
		{
			num *= 2.0;
		}
		if (owner.emotionDetail.IsGiveDamageDouble())
		{
			num *= 2.0;
		}
		double num4 = diceResultValue - _damageReductionByGuard + _statBonus.breakDmg;
		num4 -= (double)target.GetBreakDamageReduction(this);
		_damageReductionByGuard = 0;
		int num5 = _statBonus.breakRate + target.GetBreakDamageIncreaseRate();
		num4 *= (double)(1f + (float)num5 / 100f);
		num4 *= (double)target.GetBreakDamageRate();
		_ = (target.view.WorldPosition - owner.view.WorldPosition).normalized;
		AtkResist atkResist = AtkResist.Normal;
		AtkResist atkResist2 = AtkResist.Normal;
		atkResist = target.GetResistHP(behaviourInCard.Detail);
		atkResist2 = target.GetResistBP(behaviourInCard.Detail);
		bool flag2 = false;
		foreach (DiceCardAbilityBase ability in abilityList)
		{
			if (ability.IsPercentDmg)
			{
				flag2 = true;
				break;
			}
		}
		if (flag2)
		{
			int num6 = int.MaxValue;
			foreach (DiceCardAbilityBase ability2 in abilityList)
			{
				int maximumPercentDmg = ability2.GetMaximumPercentDmg();
				if (maximumPercentDmg < num6)
				{
					num6 = maximumPercentDmg;
				}
			}
			double num7 = (double)target.MaxHp * (num / 100.0);
			if (num7 >= (double)target.MaxHp)
			{
				num7 = target.MaxHp;
			}
			num = Mathf.Min((float)(num7 * (double)BookModel.GetResistRate(AtkResist.Weak)), num6);
		}
		else
		{
			num *= (double)BookModel.GetResistRate(atkResist);
		}
		num4 *= (double)BookModel.GetResistRate(atkResist2);
		num = target.ChangeDamage(owner, num);
		if (card != null && card.cardAbility != null && card.cardAbility.IsTrueDamage())
		{
			num = diceResultValue;
			num4 = diceResultValue;
		}
		int num8 = (int)num;
		int num9 = (int)num4;
		if (num8 < 1)
		{
			num8 = 0;
		}
		if (abilityList.Exists((DiceCardAbilityBase x) => x.Invalidity))
		{
			num8 = 0;
			num9 = 0;
		}
		if (num9 < 1)
		{
			num9 = 0;
		}
		if (card.card.GetSpec().Ranged == CardRange.Far && target.passiveDetail.IsImmuneByFarAtk())
		{
			num8 = 0;
			num9 = 0;
		}
		if (target.passiveDetail.IsInvincible())
		{
			num8 = 0;
			num9 = 0;
		}
		num8 = target.TakeDamage(num8, DamageType.Attack, owner);
		owner.emotionDetail.CheckDmg(num8, target);
		owner.passiveDetail.AfterGiveDamage(num8);
		if (card.cardAbility != null)
		{
			card.cardAbility.AfterGiveDamage(num8, target);
		}
		target.TakeBreakDamage(num9, DamageType.Attack, owner, atkResist2);
		_diceResultDamage = num8;
		_diceDamageAll += num8;
		owner.battleCardResultLog.SetDamageGiven(num8);
		owner.battleCardResultLog.SetBreakDmgGiven(num9);
		target.battleCardResultLog.SetDeathState(target.IsDeadReal());
		owner.history.damageAtOneRoundByDice += num8;
		if (target.faction == Faction.Player)
		{
			if (owner.UnitData.unitData.EnemyUnitId == 20003 || owner.UnitData.unitData.EnemyUnitId == 20002)
			{
				target.UnitData.historyInStage.damagedByIsadoraJulia++;
			}
			if (target.Book.GetBookClassInfoId() == 200004)
			{
				target.UnitData.unitData.history.damagedFinnBook++;
			}
		}
		if (!target.IsDead())
		{
			target.OnTakeDamageByAttack(this, num8);
			target.OnTakeBreakDamageByAttack(this, num9);
		}
		if (!flag)
		{
			CardRange ranged = card.card.GetSpec().Ranged;
			if (ranged == CardRange.FarArea || ranged == CardRange.FarAreaEach)
			{
				card.OnSucceedAreaAttack(target);
				owner.OnSucceedAreaAttack(this, target);
				try
				{
					abilityList.ForEach(delegate(DiceCardAbilityBase x)
					{
						x.OnSucceedAreaAttack(target);
					});
					abilityList.ForEach(delegate(DiceCardAbilityBase x)
					{
						x.OnSucceedAttack(target);
					});
				}
				catch (Exception message)
				{
					Debug.LogError("card internal error");
					Debug.LogError(message);
				}
			}
			else
			{
				OnEventDiceAbility(DiceCardAbilityBase.DiceCardPassiveType.SuccessAtk, target);
			}
			card.OnSucceedAttack(this);
			owner.battleCardResultLog.SetSucceedAtkEvent(delegate
			{
				card.OnSucceedAtkEvent();
			});
			owner.battleCardResultLog.SetSucceedAtkEvent(delegate
			{
				owner.passiveDetail.OnSucceedAttackEvent(this);
			});
			if (owner.faction == Faction.Player && target.faction == Faction.Enemy && _diceResultDamage >= 150 && card.card.GetID() != 9909999)
			{
				Singleton<StageController>.Instance.UnlockAchievement(AchievementEnum.ONCE_BIG_DAMAGE);
			}
			if (owner.faction == Faction.Player && _aliveOpponentList.Count >= 5 && _aliveOpponentList.FindAll((BattleUnitModel x) => x.IsDead()).Count >= 5)
			{
				PlatformManager.Instance.UnlockAchievement(AchievementEnum.ONCE_AREA_KILL);
			}
		}
		_statBonus = statBonus;
	}

	public void GiveDeflectDamage(BattleDiceBehavior targetDice)
	{
		if (targetDice != null)
		{
			int diceResultValue = DiceResultValue;
			int num = 0;
			if (IsAttackDice(targetDice.Detail))
			{
				num = targetDice.DiceResultValue;
			}
			int num2 = (diceResultValue - num + GuardBreakAdder) * GuardBreakMultiplier;
			num2 += targetDice.owner.GetTakenGuardBreakDamageAdder(num2);
			owner.history.counterDamageAtOneRound += num2;
			targetDice.owner.TakeBreakDamage(num2, DamageType.Rebound, owner);
			owner.history.counterDamageAtOneRound += num2;
			owner.emotionDetail.OnGiveDeflect(this);
			if (owner.faction == Faction.Player && targetDice.owner.faction == Faction.Enemy && targetDice.owner.IsBreakLifeZero())
			{
				PlatformManager.Instance.UnlockAchievement(AchievementEnum.ONCE_DEFLECT);
			}
		}
	}

	public void OnEndFarAreaBehaviourAtk(List<BattleUnitModel> damagedList, List<BattleUnitModel> defensedList)
	{
		if (abilityList == null)
		{
			return;
		}
		foreach (DiceCardAbilityBase ability in abilityList)
		{
			try
			{
				ability?.OnAfterAreaAtk(damagedList, defensedList);
			}
			catch (Exception message)
			{
				Debug.Log(message);
			}
		}
	}

	private void SaveBeforeRollDiceStateForAchievements()
	{
		_aliveOpponentList.Clear();
		if (!PlatformManager.Instance.AchievementUnlocked(AchievementEnum.ONCE_AREA_KILL))
		{
			CardRange ranged = card.card.GetSpec().Ranged;
			if (ranged == CardRange.FarAreaEach || ranged == CardRange.FarArea)
			{
				_aliveOpponentList = BattleObjectManager.instance.GetAliveList_opponent(owner.faction);
			}
		}
	}

	public void OnEventDiceAbility(DiceCardAbilityBase.DiceCardPassiveType dicePassiveType, BattleUnitModel target = null)
	{
		try
		{
			bool activateByResult = false;
			switch (dicePassiveType)
			{
			case DiceCardAbilityBase.DiceCardPassiveType.BeforeRollDice:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.BeforeRollDice();
				});
				activateByResult = false;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.RollDice:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnRollDice();
				});
				activateByResult = false;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.AfterAction:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.AfterAction();
				});
				activateByResult = true;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.WinParryingAtk:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnWinParrying();
				});
				activateByResult = true;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.WinParryingDfn:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnWinParrying();
				});
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnWinParryingDefense();
				});
				activateByResult = true;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.SuccessAtk:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnSucceedAttack();
				});
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnSucceedAttack(target);
				});
				activateByResult = true;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.LoseParrying:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnLoseParrying();
				});
				activateByResult = true;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.DrawParrying:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnDrawParrying();
				});
				activateByResult = true;
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.SuccessDefense:
				abilityList?.ForEach(delegate(DiceCardAbilityBase x)
				{
					x?.OnWinParryingDefense();
				});
				activateByResult = true;
				break;
			}
			owner?.battleCardResultLog?.SetDiceBehaviourAbility(activateByResult, this, card.card);
			switch (dicePassiveType)
			{
			case DiceCardAbilityBase.DiceCardPassiveType.BeforeRollDice:
				owner?.BeforeRollDice(this);
				SaveBeforeRollDiceStateForAchievements();
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.RollDice:
				owner?.OnRollDice(this);
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.AfterAction:
				owner?.AfterDiceAction(this);
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.WinParryingAtk:
				owner?.OnWinParrying(this);
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.WinParryingDfn:
				owner?.OnWinParrying(this);
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.SuccessAtk:
				owner?.OnSucceedAttack(this);
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.LoseParrying:
				owner?.OnLoseParrying(this);
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.DrawParrying:
				owner?.OnDrawParrying(this);
				break;
			case DiceCardAbilityBase.DiceCardPassiveType.None:
			case DiceCardAbilityBase.DiceCardPassiveType.SuccessDefense:
				break;
			}
		}
		catch (Exception message)
		{
			Debug.LogError("card internal error");
			Debug.LogError(message);
		}
	}

	public int GetScope()
	{
		return 4;
	}

	private bool IsAttackDice(BehaviourDetail diceDetail)
	{
		if (diceDetail != BehaviourDetail.Slash && diceDetail != BehaviourDetail.Penetrate)
		{
			return diceDetail == BehaviourDetail.Hit;
		}
		return true;
	}
}
