using System.Collections.Generic;
using LOR_XML;

public class BattleCardDescXmlList : Singleton<BattleCardDescXmlList>
{
	private Dictionary<LorId, BattleCardDesc> _dictionary;

	public void Init(Dictionary<LorId, BattleCardDesc> dictionary)
	{
		_dictionary = dictionary;
	}

	public BattleCardDesc GetCardDesc(LorId cardID)
	{
		BattleCardDesc battleCardDesc = null;
		if (cardID == 705010)
		{
			cardID = new LorId(707001);
		}
		if (_dictionary.ContainsKey(cardID))
		{
			battleCardDesc = _dictionary[cardID];
		}
		else
		{
			battleCardDesc = new BattleCardDesc();
			battleCardDesc.cardID = -1;
			battleCardDesc.cardName = "";
			battleCardDesc.behaviourDescList = new List<CardBehaviourDesc>();
			battleCardDesc.behaviourDescList.Add(new CardBehaviourDesc
			{
				behaviourID = -1,
				behaviourDesc = "Unknown"
			});
		}
		return battleCardDesc;
	}

	public string GetCardName(LorId cardID)
	{
		string result = "Not Found";
		if (cardID == 705010)
		{
			cardID = new LorId(707001);
		}
		if (_dictionary.ContainsKey(cardID))
		{
			result = _dictionary[cardID].cardName;
		}
		return result;
	}

	public string GetAbilityDesc(LorId cardID)
	{
		string result = string.Empty;
		if (_dictionary.ContainsKey(cardID))
		{
			result = _dictionary[cardID].ability;
		}
		return result;
	}

	public string GetBehaviourDesc(LorId cardID, int behaviourIdx)
	{
		string result = string.Empty;
		if (_dictionary.ContainsKey(cardID))
		{
			result = ((!_dictionary[cardID].behaviourDescList.Exists((CardBehaviourDesc x) => x.behaviourID == behaviourIdx)) ? string.Empty : _dictionary[cardID].behaviourDescList.Find((CardBehaviourDesc x) => x.behaviourID == behaviourIdx).behaviourDesc);
		}
		return result;
	}
}
