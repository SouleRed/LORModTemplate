public enum ActionTextMode
{
	Rencounter,
	None
}
