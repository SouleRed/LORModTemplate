public enum ActionStartDirection
{
	Middle,
	LeftUp,
	RightUp
}
