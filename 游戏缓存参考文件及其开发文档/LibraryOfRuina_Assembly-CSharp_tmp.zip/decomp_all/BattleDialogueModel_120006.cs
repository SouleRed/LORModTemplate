using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_120006 : BattleDialogueModel
{
	public BattleDialogueModel_120006(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType, List<BattleUnitModel> targets)
	{
		string result = base.GetBattleDlg(dlgType, targets);
		switch (dlgType)
		{
		case DialogType.COLLEAGUE_DEATH:
		{
			List<BattleUnitModel> aliveList2 = BattleObjectManager.instance.GetAliveList(Faction.Enemy);
			BattleUnitModel battleUnitModel3 = aliveList2.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120007);
			BattleUnitModel battleUnitModel4 = aliveList2.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120005);
			bool num = targets.Exists((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120007);
			bool flag3 = targets.Exists((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120005);
			if (num)
			{
				result = ((battleUnitModel4 != null) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_4") : GetBattleDlgSpecialEvent("SPECIAL_EVENT_3"));
			}
			else if (flag3)
			{
				result = ((battleUnitModel3 != null) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_5") : GetBattleDlgSpecialEvent("SPECIAL_EVENT_3"));
			}
			break;
		}
		case DialogType.DEATH:
		{
			List<BattleUnitModel> aliveList = BattleObjectManager.instance.GetAliveList(Faction.Enemy);
			BattleUnitModel battleUnitModel = aliveList.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120007);
			BattleUnitModel battleUnitModel2 = aliveList.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120005);
			bool flag = battleUnitModel == null;
			bool flag2 = battleUnitModel2 == null;
			if (flag && flag2)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_2");
			}
			else if (flag2)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_1");
			}
			else if (flag)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
			break;
		}
		}
		return result;
	}
}
