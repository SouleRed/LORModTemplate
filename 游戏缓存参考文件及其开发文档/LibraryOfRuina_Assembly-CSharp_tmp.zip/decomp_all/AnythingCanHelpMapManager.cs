using UnityEngine;

public class AnythingCanHelpMapManager : CreatureMapManager
{
	private bool _bPassiveActivated;

	[SerializeField]
	private SpriteRenderer _breakFilter;

	[SerializeField]
	private SpriteRenderer _egoAreaAtkFilter;

	public void SetBreakFilter(bool b)
	{
		_breakFilter.enabled = b;
	}

	public void SetEgoAreaAtkFilter(bool b)
	{
		_egoAreaAtkFilter.enabled = b;
	}

	public void SetPassiveActivatedFilter(bool b)
	{
		_bPassiveActivated = b;
	}

	public override void InitializeMap()
	{
		base.InitializeMap();
		_creatureDlgIdList.Add("Helper_nomal_1");
		_creatureDlgIdList.Add("Helper_nomal_2");
		_creatureDlgIdList.Add("Helper_nomal_3");
		_creatureDlgIdList.Add("Helper_nomal_4");
		_creatureDlgIdList.Add("Helper_nomal_5");
		_creatureDlgIdList.Add("Helper_passive_1");
		_creatureDlgIdList.Add("Helper_passive_2");
		_creatureDlgIdList.Add("Helper_passive_3");
		_creatureDlgIdList.Add("Helper_passive_4");
		_creatureDlgIdList.Add("Helper_passive_5");
		_bPassiveActivated = false;
		CreateDialog();
		_breakFilter.enabled = false;
	}

	public override void ChangeDlgByBoss()
	{
		base.ChangeDlgByBoss();
		_creatureDlgIdList.Add("Y_Angela_Helper_1");
		_creatureDlgIdList.Add("Y_Angela_Helper_2");
		_creatureDlgIdList.Add("Y_Angela_Helper_3");
		_creatureDlgIdList.Add("Y_Angela_Helper_4");
		_creatureDlgIdList.Add("Y_Angela_Helper_5");
		_creatureDlgIdList.Add("Y_Angela_Helper_6");
		_creatureDlgIdList.Add("Y_Angela_Helper_7");
		_creatureDlgIdList.Add("Y_Angela_Helper_8");
		_creatureDlgIdList.Add("Y_Angela_Helper_9");
		_creatureDlgIdList.Add("Y_Angela_Helper_10");
		CreateDialog();
	}

	public override void CreateDialog()
	{
		if (isBossPhase)
		{
			_dlgIdx %= 10;
		}
		else if (_bPassiveActivated)
		{
			if (_dlgIdx < 5 || _dlgIdx > 9)
			{
				_dlgIdx = 5;
			}
		}
		else
		{
			_dlgIdx %= 5;
		}
		base.CreateDialog();
	}

	protected override void Update()
	{
		base.Update();
		if (_breakFilter.enabled)
		{
			float a = Mathf.PingPong(Time.time * 2f, 0.3f) + 0.7f;
			Color color = _breakFilter.color;
			color.a = a;
			_breakFilter.color = color;
		}
		if (_egoAreaAtkFilter.enabled)
		{
			ReviseFilterTransform(_egoAreaAtkFilter);
			float a2 = Mathf.PingPong(Time.time * 2f, 0.3f) + 0.7f;
			Color color2 = _egoAreaAtkFilter.color;
			color2.a = a2;
			_egoAreaAtkFilter.color = color2;
		}
	}
}
