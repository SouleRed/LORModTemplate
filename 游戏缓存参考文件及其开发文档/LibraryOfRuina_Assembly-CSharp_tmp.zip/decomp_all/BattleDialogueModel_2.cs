using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_2 : BattleDialogueModel_Sephirah
{
	private string _groupId_Default = "LibraryOfRuina";

	private string _characterId_Default = "Yesod";

	private int _stageId_RB1 = 70002;

	private string _groupId_RB1 = "The Blue Reverberation2 Yesod";

	private string _characterId_RB1 = "Y_E_Yesod";

	private SpecialBattleDialog _specialDialogs;

	public BattleDialogueModel_2(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_specialDialogs = new SpecialBattleDialog();
		_specialDialogs.SetBattleDialog(_groupId_Default, _characterId_Default);
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		LorId id = Singleton<StageController>.Instance.GetStageModel().ClassInfo.id;
		if (id == _stageId_RB1)
		{
			return GetBattleDlg_RB1(dlgType);
		}
		if (id == 60003)
		{
			return GetBattleDlg_BS(dlgType, SephirahType.Yesod, "Yesod");
		}
		if (id == 60004)
		{
			return GetBattleDlg_RB2(dlgType, SephirahType.Yesod, "Yesod");
		}
		return GetNormalBattleDlg(dlgType);
	}

	private string GetBattleDlg_RB1(DialogType dlgType)
	{
		string text = string.Empty;
		if (!_specialDialogs.AccordWith(_groupId_RB1, _characterId_RB1))
		{
			_specialDialogs.SetBattleDialog(_groupId_RB1, _characterId_RB1);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = dialogDictionary[dlgType];
			if (list.Count > 0)
			{
				text = list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetNormalBattleDlg(DialogType dlgType)
	{
		if (_xmlInfo.characterID != _characterId_Default)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData(_groupId_Default, _characterId_Default);
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}
}
