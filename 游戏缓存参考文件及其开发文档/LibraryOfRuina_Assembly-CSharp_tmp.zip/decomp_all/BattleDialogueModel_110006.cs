using LOR_XML;

public class BattleDialogueModel_110006 : BattleDialogueModel
{
	public BattleDialogueModel_110006(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.START_BATTLE)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetAliveList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 10);
			if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Keter && battleUnitModel != null)
			{
				result = ((battleUnitModel.UnitData.unitData.history.killMarsInStreetLightEp1 != 1) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_2") : GetBattleDlgSpecialEvent("SPECIAL_EVENT_0"));
			}
		}
		return result;
	}
}
