using UnityEngine;

public class BattleCamera
{
	private bool _on;

	private bool _posOn;

	private Vector3 _startZoomPos;

	private float _startZoomSize;

	private float _zoomTime;

	private float _elapsedTime;

	public void ReturnCameraState(float time)
	{
	}

	public void StopZoom()
	{
		_on = false;
	}

	public bool IsZoomOn()
	{
		return _on;
	}

	public void OnUpdate()
	{
		_elapsedTime += Time.unscaledDeltaTime;
		if (_elapsedTime >= _zoomTime)
		{
			_on = false;
		}
	}
}
