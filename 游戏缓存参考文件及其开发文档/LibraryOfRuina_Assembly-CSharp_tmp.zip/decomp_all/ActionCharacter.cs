using System.Collections;
using Battle.DiceAttackEffect;
using UnityEngine;

public class ActionCharacter : MonoBehaviour
{
	public Transform spriteRoot;

	public Transform effectRoot;

	public bool isActionEnd = true;

	public bool isReadyAction = true;

	[SerializeField]
	private CharacterAppearance _cloneAppearance;

	public Direction direction
	{
		get
		{
			if (base.transform.localScale.x > 0f)
			{
				return Direction.LEFT;
			}
			return Direction.RIGHT;
		}
		set
		{
			Vector3 localScale = base.transform.localScale;
			localScale.x = Mathf.Abs(localScale.x) * (float)((value != Direction.RIGHT) ? 1 : (-1));
			base.transform.localScale = localScale;
		}
	}

	public void Initialize(CharacterAppearance cloneAppearance)
	{
		_cloneAppearance = Object.Instantiate(cloneAppearance, spriteRoot);
		_cloneAppearance.isActionCharacter = true;
		_cloneAppearance.transform.localScale = Vector3.one * 0.5f;
		_cloneAppearance.ChangeLayer("Focus_UnitAction");
	}

	public void ResetAction()
	{
		DiceAttackEffect[] componentsInChildren = effectRoot.GetComponentsInChildren<DiceAttackEffect>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Object.Destroy(componentsInChildren[i].gameObject);
		}
		DamageText[] componentsInChildren2 = effectRoot.GetComponentsInChildren<DamageText>();
		for (int i = 0; i < componentsInChildren2.Length; i++)
		{
			Object.Destroy(componentsInChildren2[i].gameObject);
		}
		if (_cloneAppearance != null)
		{
			Object.Destroy(_cloneAppearance.gameObject);
		}
		isActionEnd = true;
	}

	public void BeforeAction(ResultData r)
	{
		isReadyAction = false;
		if (r.actionType == ActionType.Atk && _cloneAppearance.GetCurrentMotionDetail() == r.actionDetail)
		{
			StartCoroutine(ReadyAction());
		}
		else
		{
			isReadyAction = true;
		}
	}

	private IEnumerator ReadyAction()
	{
		_cloneAppearance.ChangeMotion(ActionDetail.Default);
		yield return YieldCache.WaitForSeconds(0.2f);
		isReadyAction = true;
	}

	public void DoAction(ResultData r, Vector3 dstPos)
	{
		isActionEnd = false;
		_cloneAppearance.ChangeMotion(r.actionDetail);
		base.transform.position = dstPos;
		if (r.actionDetail != ActionDetail.Evade && r.actionDetail != ActionDetail.Guard)
		{
			_ = r.actionDetail;
			_ = 3;
		}
		StartCoroutine(AfterAction(r));
	}

	private IEnumerator AfterAction(ResultData r)
	{
		float num = 0f;
		if (r.actionType == ActionType.Atk)
		{
			num = ((r.result == Result.Win) ? (-1f) : ((r.result != Result.Draw) ? 2f : 2f));
		}
		else if (r.actionType == ActionType.Def)
		{
			if (r.result != Result.Win && r.result != Result.Draw)
			{
				num = 2f;
			}
		}
		else if (r.result == Result.Win)
		{
			Debug.Log("ActionCharacter ?");
		}
		else if (r.result != Result.Draw)
		{
			num = 2f;
		}
		if (direction == Direction.RIGHT)
		{
			num *= -1f;
		}
		Vector3 src = base.transform.position;
		Vector3 dst = src + new Vector3(num, 0f, 0f);
		float elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime;
			base.transform.position = Vector3.Lerp(src, dst, elapsed);
			yield return YieldCache.waitFrame;
		}
		base.transform.position = dst;
		isActionEnd = true;
	}
}
