using System.Collections.Generic;
using UI;
using UnityEngine;

public class ApocalypseBirdObjectController : MonoBehaviour
{
	[SerializeField]
	private UIAnimationEventHandler _animEventHandler;

	private FarAreaEffect_EGO_ApcBird_PutDownAtk _areaAtkScript;

	[SerializeField]
	private List<Transform> _areaLaserPivotList;

	public List<Transform> areaLaserPivotList => new List<Transform>(_areaLaserPivotList);

	public void PlayHandAtk(Direction handDirection, FarAreaEffect_EGO_ApcBird_PutDownAtk areaAtkScript)
	{
		if (handDirection == Direction.LEFT)
		{
			_animEventHandler.Anim.SetTrigger("LeftAtk");
		}
		else
		{
			_animEventHandler.Anim.SetTrigger("RightAtk");
		}
		_areaAtkScript = areaAtkScript;
	}

	public void Disappear()
	{
		Object.Destroy(base.gameObject);
	}

	private void Awake()
	{
		_animEventHandler.AddEvent("StartAtk", OnAnimEvent_StartAtk);
		_animEventHandler.AddEvent("Damage", OnAnimEvent_Damage);
		_animEventHandler.AddEvent("EndAtk", OnAnimEvent_EndAtk);
		_animEventHandler.Anim.SetTrigger("Default");
	}

	private void OnAnimEvent_StartAtk()
	{
		if (_areaAtkScript != null)
		{
			_areaAtkScript.OnEffectStart();
		}
	}

	private void OnAnimEvent_Damage()
	{
		if (_areaAtkScript != null)
		{
			_areaAtkScript.OnGiveDamage();
		}
	}

	private void OnAnimEvent_EndAtk()
	{
		if (_areaAtkScript != null)
		{
			_areaAtkScript.OnEffectEnd();
			_areaAtkScript = null;
		}
	}
}
