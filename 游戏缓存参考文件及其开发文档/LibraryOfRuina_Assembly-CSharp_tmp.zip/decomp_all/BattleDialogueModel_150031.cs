using LOR_XML;

public class BattleDialogueModel_150031 : BattleDialogueModel
{
	public BattleDialogueModel_150031(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep2", "R_Corp_Nicolai_Meet_Gebura_2_1");
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}
}
