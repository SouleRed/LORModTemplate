using System.Collections.Generic;
using LOR_XML;

public class AbnormalityCardDescXmlList : Singleton<AbnormalityCardDescXmlList>
{
	private Dictionary<string, AbnormalityCard> _dictionary;

	public void Init(Dictionary<string, AbnormalityCard> dictionary)
	{
		_dictionary = dictionary;
	}

	public AbnormalityCard GetAbnormalityCard(string cardID)
	{
		AbnormalityCard abnormalityCard = null;
		if (_dictionary.ContainsKey(cardID))
		{
			return _dictionary[cardID];
		}
		return new AbnormalityCard
		{
			id = cardID,
			abnormalityName = "Not found",
			cardName = "Not found",
			abilityDesc = "Not found",
			flavorText = "Not found",
			dialogues = null
		};
	}

	public List<AbnormalityCardDialog> GetAbnormalityDialogue(string cardID)
	{
		List<AbnormalityCardDialog> list = null;
		if (_dictionary.ContainsKey(cardID))
		{
			list = _dictionary[cardID].dialogues;
		}
		else
		{
			list = new List<AbnormalityCardDialog>();
			list.Add(new AbnormalityCardDialog
			{
				id = cardID,
				dialog = "Not found"
			});
		}
		return list;
	}
}
