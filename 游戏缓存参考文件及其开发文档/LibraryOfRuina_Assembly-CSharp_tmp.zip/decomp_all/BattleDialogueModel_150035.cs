using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_150035 : BattleDialogueModel
{
	private bool _bKilledBinah;

	private bool _bKilledGebura;

	private bool _bKilledRoland;

	public BattleDialogueModel_150035(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bKilledBinah = false;
		_bKilledGebura = false;
		_bKilledRoland = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		switch (dlgType)
		{
		case DialogType.START_BATTLE:
			ResetDialogData(dlgType);
			break;
		case DialogType.KILLS_OPPONENT:
			if (_xmlInfo.characterID == "PupleTear_MeetGebura" && !_bKilledGebura)
			{
				BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 6);
				if (battleUnitModel != null && battleUnitModel.IsDead())
				{
					_bKilledGebura = true;
					return GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
				}
			}
			else if (_xmlInfo.characterID == "PupleTear_MeetRoland" && !_bKilledRoland)
			{
				BattleUnitModel battleUnitModel2 = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 10);
				if (battleUnitModel2 != null && battleUnitModel2.IsDead())
				{
					_bKilledRoland = true;
					return GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
				}
			}
			else if (_xmlInfo.characterID == "PupleTear_MeetBinah" && !_bKilledBinah)
			{
				BattleUnitModel battleUnitModel3 = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 8);
				if (battleUnitModel3 != null && battleUnitModel3.IsDead())
				{
					_bKilledRoland = true;
					return GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
				}
			}
			break;
		}
		return base.GetBattleDlg(dlgType);
	}

	private void ResetDialogData(DialogType dlgType)
	{
		switch (Singleton<StageController>.Instance.CurrentFloor)
		{
		case SephirahType.Gebura:
			if (_xmlInfo.characterID != "PurpleTear_MeetGebura")
			{
				BattleDialogCharacter battleDlg2 = ChangeDlgWithDefaultKillsOpponent("PupleTear", "PupleTear_MeetGebura");
				Init(battleDlg2);
			}
			break;
		case SephirahType.Keter:
			if (_xmlInfo.characterID != "PupleTear_MeetRoland")
			{
				BattleDialogCharacter battleDlg3 = ChangeDlgWithDefaultKillsOpponent("PupleTear", "PupleTear_MeetRoland");
				Init(battleDlg3);
			}
			break;
		case SephirahType.Binah:
			if (_xmlInfo.characterID != "PupleTear_MeetBinah")
			{
				BattleDialogCharacter battleDlg = ChangeDlgWithDefaultKillsOpponent("PupleTear", "PupleTear_MeetBinah");
				Init(battleDlg);
			}
			break;
		}
	}

	private BattleDialogCharacter ChangeDlgWithDefaultKillsOpponent(string groupId, string characterId)
	{
		BattleDialogType battleDialogType = _xmlInfo.dialogTypeList.Find((BattleDialogType x) => x.dialogType == DialogType.KILLS_OPPONENT);
		BattleDialogType battleDialogType2 = new BattleDialogType
		{
			dialogType = DialogType.KILLS_OPPONENT,
			dialogList = new List<BattleDialog>()
		};
		foreach (BattleDialog dialog in battleDialogType.dialogList)
		{
			battleDialogType2.dialogList.Add(dialog);
		}
		BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData(groupId, characterId);
		BattleDialogType battleDialogType3 = characterData.dialogTypeList.Find((BattleDialogType x) => x.dialogType == DialogType.KILLS_OPPONENT);
		if (battleDialogType3 != null)
		{
			battleDialogType3.dialogList.Clear();
			foreach (BattleDialog dialog2 in battleDialogType2.dialogList)
			{
				battleDialogType3.dialogList.Add(dialog2);
			}
		}
		else
		{
			characterData.dialogTypeList.Add(battleDialogType2);
		}
		return characterData;
	}
}
