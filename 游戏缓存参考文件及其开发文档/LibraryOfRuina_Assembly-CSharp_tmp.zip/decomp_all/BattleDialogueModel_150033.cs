using LOR_XML;

public class BattleDialogueModel_150033 : BattleDialogueModel
{
	public BattleDialogueModel_150033(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep2", "R_Corp_Maxim_2_2_Meet_Gebura");
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}
}
