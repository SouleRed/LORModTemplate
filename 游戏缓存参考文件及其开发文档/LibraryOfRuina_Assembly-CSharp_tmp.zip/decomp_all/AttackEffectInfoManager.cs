using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using UnityEngine;

public class AttackEffectInfoManager : Singleton<AttackEffectInfoManager>
{
	public const string atkEffectResourcesPath = "Prefabs/Battle/DiceAttackEffects/New/";

	private Dictionary<string, string> _attackEffectPathTable = new Dictionary<string, string>();

	public void Init(List<AttackEffectPathXmlInfo> charResourceInfo)
	{
		_attackEffectPathTable = new Dictionary<string, string>();
		foreach (AttackEffectPathXmlInfo item in charResourceInfo)
		{
			_attackEffectPathTable.Add(item.name, item.filepath);
		}
	}

	public void Init(Dictionary<string, string> charResourceInfo)
	{
		_attackEffectPathTable = new Dictionary<string, string>();
		foreach (KeyValuePair<string, string> item in charResourceInfo)
		{
			_attackEffectPathTable.Add(item.Key, item.Value);
		}
	}

	public void Load()
	{
		LoadResourceInfo();
	}

	private void LoadResourceInfo()
	{
		List<AttackEffectPathXmlInfo> list = new List<AttackEffectPathXmlInfo>();
		list.AddRange(LoadNewResourceInfo("Xml/AttackEffectPathInfo").list);
		Init(list);
	}

	private AttackEffectPathInfoRoot LoadNewResourceInfo(string path)
	{
		using StringReader textReader = new StringReader(Resources.Load<TextAsset>(path).text);
		return (AttackEffectPathInfoRoot)new XmlSerializer(typeof(AttackEffectPathInfoRoot)).Deserialize(textReader);
	}

	public string GetPath(string name)
	{
		if (_attackEffectPathTable.TryGetValue(name, out var value))
		{
			return "Prefabs/Battle/DiceAttackEffects/New/" + value;
		}
		return name;
	}
}
