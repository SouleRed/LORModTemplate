using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_100008 : BattleDialogueModel
{
	public BattleDialogueModel_100008(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType, List<BattleUnitModel> targets)
	{
		string empty = string.Empty;
		if (dlgType == DialogType.COLLEAGUE_DEATH)
		{
			BattleUnitModel battleUnitModel = targets.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 100007);
			BattleUnitModel battleUnitModel2 = targets.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 100009);
			string[] list = new string[2] { "SPECIAL_EVENT_0", "SPECIAL_EVENT_1" };
			if (battleUnitModel != null && battleUnitModel2 == null)
			{
				return GetBattleDlgSpecialEvent("SPECIAL_EVENT_1");
			}
			return GetBattleDlgSpecialEvent(RandomUtil.SelectOne(list));
		}
		return base.GetBattleDlg(dlgType);
	}
}
