public class BattleDialogWithCreatureBattle : Singleton<BattleDialogWithCreatureBattle>
{
	public class ReserveInfo
	{
		public string str;

		public BattleUnitModel talker;

		public ReserveInfo(string s)
		{
			str = s;
			talker = null;
		}
	}

	private ReserveInfo[] info;

	public void Init()
	{
		if (info != null)
		{
			info = null;
		}
		info = new ReserveInfo[5];
		info[0] = new ReserveInfo("librarian_");
		info[1] = new ReserveInfo("librarian1_");
		info[2] = new ReserveInfo("librarian2_");
		info[3] = new ReserveInfo("librarian3_");
		info[4] = new ReserveInfo("librarian4_");
	}

	public string ReserveID(BattleUnitModel model)
	{
		if (info[1].talker == null || info[1].talker == model)
		{
			info[1].talker = model;
			return info[1].str;
		}
		if (info[2].talker == null || info[2].talker == model)
		{
			info[2].talker = model;
			return info[2].str;
		}
		if (info[3].talker == null || info[3].talker == model)
		{
			info[3].talker = model;
			return info[3].str;
		}
		if (info[4].talker == null || info[4].talker == model)
		{
			info[4].talker = model;
			return info[4].str;
		}
		return info[1].str;
	}
}
