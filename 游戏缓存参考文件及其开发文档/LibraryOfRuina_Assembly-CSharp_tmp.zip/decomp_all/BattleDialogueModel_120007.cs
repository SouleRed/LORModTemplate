using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_120007 : BattleDialogueModel
{
	public BattleDialogueModel_120007(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType, List<BattleUnitModel> targets)
	{
		string result = base.GetBattleDlg(dlgType, targets);
		switch (dlgType)
		{
		case DialogType.COLLEAGUE_DEATH:
		{
			bool num2 = targets.Exists((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120005);
			bool flag2 = targets.Exists((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120006);
			if (num2)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_2");
			}
			else if (flag2)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_1");
			}
			break;
		}
		case DialogType.DEATH:
		{
			List<BattleUnitModel> aliveList = BattleObjectManager.instance.GetAliveList(Faction.Enemy);
			BattleUnitModel battleUnitModel = aliveList.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120005);
			BattleUnitModel battleUnitModel2 = aliveList.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 120006);
			bool num = battleUnitModel == null;
			bool flag = battleUnitModel2 == null;
			if (num && flag)
			{
				result = GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
			break;
		}
		}
		return result;
	}
}
