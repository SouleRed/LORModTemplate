using LOR_XML;

public class BattleDialogueModel_150036 : BattleDialogueModel
{
	public BattleDialogueModel_150036(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.COLLEAGUE_DEATH)
		{
			result = base.GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
		}
		return result;
	}
}
