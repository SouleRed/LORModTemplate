using System.Collections;
using TMPro;
using UnityEngine;

public class ActionText : MonoBehaviour
{
	public float typoFadeoutSpeed;

	public float typoRotationAngle;

	private TextMeshProUGUI _tm;

	private Material _mat;

	private BattleUnitView _view;

	[SerializeField]
	private AnimationCurve _alphaCurve;

	[SerializeField]
	[Range(1f, 5f)]
	private float _typoFadeoutSpeedRange;

	[SerializeField]
	private float _typoRotationAngleRange;

	public void Init(string text, BattleUnitView view, ActionTextMode mode = ActionTextMode.None)
	{
		switch (mode)
		{
		case ActionTextMode.None:
		{
			_tm.text = text;
			_view = view;
			TextMeshProUGUI[] componentsInChildren = _view.atkTextRoot.GetComponentsInChildren<TextMeshProUGUI>();
			foreach (TextMeshProUGUI textMeshProUGUI in componentsInChildren)
			{
				if (!textMeshProUGUI.Equals(_tm))
				{
					textMeshProUGUI.transform.Translate(0f, 1f, 0f, Space.Self);
				}
			}
			StartCoroutine(FadeOut());
			break;
		}
		case ActionTextMode.Rencounter:
			_tm.text = text;
			_view = view;
			typoFadeoutSpeed = Random.Range(1f, _typoFadeoutSpeedRange);
			typoRotationAngle = Random.Range(0f, _typoRotationAngleRange);
			if (view.model.direction == Direction.LEFT)
			{
				base.transform.localPosition = new Vector3(Random.Range(215f, 280f), Random.Range(-220f, -400f), 0f);
			}
			else
			{
				base.transform.localPosition = new Vector3(Random.Range(215f, 280f) * -1f, Random.Range(-220f, -400f), 0f);
			}
			base.transform.localRotation = Quaternion.Euler(0f, 0f, typoRotationAngle);
			_tm.alignment = ((base.transform.localPosition.x > 0f) ? TextAlignmentOptions.Left : TextAlignmentOptions.Right);
			StartCoroutine(Appear());
			break;
		}
	}

	private void Awake()
	{
		_tm = GetComponent<TextMeshProUGUI>();
	}

	private IEnumerator Appear()
	{
		float elapsed = 0f;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * 8f;
			base.transform.localScale = Vector3.one * (2f - elapsed);
			yield return YieldCache.waitFrame;
		}
		StartCoroutine(FadeOut(moveY: false, typoFadeoutSpeed));
	}

	private IEnumerator FadeOut(bool moveY = true, float fadeSpeed = 1f)
	{
		float elapsed = 0f;
		Color c = _tm.color;
		while (elapsed < 1f)
		{
			elapsed += Time.deltaTime * fadeSpeed;
			if (moveY)
			{
				base.transform.localPosition += new Vector3(0f, elapsed * 2f, 0f);
			}
			float a = _alphaCurve.Evaluate(elapsed);
			c.a = a;
			_tm.color = c;
			yield return YieldCache.waitFrame;
		}
		Object.Destroy(base.gameObject);
	}
}
