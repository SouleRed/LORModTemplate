using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_150023 : BattleDialogueModel
{
	private bool _bMeetGebura;

	private bool _bKillGebura;

	public BattleDialogueModel_150023(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bMeetGebura = false;
		_bKillGebura = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura && !_bMeetGebura)
		{
			List<BattleDialogType> list = _xmlInfo.dialogTypeList.FindAll((BattleDialogType x) => x.dialogType != DialogType.START_BATTLE);
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep1", "R_Corp_Nicolai_Meet_Gebura_1");
			foreach (BattleDialogType dlgInfo in list)
			{
				BattleDialogType battleDialogType = new BattleDialogType();
				battleDialogType.dialogType = dlgInfo.dialogType;
				battleDialogType.dialogList = new List<BattleDialog>();
				foreach (BattleDialog dialog in dlgInfo.dialogList)
				{
					battleDialogType.dialogList.Add(dialog);
				}
				BattleDialogType battleDialogType2 = characterData.dialogTypeList.Find((BattleDialogType x) => x.dialogType == dlgInfo.dialogType);
				if (battleDialogType2 != null)
				{
					battleDialogType2.dialogList.Clear();
					foreach (BattleDialog dialog2 in battleDialogType.dialogList)
					{
						battleDialogType2.dialogList.Add(dialog2);
					}
				}
				else
				{
					characterData.dialogTypeList.Add(battleDialogType);
				}
			}
			Init(characterData);
			_bMeetGebura = true;
		}
		if (dlgType == DialogType.KILLS_OPPONENT && _bMeetGebura && Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura && !_bKillGebura)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 6);
			if (battleUnitModel != null && battleUnitModel.IsDead())
			{
				_bKillGebura = true;
				return GetBattleDlgSpecialEvent("SPECIAL_EVENT_" + Random.Range(0, 2));
			}
		}
		return base.GetBattleDlg(dlgType);
	}
}
