using UnityEngine;

public class BattleEffectSound : MonoBehaviour
{
	private AudioSource _audioSrc;

	private float length;

	private float elapsed;

	public void Init(AudioClip ac, float volume = 1f, bool loop = false)
	{
		if (Singleton<StageController>.Instance.argaliaFinalMapChanged)
		{
			volume *= 0.5f;
		}
		_audioSrc.clip = ac;
		_audioSrc.volume = volume;
		_audioSrc.Play();
		_audioSrc.loop = loop;
		length = ac.length;
	}

	public bool IsPlaying()
	{
		if (_audioSrc == null)
		{
			return false;
		}
		return _audioSrc.isPlaying;
	}

	public void ChangeVolume(float volume)
	{
		_audioSrc.volume = volume;
	}

	public void Release()
	{
		Object.Destroy(base.gameObject);
	}

	private void Awake()
	{
		_audioSrc = GetComponent<AudioSource>();
	}

	private void Start()
	{
	}

	private void Update()
	{
		elapsed += Time.deltaTime;
		if (elapsed > length + 1f && !_audioSrc.loop)
		{
			Object.Destroy(base.gameObject);
		}
	}
}
