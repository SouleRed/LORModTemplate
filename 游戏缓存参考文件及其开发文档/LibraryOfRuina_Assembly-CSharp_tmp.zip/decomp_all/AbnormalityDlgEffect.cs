using System.Collections;
using TMPro;
using UnityEngine;

public class AbnormalityDlgEffect : MonoBehaviour
{
	private struct VertexAnim
	{
		public float angleRange;

		public float angle;

		public float speed;
	}

	public float AngleMultiplier = 1f;

	public float SpeedMultiplier = 1f;

	public float CurveScale = 1f;

	private TMP_Text m_TextComponent;

	private bool hasTextChanged;

	private void OnDisable()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Remove(ON_TEXT_CHANGED);
	}

	public void Init()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Add(ON_TEXT_CHANGED);
		m_TextComponent = GetComponent<TMP_Text>();
		StopAllCoroutines();
		StartCoroutine(AnimateVertex());
	}

	private void Start()
	{
	}

	private void ON_TEXT_CHANGED(Object obj)
	{
		if (obj == m_TextComponent)
		{
			hasTextChanged = true;
		}
	}

	private IEnumerator AnimateVertex()
	{
		m_TextComponent.ForceMeshUpdate();
		TMP_TextInfo textInfo = m_TextComponent.textInfo;
		int loopCount = 0;
		hasTextChanged = true;
		VertexAnim[] vertexAnim = new VertexAnim[1024];
		for (int i = 0; i < 1024; i++)
		{
			vertexAnim[i].angleRange = Random.Range(10f, 25f);
			vertexAnim[i].speed = Random.Range(1f, 3f);
		}
		TMP_MeshInfo[] cachedMeshInfo = textInfo.CopyMeshInfoVertexData();
		while (true)
		{
			if (hasTextChanged)
			{
				cachedMeshInfo = textInfo.CopyMeshInfoVertexData();
				hasTextChanged = false;
			}
			int characterCount = textInfo.characterCount;
			if (characterCount == 0)
			{
				yield return new WaitForSeconds(0.25f);
				continue;
			}
			for (int j = 0; j < characterCount; j++)
			{
				if (textInfo.characterInfo[j].isVisible)
				{
					VertexAnim vertexAnim2 = vertexAnim[j];
					int materialReferenceIndex = textInfo.characterInfo[j].materialReferenceIndex;
					int vertexIndex = textInfo.characterInfo[j].vertexIndex;
					Vector3[] vertices = cachedMeshInfo[materialReferenceIndex].vertices;
					Vector3 vector = (Vector2)((vertices[vertexIndex] + vertices[vertexIndex + 2]) / 2f);
					Vector3[] vertices2 = textInfo.meshInfo[materialReferenceIndex].vertices;
					vertices2[vertexIndex] = vertices[vertexIndex] - vector;
					vertices2[vertexIndex + 1] = vertices[vertexIndex + 1] - vector;
					vertices2[vertexIndex + 2] = vertices[vertexIndex + 2] - vector;
					vertices2[vertexIndex + 3] = vertices[vertexIndex + 3] - vector;
					vertexAnim2.angle = Mathf.SmoothStep(0f - vertexAnim2.angleRange, vertexAnim2.angleRange, Mathf.PingPong((float)loopCount / 25f * vertexAnim2.speed, 1f));
					Matrix4x4 matrix4x = Matrix4x4.TRS(new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), 0f) * CurveScale, Quaternion.Euler(0f, 0f, Random.Range(-5f, 5f) * AngleMultiplier), Vector3.one);
					vertices2[vertexIndex] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex]);
					vertices2[vertexIndex + 1] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex + 1]);
					vertices2[vertexIndex + 2] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex + 2]);
					vertices2[vertexIndex + 3] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex + 3]);
					vertices2[vertexIndex] += vector;
					vertices2[vertexIndex + 1] += vector;
					vertices2[vertexIndex + 2] += vector;
					vertices2[vertexIndex + 3] += vector;
					vertexAnim[j] = vertexAnim2;
				}
			}
			for (int k = 0; k < textInfo.meshInfo.Length; k++)
			{
				textInfo.meshInfo[k].mesh.vertices = textInfo.meshInfo[k].vertices;
				m_TextComponent.UpdateGeometry(textInfo.meshInfo[k].mesh, k);
			}
			loopCount++;
			yield return new WaitForSeconds(0.1f);
		}
	}

	private void SetEffect()
	{
		m_TextComponent.ForceMeshUpdate();
		TMP_TextInfo textInfo = m_TextComponent.textInfo;
		int num = 0;
		hasTextChanged = true;
		VertexAnim[] array = new VertexAnim[1024];
		for (int i = 0; i < 1024; i++)
		{
			array[i].angleRange = Random.Range(10f, 25f);
			array[i].speed = Random.Range(1f, 3f);
		}
		TMP_MeshInfo[] array2 = textInfo.CopyMeshInfoVertexData();
		if (hasTextChanged)
		{
			array2 = textInfo.CopyMeshInfoVertexData();
			hasTextChanged = false;
		}
		int characterCount = textInfo.characterCount;
		if (characterCount == 0)
		{
			return;
		}
		for (int j = 0; j < characterCount; j++)
		{
			if (textInfo.characterInfo[j].isVisible)
			{
				VertexAnim vertexAnim = array[j];
				int materialReferenceIndex = textInfo.characterInfo[j].materialReferenceIndex;
				int vertexIndex = textInfo.characterInfo[j].vertexIndex;
				Vector3[] vertices = array2[materialReferenceIndex].vertices;
				Vector3 vector = (Vector2)((vertices[vertexIndex] + vertices[vertexIndex + 2]) / 2f);
				Vector3[] vertices2 = textInfo.meshInfo[materialReferenceIndex].vertices;
				vertices2[vertexIndex] = vertices[vertexIndex] - vector;
				vertices2[vertexIndex + 1] = vertices[vertexIndex + 1] - vector;
				vertices2[vertexIndex + 2] = vertices[vertexIndex + 2] - vector;
				vertices2[vertexIndex + 3] = vertices[vertexIndex + 3] - vector;
				vertexAnim.angle = Mathf.SmoothStep(0f - vertexAnim.angleRange, vertexAnim.angleRange, Mathf.PingPong((float)num / 25f * vertexAnim.speed, 1f));
				Matrix4x4 matrix4x = Matrix4x4.TRS(new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), 0f) * CurveScale, Quaternion.Euler(0f, 0f, Random.Range(-5f, 5f) * AngleMultiplier), Vector3.one * Random.Range(1f, 1.5f));
				vertices2[vertexIndex] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex]);
				vertices2[vertexIndex + 1] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex + 1]);
				vertices2[vertexIndex + 2] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex + 2]);
				vertices2[vertexIndex + 3] = matrix4x.MultiplyPoint3x4(vertices2[vertexIndex + 3]);
				vertices2[vertexIndex] += vector;
				vertices2[vertexIndex + 1] += vector;
				vertices2[vertexIndex + 2] += vector;
				vertices2[vertexIndex + 3] += vector;
				array[j] = vertexAnim;
			}
		}
		for (int k = 0; k < textInfo.meshInfo.Length; k++)
		{
			textInfo.meshInfo[k].mesh.vertices = textInfo.meshInfo[k].vertices;
			m_TextComponent.UpdateGeometry(textInfo.meshInfo[k].mesh, k);
		}
		num++;
	}
}
