using System;
using System.Collections.Generic;
using LOR_DiceSystem;
using LOR_XML;
using Mod;
using UnityEngine;

public class BattleCardAbilityDescXmlList : Singleton<BattleCardAbilityDescXmlList>
{
	private Dictionary<string, BattleCardAbilityDesc> _dictionary;

	private Dictionary<string, List<string>> _dictionaryKeywordCache = new Dictionary<string, List<string>>();

	public void Init(Dictionary<string, BattleCardAbilityDesc> dictionary)
	{
		_dictionary = dictionary;
		_dictionaryKeywordCache.Clear();
	}

	public void AddByMode(string packageId, Dictionary<string, BattleCardAbilityDesc> dict)
	{
		foreach (KeyValuePair<string, BattleCardAbilityDesc> item in dict)
		{
			if (_dictionary.ContainsKey(item.Key))
			{
				Singleton<ModContentManager>.Instance.AddErrorLog("ability ID already exists : " + item.Key);
			}
			else
			{
				_dictionary.Add(item.Key, item.Value);
			}
		}
	}

	public List<string> GetAbilityDesc(DiceCardXmlInfo card)
	{
		string defaultAbilityDescString = GetDefaultAbilityDescString(card);
		List<string> abilityDesc = GetAbilityDesc(card.Script);
		if (!string.IsNullOrEmpty(defaultAbilityDescString))
		{
			abilityDesc.Insert(0, defaultAbilityDescString);
		}
		return abilityDesc;
	}

	public string GetAbilityDescString(DiceCardXmlInfo card)
	{
		List<string> abilityDesc = GetAbilityDesc(card);
		if (abilityDesc.Count > 0)
		{
			return string.Join("\n", abilityDesc);
		}
		return string.Empty;
	}

	public string GetDefaultAbilityDescString(DiceCardXmlInfo card)
	{
		List<string> list = new List<string>();
		card.IsOnlyPage();
		if (card.Spec.Ranged == CardRange.FarArea)
		{
			list.AddRange(GetAbilityDesc("areaText_summation"));
		}
		else if (card.Spec.Ranged == CardRange.FarAreaEach)
		{
			list.AddRange(GetAbilityDesc("areaText_single"));
		}
		if (card.IsExhaustOnUse())
		{
			list.AddRange(GetAbilityDesc("exhaustOnUseText"));
		}
		if (list.Count > 0)
		{
			return string.Join(string.Join("", GetAbilityDesc("separator")), list);
		}
		return string.Empty;
	}

	public string GetAbilityDesc(DiceBehaviour behaviour)
	{
		List<string> abilityDesc = GetAbilityDesc(behaviour.Script);
		if (abilityDesc.Count > 0)
		{
			return abilityDesc[0];
		}
		return "";
	}

	public List<string> GetAbilityDesc(string id)
	{
		List<string> collection = new List<string>();
		if (_dictionary.ContainsKey(id))
		{
			collection = _dictionary[id].desc;
		}
		return new List<string>(collection);
	}

	public BattleCardAbilityDesc GetData(string id)
	{
		if (_dictionary.TryGetValue(id, out var value))
		{
			return value;
		}
		return null;
	}

	public List<string> GetAbilityKeywords(DiceCardXmlInfo card)
	{
		List<string> list = new List<string>();
		if (card.Spec.Ranged == CardRange.FarArea)
		{
			list.Add("AreaCard_Keyword");
			list.Add("AreaDiceAll_Keyword");
		}
		else if (card.Spec.Ranged == CardRange.FarAreaEach)
		{
			list.Add("AreaCard_Keyword");
			list.Add("AreaDiceEach_Keyword");
		}
		else if (card.Spec.Ranged == CardRange.Instance)
		{
			list.Add("Instant_Keyword");
		}
		if (card.IsExhaustOnUse())
		{
			list.Add("ExhaustOnUse_Keyword");
		}
		string script = card.Script;
		if (script != "")
		{
			list.AddRange(GetAbilityKeywords_byScript(script));
		}
		return list;
	}

	public List<string> GetAbilityKeywords_byScript(string scriptName)
	{
		if (_dictionaryKeywordCache.TryGetValue(scriptName, out var value))
		{
			return value;
		}
		value = new List<string>();
		if (!string.IsNullOrEmpty(scriptName))
		{
			DiceCardAbilityBase diceCardAbilityBase = Singleton<AssemblyManager>.Instance.CreateInstance_DiceCardAbility(scriptName);
			if (diceCardAbilityBase == null)
			{
				Type type = Type.GetType("DiceCardSelfAbility_" + scriptName.Trim());
				if (!(type != null))
				{
					Debug.LogError("card or dice ability not found : " + scriptName);
					_dictionaryKeywordCache.Add(scriptName, value);
					return value;
				}
				if (Activator.CreateInstance(type) is DiceCardSelfAbilityBase diceCardSelfAbilityBase)
				{
					value.AddRange(diceCardSelfAbilityBase.Keywords);
				}
			}
			else
			{
				value.AddRange(diceCardAbilityBase.Keywords);
			}
		}
		_dictionaryKeywordCache.Add(scriptName, value);
		return value;
	}
}
