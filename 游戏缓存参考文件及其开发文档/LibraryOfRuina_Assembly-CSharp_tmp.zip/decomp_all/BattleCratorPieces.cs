using System.Collections;
using UnityEngine;

public class BattleCratorPieces : MonoBehaviour
{
	[SerializeField]
	private AnimationCurve speedMaxCurve;

	[SerializeField]
	private AnimationCurve speedMinCurve;

	[SerializeField]
	private SpriteRenderer sprRenderer;

	private Vector3 _moveDirection;

	public void Init(Vector3 pos, Vector3 dir, Sprite sp)
	{
		_moveDirection = dir.normalized;
		sprRenderer.sprite = sp;
		base.transform.position = pos;
		base.gameObject.SetActive(value: true);
	}

	private void Start()
	{
		StartCoroutine(Move());
	}

	private IEnumerator Move()
	{
		float elapsed = 0f;
		float duration = 2f;
		float speed = Random.Range(1.5f, 5f);
		int sign = ((Random.Range(0f, 1f) > 0.5f) ? 1 : (-1));
		while (elapsed < duration)
		{
			elapsed += Time.deltaTime;
			float time = elapsed / duration;
			float num = speedMaxCurve.Evaluate(time);
			speed *= num;
			base.transform.Translate(_moveDirection * speed * Time.deltaTime);
			if (speed >= 0.1f)
			{
				base.transform.Rotate(0f, 0f, Random.Range(30f, 70f) * (float)sign * Time.deltaTime);
			}
			yield return new WaitForEndOfFrame();
		}
	}
}
