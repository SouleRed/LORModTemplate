using LOR_XML;

public class BattleDialogueModel_150032 : BattleDialogueModel
{
	private bool _bKillGebura;

	public BattleDialogueModel_150032(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bKillGebura = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep2", "R_Corp_Myo_Meet_Gebura_2_2");
			Init(characterData);
		}
		if (dlgType == DialogType.KILLS_OPPONENT && Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura && !_bKillGebura)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Player).Find((BattleUnitModel x) => x.UnitData.unitData.defaultBook.GetBookClassInfoId() == 6);
			if (battleUnitModel != null && battleUnitModel.IsDead())
			{
				_bKillGebura = true;
				return GetBattleDlgSpecialEvent("SPECIAL_EVENT_0");
			}
		}
		return base.GetBattleDlg(dlgType);
	}
}
