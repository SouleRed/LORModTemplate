using System.Collections.Generic;
using UnityEngine;

public class BattleCoin
{
	public RWBPType rwbp;

	public RWBPType rwbpDefault;

	public int level = 1;

	public List<BattleSlot> bufSlotList;

	public float damageBonus;

	public float messinessDamageBonus;

	public float predelayBonus;

	public float postdelayBonus;

	public RWBPType cardRwbp;

	public bool enhanced;

	public BattleCoin(RWBPType rwbp, RWBPType cardRwbpType, int lv = 1)
	{
		this.rwbp = rwbp;
		enhanced = false;
		bufSlotList = new List<BattleSlot>();
		rwbpDefault = rwbp;
		level = lv;
		cardRwbp = cardRwbpType;
	}

	public void SetPcoinAbility(RWBPType targetCoinType)
	{
		if (rwbp == RWBPType.P)
		{
			RWBPType rWBPType = rwbp;
			switch (targetCoinType)
			{
			case RWBPType.R:
				rWBPType = RWBPType.W;
				break;
			case RWBPType.W:
				rWBPType = RWBPType.B;
				break;
			case RWBPType.B:
				rWBPType = RWBPType.R;
				break;
			default:
			{
				int num = Random.Range(0, 3);
				rWBPType = (new RWBPType[3]
				{
					RWBPType.R,
					RWBPType.W,
					RWBPType.B
				})[num];
				break;
			}
			}
			rwbp = rWBPType;
		}
	}

	public void IncreaseLevel(int add)
	{
		level += add;
	}

	public void DecreaseLevel(int sub)
	{
		level -= sub;
	}

	public void IncreaseDamageBonus(float v)
	{
		damageBonus += v;
	}

	public void IncreaseMessinessDamageBonus(float v)
	{
		messinessDamageBonus += v;
	}

	public bool AddSlotBuf(BattleSlot slot)
	{
		if (bufSlotList.Exists((BattleSlot x) => x == slot))
		{
			return false;
		}
		bufSlotList.Add(slot);
		_ = slot.CurSlotCard;
		IncreaseLevel(1);
		return rwbp switch
		{
			_ => true, 
		};
	}

	public void Enhance()
	{
		if (!enhanced)
		{
			enhanced = true;
		}
	}

	public void Change(RWBPType rwbp)
	{
		this.rwbp = rwbp;
	}
}
