using System.Collections.Generic;
using LOR_XML;

public class BattleDialogueModel_130027 : BattleDialogueModel
{
	public BattleDialogueModel_130027(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		string result = base.GetBattleDlg(dlgType);
		if (dlgType == DialogType.DEATH)
		{
			List<BattleUnitModel> aliveList = BattleObjectManager.instance.GetAliveList(Faction.Enemy);
			BattleUnitModel battleUnitModel = aliveList.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130024);
			BattleUnitModel battleUnitModel2 = aliveList.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130025);
			BattleUnitModel battleUnitModel3 = aliveList.Find((BattleUnitModel x) => x.UnitData.unitData.bookItem.GetBookClassInfoId() == 130026);
			if (battleUnitModel != null && battleUnitModel2 != null && battleUnitModel3 != null)
			{
				result = ((!battleUnitModel.IsDead() || !battleUnitModel2.IsDead() || !battleUnitModel3.IsDead()) ? GetBattleDlgSpecialEvent("SPECIAL_EVENT_0") : GetBattleDlgSpecialEvent("SPECIAL_EVENT_1"));
			}
		}
		return result;
	}
}
