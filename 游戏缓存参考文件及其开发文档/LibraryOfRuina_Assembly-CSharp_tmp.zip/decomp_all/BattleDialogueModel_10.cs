using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_10 : BattleDialogueModel
{
	private bool _bMeetArgalia;

	private bool _bKillArgalia;

	private bool _bKilledPurpleTear;

	private SpecialBattleDialog _specialDialogs;

	public BattleDialogueModel_10(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bMeetArgalia = false;
		_bKillArgalia = false;
		_bKilledPurpleTear = false;
		_specialDialogs = new SpecialBattleDialog();
		_specialDialogs.SetBattleDialog("LibraryOfRuina", "Roland");
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		LorId id = Singleton<StageController>.Instance.GetStageModel().ClassInfo.id;
		if (id == 50006)
		{
			return GetBattleDlg_BlueReverberation(dlgType);
		}
		if (id == 50009)
		{
			return GetBattleDlg_RedMist(dlgType);
		}
		if (id == 50012)
		{
			return GetPurpleTearBattleDlg(dlgType);
		}
		if (id == 60002)
		{
			return GetOlivierBattleDlg(dlgType);
		}
		if (id == 70010)
		{
			return GetBlueReverberation2ndBattleDlg(dlgType);
		}
		if (id == 60007)
		{
			return "";
		}
		return GetNormalBattleDlg(dlgType);
	}

	private string GetBattleDlg_BlueReverberation(DialogType dlgType)
	{
		string text = string.Empty;
		if (Singleton<StageController>.Instance.CurrentWave == 2)
		{
			string text2 = "BlueReverberation1";
			string character = "Roland_MeetArgalia";
			if (!_specialDialogs.AccordWith(text2, character))
			{
				_specialDialogs.SetBattleDialog(text2, character);
			}
			Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
			if (dialogDictionary != null)
			{
				BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50013);
				if (dlgType == DialogType.START_BATTLE && battleUnitModel != null && !battleUnitModel.IsDead())
				{
					_bMeetArgalia = true;
				}
				if (_bMeetArgalia)
				{
					if (!_bKillArgalia && dlgType == DialogType.KILLS_OPPONENT && battleUnitModel != null && battleUnitModel.IsDead())
					{
						_bKillArgalia = true;
						if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
						{
							BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
							if (battleDialog != null)
							{
								text = battleDialog.dialogContent;
							}
						}
					}
					else if (dialogDictionary.ContainsKey(dlgType))
					{
						List<BattleDialog> list = dialogDictionary[dlgType];
						if (list.Count > 0)
						{
							text = list[Random.Range(0, list.Count)].dialogContent;
						}
					}
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetBattleDlg_RedMist(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "RedMist";
		string character = "Roland_MeetRedMist";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = dialogDictionary[dlgType];
			if (list.Count > 0)
			{
				text = list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetNormalBattleDlg(DialogType dlgType)
	{
		if (_xmlInfo.characterID != "Roland")
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("LibraryOfRuina", "Roland");
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}

	private string GetPurpleTearBattleDlg(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "PupleTear";
		string character = "Roland_MeetPupleTear";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50035);
			if (!_bKilledPurpleTear && battleUnitModel != null && battleUnitModel.IsDead())
			{
				_bKilledPurpleTear = true;
				if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
				{
					BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
					if (battleDialog != null)
					{
						text = battleDialog.dialogContent;
					}
				}
			}
			else if (dialogDictionary.ContainsKey(dlgType))
			{
				List<BattleDialog> list = dialogDictionary[dlgType];
				if (list != null && list.Count > 0)
				{
					text = list[Random.Range(0, list.Count)].dialogContent;
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetOlivierBattleDlg(DialogType dlgType)
	{
		string result = string.Empty;
		string text = "Olivier";
		string character = "Hana_Olivier_Roand";
		if (!_specialDialogs.AccordWith(text, character))
		{
			_specialDialogs.SetBattleDialog(text, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = dialogDictionary[dlgType];
			if (list != null && list.Count > 0)
			{
				result = list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		return result;
	}

	private string GetBlueReverberation2ndBattleDlg(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "The Blue Reverberation2 Roland";
		string character = "R_A_Roland";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = dialogDictionary[dlgType];
			if (list != null && list.Count > 0)
			{
				text = list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}
}
