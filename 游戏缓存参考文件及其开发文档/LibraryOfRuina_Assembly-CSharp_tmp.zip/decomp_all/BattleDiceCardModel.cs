using System;
using System.Collections.Generic;
using LOR_DiceSystem;
using UnityEngine;

public class BattleDiceCardModel
{
	public class CardIcon
	{
		private Sprite _icon;

		private int _priority;

		public Sprite Icon => _icon;

		public int Priority => _priority;

		public CardIcon(Sprite spr, int pri)
		{
			_icon = spr;
			_priority = pri;
		}
	}

	private DiceCardXmlInfo _originalXmlData;

	private DiceCardXmlInfo _xmlData;

	private CardDirection _cardDirection;

	private List<BattleDiceCardBuf> _bufList = new List<BattleDiceCardBuf>();

	private List<CardIcon> _addedIcons = new List<CardIcon>();

	private string _iconAdder = "";

	private int _costAdder;

	private bool _costZero;

	private int _priorityAdder;

	private int _curCost;

	public bool exhaust;

	public bool temporary;

	public bool costSpended;

	public bool isCopiedCard;

	public BattleUnitModel owner;

	private DiceCardSelfAbilityBase _script;

	private float maxCooltimeValue;

	private float currentCooltimeValue;

	public DiceCardXmlInfo XmlData => _xmlData;

	public int CurCost => _curCost;

	public float MaxCooltimeValue => maxCooltimeValue;

	public float CurrentCooltimeValue => currentCooltimeValue;

	public bool CanAddedEgoCard()
	{
		return currentCooltimeValue >= maxCooltimeValue;
	}

	public void SetMaxCooltime()
	{
		maxCooltimeValue = XmlData.EgoMaxCooltimeValue;
	}

	public void SetCurrentCostMax()
	{
		currentCooltimeValue = maxCooltimeValue;
	}

	public void AddCoolTime(float value)
	{
		currentCooltimeValue += value;
		if (currentCooltimeValue >= maxCooltimeValue)
		{
			currentCooltimeValue = maxCooltimeValue;
		}
	}

	public void ResetCoolTime()
	{
		currentCooltimeValue = 0f;
	}

	public void ReserveExhaust()
	{
		exhaust = true;
	}

	public void CopySelf()
	{
		_originalXmlData = _xmlData;
		_xmlData = _originalXmlData.Copy(deepCopy: true);
	}

	public void ResetToOriginalData()
	{
		if (_originalXmlData != null)
		{
			_xmlData = _originalXmlData.Copy();
		}
	}

	public string GetName()
	{
		if (LorId.IsModId(_xmlData.workshopID))
		{
			return _xmlData.workshopName;
		}
		return Singleton<BattleCardDescXmlList>.Instance.GetCardDesc(_xmlData.TextId).cardName;
	}

	public LorId GetID()
	{
		return _xmlData.id;
	}

	public LorId GetTextId()
	{
		return _xmlData.TextId;
	}

	public Rarity GetRarity()
	{
		return _xmlData.Rarity;
	}

	public int GetGrade()
	{
		return 1;
	}

	public DiceCardSpec GetSpec()
	{
		return _xmlData.Spec;
	}

	public bool IsExhaustOnUse()
	{
		return _xmlData.IsExhaustOnUse();
	}

	public void ChangeFarToNearForMyo()
	{
		if (_xmlData.Spec.Ranged != CardRange.Far)
		{
			return;
		}
		DiceCardSpec diceCardSpec = _xmlData.Spec.Copy();
		diceCardSpec.Ranged = CardRange.Near;
		_xmlData.Spec = diceCardSpec;
		List<DiceBehaviour> list = new List<DiceBehaviour>();
		foreach (DiceBehaviour diceBehaviour2 in _xmlData.DiceBehaviourList)
		{
			DiceBehaviour diceBehaviour = diceBehaviour2.Copy();
			diceBehaviour.EffectRes = "RCorp_Z";
			list.Add(diceBehaviour);
		}
		_xmlData.DiceBehaviourList = list;
	}

	public string GetSkin()
	{
		return _xmlData.SkinChange;
	}

	public CardSkinType GetSkinType()
	{
		return _xmlData.SkinChangeType;
	}

	public int GetSkinHeight()
	{
		return _xmlData.SkinHeight;
	}

	public string GetMap()
	{
		return _xmlData.MapChange;
	}

	public int GetPriority(int speed = 0)
	{
		int num = _xmlData.Priority;
		if (owner != null && _xmlData.PriorityScript != "")
		{
			try
			{
				DiceCardPriorityBase diceCardPriorityBase = Singleton<AssemblyManager>.Instance.CreateInstance_DiceCardPriority(_xmlData.PriorityScript);
				if (diceCardPriorityBase != null)
				{
					num += diceCardPriorityBase.GetPriorityBonus(owner);
					if (speed != 0)
					{
						num += diceCardPriorityBase.GetPriorityBonus(owner, speed);
					}
				}
				else
				{
					Debug.LogError("script not found : " + _xmlData.PriorityScript.Trim());
				}
			}
			catch (Exception exception)
			{
				Debug.LogException(exception);
			}
		}
		return num + _priorityAdder;
	}

	public void SetPriorityAdder(int v)
	{
		_priorityAdder = v;
	}

	public int GetPriorityAdder()
	{
		return _priorityAdder;
	}

	public int GetCost()
	{
		if (_script != null && _script.IsFixedCost())
		{
			return _xmlData.Spec.Cost;
		}
		int num = _curCost;
		if (_costZero)
		{
			num = 0;
		}
		foreach (BattleDiceCardBuf buf in _bufList)
		{
			num = buf.GetCost(num);
		}
		int num2 = 0;
		if (owner != null)
		{
			num2 += owner.emotionDetail.GetCardCostAdder(this);
			num2 += owner.bufListDetail.GetCardCostAdder(this);
			if (_script != null)
			{
				num2 += _script.GetCostAdder(owner, this);
			}
		}
		int num3 = num + _costAdder + num2;
		if (owner != null && _script != null && _script != null)
		{
			num3 = _script.GetCostLast(owner, this, num3);
		}
		return Mathf.Max(0, num3);
	}

	public void SetCurrentCost(int cost)
	{
		_curCost = cost;
	}

	public int GetOriginCost()
	{
		return _xmlData.Spec.Cost;
	}

	public List<DiceBehaviour> GetBehaviourList()
	{
		return _xmlData.DiceBehaviourList;
	}

	public string GetArtworkSrc()
	{
		return _xmlData.Artwork;
	}

	public BookCategory GetCategory()
	{
		return _xmlData.category;
	}

	public void SetAddedIcon(string resName, int priority = 0)
	{
		_iconAdder = resName;
		Sprite spr = Resources.Load<Sprite>("Sprites/CardAddedIcon/" + resName);
		if (_addedIcons.Find((CardIcon x) => x.Icon == spr) == null)
		{
			CardIcon item = new CardIcon(spr, priority);
			_addedIcons.Add(item);
			_addedIcons.Sort((CardIcon x, CardIcon y) => y.Priority - x.Priority);
		}
	}

	public void RemoveAddedIcon(string resName, int priority = 0)
	{
		_iconAdder = resName;
		Sprite spr = Resources.Load<Sprite>("Sprites/CardAddedIcon/" + resName);
		CardIcon cardIcon = _addedIcons.Find((CardIcon x) => x.Icon == spr);
		if (cardIcon != null)
		{
			_addedIcons.Remove(cardIcon);
		}
	}

	public Sprite GetAddedIcon(int idx)
	{
		Sprite result = null;
		if (idx < _addedIcons.Count)
		{
			result = _addedIcons[idx].Icon;
		}
		return result;
	}

	public BattleDiceCardBuf GetBufWithMostPriority()
	{
		BattleDiceCardBuf result = null;
		int num = -1;
		int num2 = -1;
		foreach (BattleDiceCardBuf buf in _bufList)
		{
			if (buf.Priority > num2)
			{
				num = buf.Stack;
				num2 = buf.Priority;
				result = buf;
			}
			else if (buf.Priority == num2 && buf.Stack > num)
			{
				num = buf.Stack;
				result = buf;
			}
		}
		return result;
	}

	public bool IsOnlyAllyUnit()
	{
		if (_script != null)
		{
			return _script.IsOnlyAllyUnit();
		}
		return false;
	}

	public bool IsTargetableSelf()
	{
		if (_script != null)
		{
			return _script.IsTargetableSelf();
		}
		return false;
	}

	public bool IsTargetableAllUnit()
	{
		if (_script != null)
		{
			return _script.IsTargetableAllUnit();
		}
		return false;
	}

	public bool IsValidTarget(BattleUnitModel unit, BattleDiceCardModel self, BattleUnitModel targetUnit)
	{
		bool result = true;
		if (_script != null)
		{
			result = _script.IsValidTarget(unit, self, targetUnit);
		}
		return result;
	}

	public void OnUseOtherCard_inHand(BattleUnitModel unit, BattlePlayingCardDataInUnitModel curCard)
	{
		if (_script != null)
		{
			_script.OnUseOtherCard_inHand(unit, this, curCard);
		}
	}

	public void OnLoseParrying_inHand(BattleUnitModel unit, BattleDiceBehavior behavior)
	{
		if (_script != null)
		{
			_script.OnLoseParrying_inHand(unit, this, behavior);
		}
	}

	public void OnWinParrying_inHand(BattleUnitModel unit, BattleDiceBehavior behavior)
	{
		if (_script != null)
		{
			_script.OnWinParrying_inHand(unit, this, behavior);
		}
	}

	public void OnRoundEnd(BattleUnitModel unit)
	{
		if (_script != null)
		{
			_script.OnRoundEnd(unit, this);
		}
	}

	public void OnRoundEnd_inHand(BattleUnitModel unit)
	{
		if (_script != null)
		{
			_script.OnRoundEnd_inHand(unit, this);
		}
	}

	public void OnRoundStart_inHand(BattleUnitModel unit)
	{
		if (_script != null)
		{
			_script.OnRoundStart_inHand(unit, this);
		}
	}

	public void OnBreakState_inHand(BattleUnitModel unit)
	{
		if (_script != null)
		{
			_script.OnBreakState_inHand(unit, this);
		}
	}

	public DiceCardSelfAbilityBase CreateDiceCardSelfAbilityScript()
	{
		return Singleton<AssemblyManager>.Instance.CreateInstance_DiceCardSelfAbility(_xmlData.Script);
	}

	public List<BattleDiceBehavior> CreateDiceCardBehaviorList()
	{
		List<BattleDiceBehavior> list = new List<BattleDiceBehavior>();
		int num = 0;
		foreach (DiceBehaviour diceBehaviour in _xmlData.DiceBehaviourList)
		{
			string script = diceBehaviour.Script;
			BattleDiceBehavior battleDiceBehavior = new BattleDiceBehavior();
			battleDiceBehavior.behaviourInCard = diceBehaviour.Copy();
			battleDiceBehavior.SetIndex(num);
			list.Add(battleDiceBehavior);
			if (script != string.Empty)
			{
				DiceCardAbilityBase diceCardAbilityBase = Singleton<AssemblyManager>.Instance.CreateInstance_DiceCardAbility(script);
				if (diceCardAbilityBase != null)
				{
					battleDiceBehavior.AddAbility(diceCardAbilityBase);
				}
				else
				{
					Debug.LogError("");
				}
			}
			num++;
		}
		return list;
	}

	public static BattleDiceCardModel CreatePlayingCard(DiceCardXmlInfo cardInfo)
	{
		BattleDiceCardModel obj = new BattleDiceCardModel
		{
			_xmlData = cardInfo.Copy(),
			_curCost = cardInfo.Spec.Cost
		};
		obj._script = obj.CreateDiceCardSelfAbilityScript();
		return obj;
	}

	public bool HasBuf<T>()
	{
		return _bufList.Exists((BattleDiceCardBuf x) => x is T);
	}

	public void AddBuf(BattleDiceCardBuf buf)
	{
		_bufList.Add(buf);
		buf.Init(this);
	}

	public void RemoveBuf(BattleDiceCardBuf buf)
	{
		if (_bufList.Contains(buf))
		{
			_bufList.Remove(buf);
		}
	}

	public void RemoveBuf<T>()
	{
		BattleDiceCardBuf battleDiceCardBuf = _bufList.Find((BattleDiceCardBuf x) => x is T);
		if (battleDiceCardBuf != null)
		{
			_bufList.Remove(battleDiceCardBuf);
		}
	}

	public List<BattleDiceCardBuf> GetBufList()
	{
		return new List<BattleDiceCardBuf>(_bufList);
	}

	public void AddBufWithoutDuplication(BattleDiceCardBuf buf)
	{
		if (buf.bufType != DiceCardBufType.None)
		{
			_bufList.RemoveAll((BattleDiceCardBuf x) => x.bufType == buf.bufType);
		}
		AddBuf(buf);
	}

	public void AddCost(int cost)
	{
		_costAdder += cost;
	}

	public void SetCostToZero(bool zero = true)
	{
		_costZero = zero;
	}

	public void OnUseCard(BattleUnitModel owner, BattlePlayingCardDataInUnitModel playingCard)
	{
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			if (!battleDiceCardBuf.IsDestroyed())
			{
				battleDiceCardBuf.OnUseCard(owner);
				battleDiceCardBuf.OnUseCard(owner, playingCard);
			}
		}
		CheckDestroyedBuf();
	}

	public void OnDiscard(BattleUnitModel owner, BattleDiceCardModel card)
	{
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			if (!battleDiceCardBuf.IsDestroyed())
			{
				battleDiceCardBuf.OnDiscard(owner, card);
			}
		}
	}

	public int OnAddKeywordBufByCard(BattleUnitBuf targetBuf, int stack)
	{
		int num = 0;
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			if (!battleDiceCardBuf.IsDestroyed())
			{
				num += battleDiceCardBuf.OnAddKeywordBufByCard(targetBuf, stack);
			}
		}
		return num;
	}

	public int OnGiveKeywordBufByCard(BattleUnitBuf targetBuf, int stack, BattleUnitModel target)
	{
		int num = 0;
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			if (!battleDiceCardBuf.IsDestroyed())
			{
				num += battleDiceCardBuf.OnGiveKeywordBufByCard(targetBuf, stack, target);
			}
		}
		return num;
	}

	public void CheckDestroyedBuf()
	{
		List<BattleDiceCardBuf> list = new List<BattleDiceCardBuf>();
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			try
			{
				if (battleDiceCardBuf.IsDestroyed())
				{
					list.Add(battleDiceCardBuf);
				}
			}
			catch (Exception exception)
			{
				Debug.LogException(exception);
			}
		}
		foreach (BattleDiceCardBuf item in list)
		{
			RemoveBuf(item);
		}
	}

	public void OnRoundStart()
	{
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			if (!battleDiceCardBuf.IsDestroyed())
			{
				battleDiceCardBuf.OnRoundStart();
			}
		}
		CheckDestroyedBuf();
	}

	public void OnDrawCard()
	{
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			if (!battleDiceCardBuf.IsDestroyed())
			{
				battleDiceCardBuf.OnDrawCard();
			}
		}
		CheckDestroyedBuf();
	}

	public void OnRoundEnd()
	{
		BattleDiceCardBuf[] array = _bufList.ToArray();
		foreach (BattleDiceCardBuf battleDiceCardBuf in array)
		{
			if (!battleDiceCardBuf.IsDestroyed())
			{
				battleDiceCardBuf.OnRoundEnd();
			}
		}
		CheckDestroyedBuf();
	}
}
