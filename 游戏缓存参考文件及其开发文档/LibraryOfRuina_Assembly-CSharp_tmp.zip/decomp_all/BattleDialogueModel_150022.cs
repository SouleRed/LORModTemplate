using LOR_XML;

public class BattleDialogueModel_150022 : BattleDialogueModel
{
	public BattleDialogueModel_150022(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		ResetDialogData(dlgType);
		return base.GetBattleDlg(dlgType);
	}

	private void ResetDialogData(DialogType dlgType)
	{
		if (dlgType != DialogType.START_BATTLE)
		{
			return;
		}
		switch (Singleton<StageController>.Instance.CurrentFloor)
		{
		case SephirahType.Gebura:
			if (_xmlInfo.characterID != "RedMist_MeetGebura")
			{
				BattleDialogCharacter characterData2 = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("RedMist", "RedMist_MeetGebura");
				Init(characterData2);
			}
			break;
		case SephirahType.Keter:
			if (_xmlInfo.characterID != "RedMist_MeetRoland")
			{
				BattleDialogCharacter characterData3 = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("RedMist", "RedMist_MeetRoland");
				Init(characterData3);
			}
			break;
		case SephirahType.Binah:
			if (_xmlInfo.characterID != "RedMist_MeetBinah")
			{
				BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("RedMist", "RedMist_MeetBinah");
				Init(characterData);
			}
			break;
		}
	}
}
