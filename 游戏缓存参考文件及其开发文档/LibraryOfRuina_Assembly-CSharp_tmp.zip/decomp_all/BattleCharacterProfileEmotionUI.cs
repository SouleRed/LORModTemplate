using TMPro;
using UnityEngine;

public class BattleCharacterProfileEmotionUI : MonoBehaviour
{
	[SerializeField]
	private TextMeshProUGUI txt_emotionLv_Prev;

	[SerializeField]
	private TextMeshProUGUI txt_emotionLv_Next;

	private Animator Anim;

	public void Init(int lv)
	{
		StopAllCoroutines();
		Anim = GetComponent<Animator>();
		Anim.SetTrigger("Default");
		switch (lv)
		{
		case 0:
			txt_emotionLv_Next.text = "O";
			txt_emotionLv_Prev.text = "O";
			break;
		case 1:
			txt_emotionLv_Next.text = "I";
			txt_emotionLv_Prev.text = "I";
			break;
		case 2:
			txt_emotionLv_Next.text = "II";
			txt_emotionLv_Prev.text = "II";
			break;
		case 3:
			txt_emotionLv_Next.text = "III";
			txt_emotionLv_Prev.text = "III";
			break;
		case 4:
			txt_emotionLv_Next.text = "IV";
			txt_emotionLv_Prev.text = "IV";
			break;
		case 5:
			txt_emotionLv_Next.text = "V";
			txt_emotionLv_Prev.text = "V";
			break;
		default:
			Debug.Log("Level bug :: out of range LV");
			break;
		}
	}

	public void UpdateEmotion(int emotionLV)
	{
		StopAllCoroutines();
		switch (emotionLV)
		{
		case 0:
			txt_emotionLv_Next.text = "O";
			break;
		case 1:
			txt_emotionLv_Next.text = "I";
			break;
		case 2:
			txt_emotionLv_Next.text = "II";
			break;
		case 3:
			txt_emotionLv_Next.text = "III";
			break;
		case 4:
			txt_emotionLv_Next.text = "IV";
			break;
		case 5:
			txt_emotionLv_Next.text = "V";
			break;
		default:
			Debug.Log("Level bug :: out of range LV");
			return;
		}
		Anim.SetTrigger("LevelUp");
	}

	public void SetEmotionLv()
	{
		txt_emotionLv_Prev.text = txt_emotionLv_Next.text;
	}

	public void SetGrayScaleColor(bool _grayScaled)
	{
		Color color = txt_emotionLv_Next.color;
		color *= (_grayScaled ? 0.25f : 4f);
		color.a = 1f;
		txt_emotionLv_Next.color = color;
		txt_emotionLv_Prev.color = color;
	}
}
