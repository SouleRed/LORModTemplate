using LOR_XML;

public class BattleDialogueModel_150024 : BattleDialogueModel
{
	private bool _bMeetGebura;

	public BattleDialogueModel_150024(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bMeetGebura = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.CurrentFloor == SephirahType.Gebura && !_bMeetGebura)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep1", "R_Corp_Myo_Meet_Gebura_1");
			Init(characterData);
			_bMeetGebura = true;
		}
		return base.GetBattleDlg(dlgType);
	}
}
