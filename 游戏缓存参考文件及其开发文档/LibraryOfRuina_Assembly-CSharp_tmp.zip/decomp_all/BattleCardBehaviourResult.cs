using System;
using System.Collections.Generic;
using Battle.CreatureEffect;
using LOR_DiceSystem;

public class BattleCardBehaviourResult
{
	public delegate void BehaviourEvent();

	public struct CreatureEffectInfo
	{
		public string path;

		public float time;
	}

	public BehaviourEvent succeedAtkEvent;

	public BehaviourEvent succeedDefEvent;

	public BehaviourEvent takeDamageEvent;

	public BehaviourEvent rolldiceEvent;

	public BehaviourEvent afterActionEvent;

	public BehaviourEvent printAtkEffectEvent;

	public BehaviourEvent printDamagedEffectEvent;

	public BattleCardBehaviourStack currentAllDiceState = new BattleCardBehaviourStack();

	public BattleBufUIDataList bufDataList = new BattleBufUIDataList();

	public bool hasBehaviour;

	public BattlePlayingCardDataInUnitModel playingCard;

	public BattleDiceBehavior behaviour;

	public BattleDiceCardModel cardModel;

	public DiceBehaviour behaviourRawData;

	public int behaviourIdx;

	public bool isDestroyed;

	public int vanillaDiceFace;

	public int vanillaDiceMin;

	public int recoveredLight;

	public int diceTypeBonus;

	public int vanillaDiceValue;

	public List<int> vanillaDiceValueList = new List<int>();

	public int resultDiceMin;

	public int resultDiceMax;

	public int resultDiceValue;

	public int iParam;

	public List<string> bufBeforeRoll = new List<string>();

	public List<string> bufAfterRoll = new List<string>();

	public List<string> debufBeforeRoll = new List<string>();

	public List<string> debufAfterRoll = new List<string>();

	public List<string> giftAbilityBeforeRoll = new List<string>();

	public List<string> giftAbilityAfterRoll = new List<string>();

	public List<string> emotionAbilityBeforeRoll = new List<string>();

	public List<string> emotionAbilityAfterRoll = new List<string>();

	public Dictionary<string, BattleEmotionCardModel> activatedEmotionCardDictionary = new Dictionary<string, BattleEmotionCardModel>();

	public List<string> behaviourAbilityBeforeRoll = new List<string>();

	public Dictionary<int, string> behaviourAbilityAfterRoll = new Dictionary<int, string>();

	public List<string> bookAbilityAfterRoll = new List<string>();

	public DiceBehaviourResultData diceBehaviourResult;

	public bool isDead;

	public bool isBreaked;

	public bool isBlockedDice;

	public List<int> dmgListGiven = new List<int>();

	public List<DmgTakenData> dmgListTaken = new List<DmgTakenData>();

	public List<int> breakListGiven = new List<int>();

	public List<DmgTakenData> breakListTaken = new List<DmgTakenData>();

	public List<int> recoveredHpList = new List<int>();

	public List<int> recoveredBpList = new List<int>();

	public List<string> addedAbnormalityEffectList = new List<string>();

	public List<CreatureEffectInfo> addedCreatureEffectList = new List<CreatureEffectInfo>();

	public List<CreatureEffect> creatureEffects = new List<CreatureEffect>();

	public List<string> craetureEffectSounds = new List<string>();

	public List<string> _addedBufEffect = new List<string>();

	private List<EmotionCoinType> _emotionCoinAdder = new List<EmotionCoinType>();

	public List<Type> addedAttackFilterList = new List<Type>();

	public float curHp;

	public int curBreakGauge;

	public bool ignoreDamagedMotion;

	public List<BattleUnitBuf> bufDataAfterRoll = new List<BattleUnitBuf>();

	public List<BattleEmotionCardModel> emotionAbilityDataAfterRoll = new List<BattleEmotionCardModel>();

	public List<PassiveAbilityBase> bookAbilityDataAfterRoll = new List<PassiveAbilityBase>();

	public bool IsFarAtk()
	{
		bool result = false;
		BattleDiceCardModel battleDiceCardModel = cardModel;
		if (battleDiceCardModel != null && battleDiceCardModel.GetSpec().Ranged == CardRange.Far)
		{
			DiceBehaviour diceBehaviour = behaviourRawData;
			if (diceBehaviour != null && diceBehaviour.Type == BehaviourType.Atk)
			{
				result = true;
			}
		}
		return result;
	}

	public List<string> GetAllAbilityStrings()
	{
		List<string> list = new List<string>();
		list.AddRange(bufBeforeRoll);
		list.AddRange(bufAfterRoll);
		list.AddRange(debufBeforeRoll);
		list.AddRange(debufAfterRoll);
		list.AddRange(giftAbilityBeforeRoll);
		list.AddRange(giftAbilityAfterRoll);
		list.AddRange(emotionAbilityBeforeRoll);
		list.AddRange(emotionAbilityAfterRoll);
		list.AddRange(behaviourAbilityBeforeRoll);
		foreach (KeyValuePair<int, string> item in behaviourAbilityAfterRoll)
		{
			list.Add(item.Value);
		}
		list.AddRange(bookAbilityAfterRoll);
		list.RemoveAll((string x) => x == "");
		return list;
	}

	public Queue<BattleEmotionCardModel> GetActivatedEmotionCards()
	{
		Queue<BattleEmotionCardModel> queue = new Queue<BattleEmotionCardModel>();
		foreach (KeyValuePair<string, BattleEmotionCardModel> item in activatedEmotionCardDictionary)
		{
			queue.Enqueue(item.Value);
		}
		return queue;
	}

	public List<string> GetAbilityStringsBeforeRoll()
	{
		List<string> list = new List<string>();
		list.AddRange(bufBeforeRoll);
		list.AddRange(debufBeforeRoll);
		list.AddRange(giftAbilityBeforeRoll);
		list.AddRange(emotionAbilityBeforeRoll);
		list.AddRange(behaviourAbilityBeforeRoll);
		list.RemoveAll((string x) => x == "");
		return list;
	}

	public List<string> GetAbilityStringsAfterRoll()
	{
		List<string> list = new List<string>();
		list.AddRange(bufAfterRoll);
		list.AddRange(debufAfterRoll);
		list.AddRange(giftAbilityAfterRoll);
		list.AddRange(emotionAbilityAfterRoll);
		foreach (KeyValuePair<int, string> item in behaviourAbilityAfterRoll)
		{
			if (item.Value != "")
			{
				list.Add(item.Value);
			}
		}
		list.AddRange(bookAbilityAfterRoll);
		list.RemoveAll((string x) => x == "");
		return list;
	}

	public List<EffectTypoData> GetAbilityDataAfterRoll()
	{
		Dictionary<EffectTypoCategory, List<EffectTypoData>> dictionary = new Dictionary<EffectTypoCategory, List<EffectTypoData>>();
		for (int i = 0; i < Enum.GetValues(typeof(EffectTypoCategory)).Length; i++)
		{
			dictionary[(EffectTypoCategory)i] = new List<EffectTypoData>();
		}
		if (bufDataAfterRoll.Count != 0)
		{
			foreach (BattleUnitBuf item in bufDataAfterRoll)
			{
				switch (item.bufType.ToString())
				{
				case "Paralysis":
				case "Strength":
				case "Weak":
				case "Endurance":
				case "Disarm":
				case "Bleeding":
				case "Protection":
				case "Vulnerable":
				{
					EffectTypoCategory effectTypoCategory = (EffectTypoCategory)Enum.Parse(typeof(EffectTypoCategory), item.bufType.ToString());
					dictionary[effectTypoCategory].Add(new EffectTypoData(effectTypoCategory, item.bufActivatedText));
					break;
				}
				}
			}
		}
		if (emotionAbilityDataAfterRoll.Count != 0)
		{
			foreach (BattleEmotionCardModel item2 in emotionAbilityDataAfterRoll)
			{
				EffectTypoCategory effectTypoCategory2 = ((item2.XmlInfo.State == MentalState.Positive) ? EffectTypoCategory.PostiveAbnormality : EffectTypoCategory.NegativePassvie);
				string[] param = new string[0];
				dictionary[effectTypoCategory2].Add(new EffectTypoData(effectTypoCategory2, item2.GetTypoText(0, param)));
			}
		}
		foreach (KeyValuePair<int, string> item3 in behaviourAbilityAfterRoll)
		{
			EffectTypoCategory effectTypoCategory3 = EffectTypoCategory.Dice;
			if (!(item3.Value == ""))
			{
				dictionary[effectTypoCategory3].Add(new EffectTypoData(effectTypoCategory3, item3.Value));
			}
		}
		foreach (PassiveAbilityBase item4 in bookAbilityDataAfterRoll)
		{
			EffectTypoCategory effectTypoCategory4 = (item4.isNegative ? EffectTypoCategory.NegativePassvie : EffectTypoCategory.Passive);
			dictionary[effectTypoCategory4].Add(new EffectTypoData(effectTypoCategory4, item4.desc, item4.name));
		}
		List<EffectTypoData> list = new List<EffectTypoData>();
		for (int j = 0; j < Enum.GetValues(typeof(EffectTypoCategory)).Length; j++)
		{
			if (dictionary[(EffectTypoCategory)j].Count != 0)
			{
				list.AddRange(dictionary[(EffectTypoCategory)j]);
			}
		}
		return list;
	}

	public void SetEmotionCoinAdded(EmotionCoinType coin, int count)
	{
		for (int i = 0; i < count; i++)
		{
			_emotionCoinAdder.Add(coin);
		}
	}

	public List<EmotionCoinType> GetAddedEmotionCoins()
	{
		return _emotionCoinAdder;
	}

	public void AddBufEffect(string src)
	{
		_addedBufEffect.Add(src);
	}

	public List<string> GetAddedBufEffect()
	{
		return _addedBufEffect;
	}
}
