using System;
using UnityEngine;

public class BattleDiceCardBuf
{
	protected BattleDiceCardModel _card;

	protected int _stack = -1;

	protected int _priority = -1;

	private bool _isDestroyed;

	private bool _iconInit;

	private Sprite _bufIcon;

	public virtual DiceCardBufType bufType => DiceCardBufType.None;

	public int Stack => _stack;

	public virtual int paramInBufDesc => _stack;

	public int Priority => _priority;

	protected virtual string keywordId => "";

	protected virtual string keywordIconId => keywordId;

	public string bufActivatedText
	{
		get
		{
			if (string.IsNullOrEmpty(keywordId))
			{
				return "";
			}
			return Singleton<BattleEffectTextsXmlList>.Instance.GetEffectTextDesc("CardBuf_" + keywordId, paramInBufDesc);
		}
	}

	public Sprite GetBufIcon()
	{
		if (!_iconInit)
		{
			try
			{
				if (!string.IsNullOrEmpty(keywordIconId))
				{
					_bufIcon = Resources.Load<Sprite>("Sprites/CardAddedIcon/" + keywordIconId);
				}
			}
			catch (Exception)
			{
				_bufIcon = null;
			}
			_iconInit = true;
		}
		return _bufIcon;
	}

	public void Destroy()
	{
		_isDestroyed = true;
	}

	public bool IsDestroyed()
	{
		return _isDestroyed;
	}

	public void Init(BattleDiceCardModel card)
	{
		_card = card;
	}

	public virtual int GetCost(int oldCost)
	{
		return oldCost;
	}

	public virtual void OnUseCard(BattleUnitModel owner)
	{
	}

	public virtual void OnUseCard(BattleUnitModel owner, BattlePlayingCardDataInUnitModel playingCard)
	{
	}

	public virtual void OnDiscard(BattleUnitModel owner, BattleDiceCardModel card)
	{
	}

	public virtual void OnRoundStart()
	{
	}

	public virtual void OnDrawCard()
	{
	}

	public virtual void OnRoundEnd()
	{
	}

	public virtual int OnAddKeywordBufByCard(BattleUnitBuf cardBuf, int stack)
	{
		return 0;
	}

	public virtual int OnGiveKeywordBufByCard(BattleUnitBuf cardBuf, int stack, BattleUnitModel target)
	{
		return 0;
	}
}
