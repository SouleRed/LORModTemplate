using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_7 : BattleDialogueModel_Sephirah
{
	private string _groupId_Default = "LibraryOfRuina";

	private string _characterId_Default = "Chesed";

	private int _stageId_pluto1st = 70007;

	private SpecialBattleDialog _specialDialogs;

	public BattleDialogueModel_7(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_specialDialogs = new SpecialBattleDialog();
		_specialDialogs.SetBattleDialog(_groupId_Default, _characterId_Default);
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		LorId id = Singleton<StageController>.Instance.GetStageModel().ClassInfo.id;
		if (id == _stageId_pluto1st)
		{
			return GetBattleDlg_Pluto1st(dlgType);
		}
		if (id == 60003)
		{
			return GetBattleDlg_BS(dlgType, SephirahType.Chesed, "Chessed");
		}
		if (id == 60004)
		{
			return GetBattleDlg_RB2(dlgType, SephirahType.Chesed, "Chessed");
		}
		return GetNormalBattleDlg(dlgType);
	}

	private string GetBattleDlg_Pluto1st(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "The Blue Reverberation2 Chesed";
		string character = "C_J_Chesed";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = dialogDictionary[dlgType];
			if (list.Count > 0)
			{
				text = list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetNormalBattleDlg(DialogType dlgType)
	{
		if (_xmlInfo.characterID != _characterId_Default)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData(_groupId_Default, _characterId_Default);
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}
}
