using LOR_XML;

public class BattleDialogueModel_14 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_14(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Netzach";
		_characterId_RB1 = "N_B_Librarian_";
		_stageId_RB1 = 70004;
		_characterId_BS = "N_Librarian";
		_sephirahType = SephirahType.Netzach;
		_characterId_RB2 = _characterId_BS;
	}
}
