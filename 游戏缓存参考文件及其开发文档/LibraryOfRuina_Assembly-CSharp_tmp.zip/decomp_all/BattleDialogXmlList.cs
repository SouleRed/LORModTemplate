using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogXmlList : Singleton<BattleDialogXmlList>
{
	public const string WorkshopDictionaryKey = "Workshop";

	private Dictionary<string, BattleDialogRoot> _dictionary;

	private List<BattleDialogRelationWithBookID> _relationList;

	public void Init(Dictionary<string, BattleDialogRoot> dictionary, List<BattleDialogRelationWithBookID> list)
	{
		_dictionary = dictionary;
		_relationList = list;
	}

	public void AddDialogByMod(List<BattleDialogCharacter> list)
	{
		if (_dictionary.ContainsKey("Workshop"))
		{
			_dictionary["Workshop"].characterList.AddRange(list);
			return;
		}
		BattleDialogRoot battleDialogRoot = new BattleDialogRoot();
		battleDialogRoot.groupName = "Workshop";
		battleDialogRoot.characterList = list;
		_dictionary.Add("Workshop", battleDialogRoot);
	}

	public BattleDialogRoot GetGroupData(string groupID)
	{
		if (_dictionary.TryGetValue(groupID, out var value))
		{
			return value;
		}
		Debug.LogErrorFormat("BattleDialogues : [{0}] does not exist.", groupID);
		return null;
	}

	public BattleDialogCharacter GetCharacterData(string groupID, string characterID)
	{
		BattleDialogCharacter battleDialogCharacter = GetGroupData(groupID)?.characterList.Find((BattleDialogCharacter x) => x.characterID == characterID);
		if (battleDialogCharacter != null)
		{
			return battleDialogCharacter;
		}
		Debug.LogErrorFormat("BattleDialogues : [{0}] does not exist in [{1}]", characterID, groupID);
		return null;
	}

	public BattleDialogCharacter GetCharacterData(int bookID)
	{
		BattleDialogRelationWithBookID relation = _relationList.Find((BattleDialogRelationWithBookID x) => x.bookID == bookID);
		BattleDialogCharacter result = null;
		if (relation != null)
		{
			result = GetGroupData(relation.groupName)?.characterList.Find((BattleDialogCharacter x) => x.characterID == relation.characterID);
		}
		return result;
	}

	public BattleDialogCharacter GetCharacterData_Mod(string workshopId, int bookID)
	{
		return GetGroupData("Workshop")?.characterList.Find((BattleDialogCharacter x) => x.workshopId == workshopId && x.bookId == bookID);
	}

	public List<BattleDialog> GetDialogPresetByType(DialogType type)
	{
		return (GetGroupData("Librarian")?.characterList.Find((BattleDialogCharacter x) => x.characterID == "Librarian")).dialogTypeList.Find((BattleDialogType x) => x.dialogType == type).dialogList;
	}

	public BattleDialog GetDialogPresetByType(DialogType type, string id)
	{
		return (GetGroupData("Librarian")?.characterList.Find((BattleDialogCharacter x) => x.characterID == "Librarian")).dialogTypeList.Find((BattleDialogType x) => x.dialogType == type).dialogList.Find((BattleDialog x) => x.dialogID == id);
	}
}
