using System.Collections.Generic;
using LOR_XML;
using UnityEngine;

public class BattleDialogueModel_6 : BattleDialogueModel_Sephirah
{
	private bool _bMeetArgalia;

	private bool _bKillArgalia;

	private bool _bMeetMyo_ep1;

	private bool _bKillMyo_ep1;

	private bool _bMeetMyo_ep2_1;

	private bool _bKillMyo_ep2_1;

	private bool _bMeetMyo_ep2_2;

	private bool _bKillMyo_ep2_2;

	private bool _bKilledPurpleTear;

	private SpecialBattleDialog _specialDialogs;

	public BattleDialogueModel_6(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bMeetArgalia = false;
		_bKillArgalia = false;
		_bKilledPurpleTear = false;
		_bMeetMyo_ep1 = false;
		_bKillMyo_ep1 = false;
		_bMeetMyo_ep2_1 = false;
		_bKillMyo_ep2_1 = false;
		_bMeetMyo_ep2_2 = false;
		_bKillMyo_ep2_2 = false;
		_specialDialogs = new SpecialBattleDialog();
		_specialDialogs.SetBattleDialog("LibraryOfRuina", "Gebura");
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		LorId id = Singleton<StageController>.Instance.GetStageModel().ClassInfo.id;
		if (id == 50006)
		{
			return GetBattleDlg_BlueReverberation(dlgType);
		}
		if (id == 50009)
		{
			return GetBattleDlg_RedMist(dlgType);
		}
		if (id == 50010)
		{
			return GetBattleDlg_MeetMyoEp1(dlgType);
		}
		if (id == 50011)
		{
			return GetBattleDlg_MeetMyoEp2(dlgType);
		}
		if (id == 50012)
		{
			return GetBattleDlg_PurpleTear(dlgType);
		}
		if (id == 70006)
		{
			return GetTanya1stBattleDlg(dlgType);
		}
		if (id == 60007)
		{
			return "";
		}
		if (id == 60003)
		{
			return GetBattleDlg_BS(dlgType, SephirahType.Gebura, "Gebura");
		}
		if (id == 60004)
		{
			return GetBattleDlg_RB2(dlgType, SephirahType.Gebura, "Gebura");
		}
		if (_xmlInfo.characterID != "Gebura")
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("LibraryOfRuina", "Gebura");
			Init(characterData);
		}
		return base.GetBattleDlg(dlgType);
	}

	private string GetBattleDlg_BlueReverberation(DialogType dlgType)
	{
		string text = string.Empty;
		if (Singleton<StageController>.Instance.CurrentWave == 2)
		{
			string text2 = "BlueReverberation1";
			string character = "Gebura_MeetArgalia";
			if (!_specialDialogs.AccordWith(text2, character))
			{
				_specialDialogs.SetBattleDialog(text2, character);
			}
			Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
			if (dialogDictionary != null)
			{
				BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50013);
				if (dlgType == DialogType.START_BATTLE && !battleUnitModel.IsDead())
				{
					_bMeetMyo_ep1 = true;
				}
				if (_bMeetArgalia)
				{
					if (dlgType == DialogType.KILLS_OPPONENT && !_bKillArgalia && battleUnitModel != null && battleUnitModel.IsDead())
					{
						_bKillArgalia = true;
						if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
						{
							BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
							if (battleDialog != null)
							{
								text = battleDialog.dialogContent;
							}
						}
					}
					else if (dialogDictionary.ContainsKey(dlgType))
					{
						List<BattleDialog> list = dialogDictionary[dlgType];
						if (list.Count > 0)
						{
							text = list[Random.Range(0, list.Count)].dialogContent;
						}
					}
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetBattleDlg_RedMist(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "RedMist";
		string character = "Gebura_MeetRedMist";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
		{
			List<BattleDialog> list = dialogDictionary[dlgType];
			if (list.Count > 0)
			{
				text = list[Random.Range(0, list.Count)].dialogContent;
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetBattleDlg_PurpleTear(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "PupleTear";
		string character = "Gebura_MeetPupleTear";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50035);
			if (!_bKilledPurpleTear && battleUnitModel != null && battleUnitModel.IsDead())
			{
				_bKilledPurpleTear = true;
				if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
				{
					BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
					if (battleDialog != null)
					{
						text = battleDialog.dialogContent;
					}
				}
			}
			else if (dialogDictionary.ContainsKey(dlgType))
			{
				List<BattleDialog> list = dialogDictionary[dlgType];
				if (list != null && list.Count > 0)
				{
					text = list[Random.Range(0, list.Count)].dialogContent;
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetBattleDlg_MeetMyoEp1(DialogType dlgType)
	{
		string text = string.Empty;
		if (Singleton<StageController>.Instance.CurrentWave == 3)
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50024);
			if (dlgType == DialogType.START_BATTLE && !battleUnitModel.IsDead())
			{
				_bMeetMyo_ep1 = true;
			}
			if (_bMeetMyo_ep1)
			{
				string text2 = "r_corp_ep1";
				string character = "R_Corp_Gebura_Meet_Myo_1";
				if (!_specialDialogs.AccordWith(text2, character))
				{
					_specialDialogs.SetBattleDialog(text2, character);
				}
				Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
				if (dialogDictionary != null)
				{
					if (dlgType == DialogType.KILLS_OPPONENT && !_bKillMyo_ep1 && battleUnitModel != null && battleUnitModel.IsDead())
					{
						_bKillMyo_ep1 = true;
						if (dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
						{
							BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_" + Random.Range(0, 2));
							if (battleDialog != null)
							{
								text = battleDialog.dialogContent;
							}
						}
					}
					else if (dialogDictionary.ContainsKey(dlgType))
					{
						List<BattleDialog> list = dialogDictionary[dlgType];
						if (list.Count > 0)
						{
							text = list[Random.Range(0, list.Count)].dialogContent;
						}
					}
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetBattleDlg_MeetMyoEp2(DialogType dlgType)
	{
		string text = string.Empty;
		switch (Singleton<StageController>.Instance.CurrentWave)
		{
		case 3:
		{
			BattleUnitModel battleUnitModel2 = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50028);
			if (dlgType == DialogType.START_BATTLE && !battleUnitModel2.IsDead())
			{
				_bMeetMyo_ep2_1 = true;
			}
			if (!_bMeetMyo_ep2_1)
			{
				break;
			}
			string text3 = "r_corp_ep2";
			string character2 = "R_Corp_Gebura_Meet_Myo_2_1";
			if (!_specialDialogs.AccordWith(text3, character2))
			{
				_specialDialogs.SetBattleDialog(text3, character2);
			}
			Dictionary<DialogType, List<BattleDialog>> dialogDictionary2 = _specialDialogs.GetDialogDictionary();
			if (dialogDictionary2 == null)
			{
				break;
			}
			if (dlgType == DialogType.KILLS_OPPONENT && !_bKillMyo_ep2_1 && battleUnitModel2 != null && battleUnitModel2.IsDead())
			{
				_bKillMyo_ep2_1 = true;
				if (dialogDictionary2.ContainsKey(DialogType.SPECIAL_EVENT))
				{
					BattleDialog battleDialog = dialogDictionary2[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
					if (battleDialog != null)
					{
						text = battleDialog.dialogContent;
					}
				}
			}
			else if (dialogDictionary2.ContainsKey(dlgType))
			{
				List<BattleDialog> list2 = dialogDictionary2[dlgType];
				if (list2.Count > 0)
				{
					text = list2[Random.Range(0, list2.Count)].dialogContent;
				}
			}
			break;
		}
		case 4:
		{
			BattleUnitModel battleUnitModel = BattleObjectManager.instance.GetList(Faction.Enemy).Find((BattleUnitModel x) => x.UnitData.unitData.EnemyUnitId == 50032);
			if (dlgType == DialogType.START_BATTLE && !battleUnitModel.IsDead())
			{
				_bMeetMyo_ep2_2 = true;
			}
			if (!_bMeetMyo_ep2_2)
			{
				break;
			}
			string text2 = "r_corp_ep2";
			string character = "R_Corp_Gebura_Meet_Myo_2_2";
			if (!_specialDialogs.AccordWith(text2, character))
			{
				_specialDialogs.SetBattleDialog(text2, character);
			}
			Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
			if (dialogDictionary != null && dialogDictionary.ContainsKey(dlgType))
			{
				List<BattleDialog> list = dialogDictionary[dlgType];
				if (list.Count > 0)
				{
					text = list[Random.Range(0, list.Count)].dialogContent;
				}
			}
			break;
		}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}

	private string GetTanya1stBattleDlg(DialogType dlgType)
	{
		string text = string.Empty;
		string text2 = "The Blue Reverberation2 Gebura";
		string character = "G_T_Gebura";
		if (!_specialDialogs.AccordWith(text2, character))
		{
			_specialDialogs.SetBattleDialog(text2, character);
		}
		Dictionary<DialogType, List<BattleDialog>> dialogDictionary = _specialDialogs.GetDialogDictionary();
		if (dialogDictionary != null)
		{
			if (dlgType == DialogType.BATTLE_VICTORY && dialogDictionary.ContainsKey(DialogType.SPECIAL_EVENT))
			{
				BattleDialog battleDialog = dialogDictionary[DialogType.SPECIAL_EVENT].Find((BattleDialog x) => x.dialogID == "SPECIAL_EVENT_0");
				if (battleDialog != null)
				{
					text = battleDialog.dialogContent;
				}
			}
			if (dialogDictionary.ContainsKey(dlgType))
			{
				List<BattleDialog> list = dialogDictionary[dlgType];
				if (list.Count > 0)
				{
					text = list[Random.Range(0, list.Count)].dialogContent;
				}
			}
		}
		if (text == string.Empty)
		{
			text = base.GetBattleDlg(dlgType);
		}
		return text;
	}
}
