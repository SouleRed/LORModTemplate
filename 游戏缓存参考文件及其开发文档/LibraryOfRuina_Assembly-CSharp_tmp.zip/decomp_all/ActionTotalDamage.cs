using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ActionTotalDamage : MonoBehaviour
{
	public Image[] imgDamageNumbers;

	public Transform layoutRoot;

	private List<Image> numberList = new List<Image>();

	private float elapsed;

	public void ResetNumber()
	{
		for (int i = 0; i < numberList.Count; i++)
		{
			Object.Destroy(numberList[i].gameObject);
		}
		numberList.Clear();
	}

	public void CreateDamageText(int dmg)
	{
		if (dmg <= 0)
		{
			Image image = Object.Instantiate(imgDamageNumbers[0], layoutRoot);
			image.transform.localRotation = Quaternion.Euler(0f, 0f, Random.Range(-4f, 4f));
			numberList.Add(image);
			return;
		}
		int num = (int)Mathf.Log10(dmg);
		int num2 = (int)Mathf.Pow(10f, num);
		int num3 = dmg;
		while (num2 > 0)
		{
			int num4 = num3 / num2;
			Image image2 = Object.Instantiate(imgDamageNumbers[num4], layoutRoot);
			image2.color = Color.red;
			numberList.Add(image2);
			image2.transform.localRotation = Quaternion.Euler(0f, 0f, Random.Range(-4f, 4f));
			num3 %= num2;
			num2 /= 10;
		}
	}
}
