using System.Collections.Generic;
using LOR_XML;

public class BattleEffectTextsXmlList : Singleton<BattleEffectTextsXmlList>
{
	private Dictionary<string, BattleEffectText> _dictionary;

	public void Init(Dictionary<string, BattleEffectText> dictionary)
	{
		_dictionary = dictionary;
	}

	public BattleEffectText GetEffectText(string id)
	{
		BattleEffectText battleEffectText = null;
		if (_dictionary.ContainsKey(id))
		{
			battleEffectText = _dictionary[id];
		}
		else
		{
			battleEffectText = new BattleEffectText();
			battleEffectText.ID = "NOT_FOUND";
			battleEffectText.Name = "Not found";
			battleEffectText.Desc = "Not found";
		}
		return battleEffectText;
	}

	public string GetEffectTextName(string id)
	{
		string result = "";
		if (_dictionary.ContainsKey(id))
		{
			result = _dictionary[id].Name;
		}
		return result;
	}

	public string GetEffectTextDesc(string id, int stack)
	{
		string result = "Desc not found";
		if (_dictionary.ContainsKey(id) && _dictionary[id].Desc != null)
		{
			result = string.Format(_dictionary[id].Desc, stack);
		}
		return result;
	}

	public string GetEffectTextDesc(string id, params object[] args)
	{
		string result = "Desc not found";
		if (_dictionary.ContainsKey(id) && _dictionary[id].Desc != null)
		{
			result = string.Format(_dictionary[id].Desc, args);
		}
		return result;
	}

	public string GetEffectTextDesc(string id)
	{
		if (_dictionary.ContainsKey(id))
		{
			if (_dictionary[id].Desc == null)
			{
				return "";
			}
			return _dictionary[id].Desc.Replace("{0}", "X");
		}
		return "";
	}
}
