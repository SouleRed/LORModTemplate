using LOR_XML;

public class BattleDialogueModel_150102 : BattleDialogueModel
{
	private bool _bSecondBattle;

	public BattleDialogueModel_150102(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_bSecondBattle = false;
	}

	public override string GetBattleDlg(DialogType dlgType)
	{
		if (Singleton<StageController>.Instance.GetStageModel().ClassInfo.id == 50011 && !_bSecondBattle)
		{
			BattleDialogCharacter characterData = Singleton<BattleDialogXmlList>.Instance.GetCharacterData("r_corp_ep2", "R_Corp_Rhinoceros_2");
			Init(characterData);
			_bSecondBattle = true;
		}
		return base.GetBattleDlg(dlgType);
	}
}
