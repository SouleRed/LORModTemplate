namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_12_1 : DiceAttackEffect
{
}
