using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_209_1 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	[SerializeField]
	private Vector3 targetOffset;

	[SerializeField]
	private SpriteRenderer targetSprite;

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position + targetOffset * ((_self.direction != Direction.LEFT) ? 1 : (-1));
		targetSprite.flipX = _self.direction == Direction.LEFT;
		base.Update();
	}
}
