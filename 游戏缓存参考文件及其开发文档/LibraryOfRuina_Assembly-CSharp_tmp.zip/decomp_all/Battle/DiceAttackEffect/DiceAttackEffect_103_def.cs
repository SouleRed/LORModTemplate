namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_103_def : DiceAttackEffect
{
}
