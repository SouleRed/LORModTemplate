namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Yun_Yun_H : DiceAttackEffect
{
}
