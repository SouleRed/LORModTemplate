using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_210_1 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	[SerializeField]
	private Vector3 targetOffset;

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position + targetOffset * ((_self.direction == Direction.LEFT) ? 1 : (-1));
		base.Update();
	}
}
