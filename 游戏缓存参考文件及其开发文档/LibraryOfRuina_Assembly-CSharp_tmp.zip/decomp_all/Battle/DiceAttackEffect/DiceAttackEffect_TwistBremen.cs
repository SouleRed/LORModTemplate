namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_TwistBremen : DiceAttackEffect
{
	public override void SetScale(float scaleFactor)
	{
	}
}
