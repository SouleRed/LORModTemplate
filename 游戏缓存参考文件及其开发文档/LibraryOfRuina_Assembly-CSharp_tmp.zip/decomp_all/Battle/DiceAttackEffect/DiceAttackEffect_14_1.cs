namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_14_1 : DiceAttackEffect
{
}
