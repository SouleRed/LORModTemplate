namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_6_1 : DiceAttackEffect
{
}
