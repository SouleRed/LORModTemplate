using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_7_1 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position;
		base.Update();
	}
}
