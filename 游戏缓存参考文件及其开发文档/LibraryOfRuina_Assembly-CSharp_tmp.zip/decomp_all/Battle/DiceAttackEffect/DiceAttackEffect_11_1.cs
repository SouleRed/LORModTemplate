namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_11_1 : DiceAttackEffect
{
}
