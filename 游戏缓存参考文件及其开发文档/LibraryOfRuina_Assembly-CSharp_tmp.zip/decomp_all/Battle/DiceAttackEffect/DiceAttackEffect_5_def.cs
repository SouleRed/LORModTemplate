namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_5_def : DiceAttackEffect
{
}
