namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_2_3 : DiceAttackEffect
{
}
