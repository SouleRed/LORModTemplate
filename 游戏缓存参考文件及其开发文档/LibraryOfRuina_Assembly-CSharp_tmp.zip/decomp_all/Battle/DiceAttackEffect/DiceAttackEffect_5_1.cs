namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_5_1 : DiceAttackEffect
{
}
