namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_110_3 : DiceAttackEffect
{
}
