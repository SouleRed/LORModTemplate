namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_Naoki_H : DiceAttackEffect
{
}
