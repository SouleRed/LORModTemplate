namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_8_3 : DiceAttackEffect
{
}
