namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Street_San_Z : DiceAttackEffect
{
}
