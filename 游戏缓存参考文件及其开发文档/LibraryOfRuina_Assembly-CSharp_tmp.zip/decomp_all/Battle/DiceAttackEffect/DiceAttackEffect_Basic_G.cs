namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Basic_G : DiceAttackEffect
{
}
