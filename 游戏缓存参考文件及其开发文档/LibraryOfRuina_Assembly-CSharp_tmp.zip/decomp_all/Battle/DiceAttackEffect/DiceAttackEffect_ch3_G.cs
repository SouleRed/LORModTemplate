namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_ch3_G : DiceAttackEffect
{
}
