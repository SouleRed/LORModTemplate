namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Zwei_J : DiceAttackEffect
{
}
