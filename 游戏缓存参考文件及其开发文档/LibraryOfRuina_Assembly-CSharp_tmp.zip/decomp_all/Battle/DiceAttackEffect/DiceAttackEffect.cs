using System;
using UnityEngine;

namespace Battle.DiceAttackEffect;

[RequireComponent(typeof(SpriteRenderer), typeof(Animator))]
public class DiceAttackEffect : MonoBehaviour
{
	protected bool _bHasDamagedEffect;

	[SerializeField]
	protected Vector2 offset;

	[SerializeField]
	protected Vector3 additionalScale;

	[SerializeField]
	protected SpriteRenderer spr;

	[SerializeField]
	protected Animator animator;

	[SerializeField]
	protected float addedDestroyTime;

	protected float _destroyTime;

	protected BattleUnitModel _self;

	protected Transform _selfTransform;

	protected Transform _targetTransform;

	protected float _elapsed;

	protected Vector3 _initializedPos;

	public bool HasDamagedEffect => _bHasDamagedEffect;

	public virtual void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime)
	{
		_bHasDamagedEffect = false;
		_self = self.model;
		string[] array = base.gameObject.name.Split('_');
		Transform transform = _self.view.charAppearance.atkEffectRoot;
		if (array.Length != 0)
		{
			string text = array[array.Length - 1].ToUpper();
			if (text.Contains("H"))
			{
				transform = _self.view.charAppearance.GetAtkEffectPivot(ActionDetail.Hit);
			}
			else if (text.Contains("J"))
			{
				transform = _self.view.charAppearance.GetAtkEffectPivot(ActionDetail.Slash);
			}
			else if (text.Contains("Z"))
			{
				transform = _self.view.charAppearance.GetAtkEffectPivot(ActionDetail.Penetrate);
			}
			else if (text.Contains("G"))
			{
				transform = _self.view.charAppearance.GetAtkEffectPivot(ActionDetail.Guard);
			}
		}
		base.transform.parent = transform;
		_selfTransform = transform;
		_ = _self.view.characterRotationCenter.localScale;
		base.transform.localScale = (Vector3.one + additionalScale) * 2f;
		_targetTransform = target.atkEffectRoot;
		base.transform.localPosition = Vector3.zero + new Vector3(offset.x, offset.y, 0f);
		base.transform.localRotation = Quaternion.identity;
		_initializedPos = base.transform.position;
		_destroyTime = destroyTime + addedDestroyTime;
		animator.speed = 1f / _destroyTime;
		_elapsed = 0f;
	}

	public virtual void SetLayer(string layerName)
	{
		Transform[] componentsInChildren = GetComponentsInChildren<Transform>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].gameObject.layer = LayerMask.NameToLayer(layerName);
		}
	}

	public virtual void SetScale(float scaleFactor)
	{
		Vector3 localScale = base.transform.localScale * (1f + scaleFactor);
		base.transform.localScale = localScale;
	}

	public virtual void SetDestroyTime(float destroyTime)
	{
		_destroyTime = destroyTime;
	}

	protected virtual void Awake()
	{
		spr = GetComponent<SpriteRenderer>();
		animator = GetComponent<Animator>();
	}

	protected virtual void Start()
	{
	}

	protected virtual void Update()
	{
		_elapsed += Time.deltaTime;
		if (_elapsed >= _destroyTime)
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}
	}

	protected virtual void OnDestroy()
	{
	}

	public virtual void ResetLocalTransform(Transform t)
	{
		t.localScale = Vector3.one;
		t.localPosition = Vector3.zero;
		t.localRotation = Quaternion.identity;
	}

	public virtual void SetAutoDestruction(GameObject go, float time, bool destroyWhenDisable)
	{
		AutoDestruct autoDestruct = go.AddComponent<AutoDestruct>();
		autoDestruct.time = time;
		if (destroyWhenDisable)
		{
			autoDestruct.DestroyWhenDisable();
		}
	}

	public virtual void AddFilter(Type filter)
	{
		base.gameObject.AddComponent(filter);
	}
}
