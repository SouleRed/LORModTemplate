namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Yun_J : DiceAttackEffect
{
}
