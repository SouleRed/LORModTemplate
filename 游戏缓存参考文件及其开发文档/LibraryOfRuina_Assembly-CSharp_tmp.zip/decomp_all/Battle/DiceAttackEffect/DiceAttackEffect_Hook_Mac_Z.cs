namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_Mac_Z : DiceAttackEffect
{
}
