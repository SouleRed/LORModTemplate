using UnityEngine;

namespace Battle.DiceAttackEffect;

[RequireComponent(typeof(SpriteRenderer), typeof(Animator))]
public class DiceAttackEffectWithActionDetail : DiceAttackEffect
{
	[SerializeField]
	private ActionDetail actionDetail;

	[SerializeField]
	private float _minScaleFactor;

	[SerializeField]
	private float _maxScaleFactor;

	[SerializeField]
	private float _defaultScaleFactor;

	[SerializeField]
	private bool _hasDamagedEffect;

	[SerializeField]
	private GameObject _damagedEffect;

	[SerializeField]
	private bool _bZeroPosition;

	protected GameObject _damagedEffectObj;

	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime)
	{
		_bHasDamagedEffect = _hasDamagedEffect;
		_self = self.model;
		base.gameObject.name.Split('_');
		if (!_bZeroPosition)
		{
			Transform specialMotionPivot = _self.view.charAppearance.GetSpecialMotionPivot(actionDetail);
			base.transform.parent = specialMotionPivot;
		}
		else
		{
			base.transform.parent = _self.view.charAppearance.transform;
		}
		_selfTransform = base.transform;
		_ = _self.view.characterRotationCenter.localScale;
		_targetTransform = target.atkEffectRoot;
		base.transform.localScale = Vector3.one;
		base.transform.localPosition = Vector3.zero;
		base.transform.localRotation = Quaternion.identity;
		_initializedPos = base.transform.position;
		_destroyTime = destroyTime + addedDestroyTime;
		animator.speed = 1f / _destroyTime;
		_elapsed = 0f;
		if (_bHasDamagedEffect && target != null && _damagedEffect != null)
		{
			GameObject gameObject = Object.Instantiate(_damagedEffect, target.atkEffectRoot);
			gameObject.transform.localPosition = Vector3.zero;
			gameObject.transform.localScale = Vector3.one;
			gameObject.transform.localRotation = Quaternion.identity;
			_damagedEffectObj = gameObject;
			AutoDestruct autoDestruct = gameObject.AddComponent<AutoDestruct>();
			autoDestruct.time = 3f;
			autoDestruct.DestroyWhenDisable();
		}
	}

	public override void SetLayer(string layerName)
	{
		Transform[] componentsInChildren = GetComponentsInChildren<Transform>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].gameObject.layer = LayerMask.NameToLayer(layerName);
		}
	}

	public override void SetScale(float scaleFactor)
	{
		float num = _defaultScaleFactor + scaleFactor;
		if (num > _maxScaleFactor)
		{
			num = _maxScaleFactor;
		}
		else if (num < _minScaleFactor)
		{
			num = _minScaleFactor;
		}
		base.transform.localScale = Vector3.one * num;
	}
}
