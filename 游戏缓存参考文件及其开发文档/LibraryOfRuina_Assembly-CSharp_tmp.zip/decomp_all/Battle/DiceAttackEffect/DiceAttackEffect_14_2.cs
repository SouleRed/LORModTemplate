using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_14_2 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	protected override void Start()
	{
		base.Start();
	}

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position;
		base.Update();
	}
}
