namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_8_2 : DiceAttackEffect
{
}
