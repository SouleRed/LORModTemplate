namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Basic_J : DiceAttackEffect
{
}
