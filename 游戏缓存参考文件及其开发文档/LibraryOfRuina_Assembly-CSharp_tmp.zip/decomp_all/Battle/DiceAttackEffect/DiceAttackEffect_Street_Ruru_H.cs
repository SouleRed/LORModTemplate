namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Street_Ruru_H : DiceAttackEffect
{
}
