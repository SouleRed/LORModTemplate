namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_Z : DiceAttackEffect
{
}
