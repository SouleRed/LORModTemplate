namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_10_3 : DiceAttackEffect
{
}
