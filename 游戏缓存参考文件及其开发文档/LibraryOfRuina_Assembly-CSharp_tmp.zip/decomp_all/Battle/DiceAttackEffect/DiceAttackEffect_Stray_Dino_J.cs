namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Stray_Dino_J : DiceAttackEffect
{
}
