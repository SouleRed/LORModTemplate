namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_10_2 : DiceAttackEffect
{
}
