namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Iron_Cut_H : DiceAttackEffect
{
}
