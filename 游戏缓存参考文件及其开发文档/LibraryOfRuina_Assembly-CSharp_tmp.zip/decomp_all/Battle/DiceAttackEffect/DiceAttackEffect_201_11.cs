using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_201_11 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	[SerializeField]
	private Vector3 targetOffset;

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position;
		effectForTarget.rotation = Quaternion.identity;
		base.Update();
	}
}
