namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Pierr_H : DiceAttackEffect
{
}
