namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Pierr_Pierr_J : DiceAttackEffect
{
}
