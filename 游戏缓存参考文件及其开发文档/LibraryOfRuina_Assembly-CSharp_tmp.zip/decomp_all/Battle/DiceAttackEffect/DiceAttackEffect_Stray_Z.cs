namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Stray_Z : DiceAttackEffect
{
}
