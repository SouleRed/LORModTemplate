using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_8_1 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	protected override void Update()
	{
		if (effectForTarget != null)
		{
			effectForTarget.position = _targetTransform.position;
		}
		base.Update();
	}
}
