namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_Rain_H : DiceAttackEffect
{
}
