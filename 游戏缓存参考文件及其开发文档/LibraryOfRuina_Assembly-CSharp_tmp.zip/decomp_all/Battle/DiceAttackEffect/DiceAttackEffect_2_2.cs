namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_2_2 : DiceAttackEffect
{
}
