namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_ch1_J : DiceAttackEffect
{
}
