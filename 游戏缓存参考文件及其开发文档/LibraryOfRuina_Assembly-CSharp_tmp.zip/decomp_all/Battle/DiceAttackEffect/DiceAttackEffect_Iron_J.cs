namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Iron_J : DiceAttackEffect
{
}
