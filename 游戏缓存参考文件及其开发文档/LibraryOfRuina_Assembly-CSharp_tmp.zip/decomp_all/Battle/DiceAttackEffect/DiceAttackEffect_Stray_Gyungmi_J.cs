namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Stray_Gyungmi_J : DiceAttackEffect
{
}
