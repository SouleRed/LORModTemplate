namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_2_1 : DiceAttackEffect
{
}
