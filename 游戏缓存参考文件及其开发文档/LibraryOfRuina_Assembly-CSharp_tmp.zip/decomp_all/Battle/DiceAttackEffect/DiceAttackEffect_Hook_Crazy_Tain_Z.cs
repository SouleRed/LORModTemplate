namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_Crazy_Tain_Z : DiceAttackEffect
{
}
