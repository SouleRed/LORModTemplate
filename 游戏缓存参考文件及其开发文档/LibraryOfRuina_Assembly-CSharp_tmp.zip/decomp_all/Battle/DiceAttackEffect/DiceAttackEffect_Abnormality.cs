namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Abnormality : DiceAttackEffect
{
	public float lifeTime = 0.5f;

	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime)
	{
		base.Initialize(self, target, destroyTime * lifeTime);
	}
}
