namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Pierr_Every_Z : DiceAttackEffect
{
}
