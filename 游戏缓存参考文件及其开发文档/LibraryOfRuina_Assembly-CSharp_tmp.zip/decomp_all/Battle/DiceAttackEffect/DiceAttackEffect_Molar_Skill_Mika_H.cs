namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_Skill_Mika_H : DiceAttackEffect
{
}
