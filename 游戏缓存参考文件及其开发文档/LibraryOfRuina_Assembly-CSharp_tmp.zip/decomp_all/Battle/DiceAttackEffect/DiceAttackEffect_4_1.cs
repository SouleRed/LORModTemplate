namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_4_1 : DiceAttackEffect
{
}
