namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_Skill_H : DiceAttackEffect
{
}
