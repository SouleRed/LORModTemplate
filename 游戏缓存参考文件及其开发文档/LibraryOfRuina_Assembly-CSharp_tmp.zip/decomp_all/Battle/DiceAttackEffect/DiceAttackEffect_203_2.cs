using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_203_2 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	[SerializeField]
	private Vector3 targetOffset;

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position + targetOffset;
		base.Update();
	}
}
