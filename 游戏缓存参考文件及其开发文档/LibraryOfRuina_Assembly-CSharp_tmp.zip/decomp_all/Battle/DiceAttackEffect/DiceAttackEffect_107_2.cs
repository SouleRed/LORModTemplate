namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_107_2 : DiceAttackEffect
{
}
