namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_201_1 : DiceAttackEffect
{
}
