namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_107_1 : DiceAttackEffect
{
}
