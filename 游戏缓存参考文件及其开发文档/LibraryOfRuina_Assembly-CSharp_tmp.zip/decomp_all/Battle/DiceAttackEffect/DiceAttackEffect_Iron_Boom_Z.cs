namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Iron_Boom_Z : DiceAttackEffect
{
}
