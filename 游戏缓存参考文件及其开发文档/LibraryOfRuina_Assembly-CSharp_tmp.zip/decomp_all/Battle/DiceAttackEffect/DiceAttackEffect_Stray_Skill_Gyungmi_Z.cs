namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Stray_Skill_Gyungmi_Z : DiceAttackEffect
{
}
