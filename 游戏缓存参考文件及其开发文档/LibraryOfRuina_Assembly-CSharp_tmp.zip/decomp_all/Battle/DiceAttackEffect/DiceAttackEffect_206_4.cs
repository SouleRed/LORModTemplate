using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_206_4 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	private SpriteRenderer effectForTargetSpr;

	protected override void Start()
	{
		base.Start();
		effectForTargetSpr = effectForTarget.GetComponent<SpriteRenderer>();
	}

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position;
		effectForTargetSpr.flipX = ((_self.direction != Direction.LEFT) ? true : false);
		base.Update();
	}
}
