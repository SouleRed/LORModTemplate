namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_109_2 : DiceAttackEffect
{
}
