namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Yun_Pin_H : DiceAttackEffect
{
}
