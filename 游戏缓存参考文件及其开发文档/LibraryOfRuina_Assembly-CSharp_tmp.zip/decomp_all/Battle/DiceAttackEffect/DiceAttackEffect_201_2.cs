namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_201_2 : DiceAttackEffect
{
}
