namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_3_1 : DiceAttackEffect
{
}
