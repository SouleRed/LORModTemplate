namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Street_Fire_J : DiceAttackEffect
{
}
