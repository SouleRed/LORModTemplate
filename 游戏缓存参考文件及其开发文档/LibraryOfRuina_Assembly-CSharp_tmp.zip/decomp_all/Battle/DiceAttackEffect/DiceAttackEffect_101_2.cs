namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_101_2 : DiceAttackEffect
{
}
