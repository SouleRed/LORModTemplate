using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_108_1 : DiceAttackEffect
{
	[SerializeField]
	private Transform selfDust;

	[SerializeField]
	private Vector3 selfDustOffset;

	protected override void Update()
	{
		selfDust.transform.position = _selfTransform.position + selfDustOffset;
		selfDust.transform.rotation = Quaternion.identity;
		base.Update();
	}
}
