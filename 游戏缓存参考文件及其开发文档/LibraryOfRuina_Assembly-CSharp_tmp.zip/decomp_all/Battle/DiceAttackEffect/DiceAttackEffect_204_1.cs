namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_204_1 : DiceAttackEffect
{
}
