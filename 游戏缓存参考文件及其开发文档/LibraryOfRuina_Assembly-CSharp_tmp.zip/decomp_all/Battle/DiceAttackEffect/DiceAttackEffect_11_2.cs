namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_11_2 : DiceAttackEffect
{
}
