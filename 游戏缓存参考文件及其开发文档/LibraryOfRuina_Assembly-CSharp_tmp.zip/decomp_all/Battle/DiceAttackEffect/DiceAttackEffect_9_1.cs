using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_9_1 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	private Vector3 targetOffset;

	protected override void Start()
	{
		base.Start();
		targetOffset = new Vector3(offset.x, offset.y, 0f);
	}

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position + targetOffset * ((_self.direction == Direction.LEFT) ? 1 : (-1));
		base.Update();
	}
}
