namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_Crazy_J : DiceAttackEffect
{
}
