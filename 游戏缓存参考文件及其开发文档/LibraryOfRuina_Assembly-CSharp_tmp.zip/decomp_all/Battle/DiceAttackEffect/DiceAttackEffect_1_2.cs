namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_1_2 : DiceAttackEffect
{
}
