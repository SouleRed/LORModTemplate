namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Pierr_Jack_Z : DiceAttackEffect
{
}
