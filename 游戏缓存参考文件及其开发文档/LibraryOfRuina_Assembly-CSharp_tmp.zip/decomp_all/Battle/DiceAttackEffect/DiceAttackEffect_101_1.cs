namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_101_1 : DiceAttackEffect
{
}
