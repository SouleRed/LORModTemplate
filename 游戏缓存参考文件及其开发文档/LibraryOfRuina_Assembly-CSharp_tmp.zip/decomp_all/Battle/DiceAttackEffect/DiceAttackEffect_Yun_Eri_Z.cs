namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Yun_Eri_Z : DiceAttackEffect
{
}
