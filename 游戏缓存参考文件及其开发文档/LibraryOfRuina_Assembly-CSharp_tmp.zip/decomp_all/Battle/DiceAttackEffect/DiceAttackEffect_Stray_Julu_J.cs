namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Stray_Julu_J : DiceAttackEffect
{
}
