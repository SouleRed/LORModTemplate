namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_Olga_Z : DiceAttackEffect
{
}
