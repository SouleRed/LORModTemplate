namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Street_Mas_Z : DiceAttackEffect
{
}
