namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_J : DiceAttackEffect
{
}
