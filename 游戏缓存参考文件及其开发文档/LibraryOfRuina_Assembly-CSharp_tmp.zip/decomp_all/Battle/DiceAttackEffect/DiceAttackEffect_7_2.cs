namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_7_2 : DiceAttackEffect
{
}
