namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Rats_J : DiceAttackEffect
{
}
