namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Street_Z : DiceAttackEffect
{
}
