namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_Crazy_Mac_H : DiceAttackEffect
{
}
