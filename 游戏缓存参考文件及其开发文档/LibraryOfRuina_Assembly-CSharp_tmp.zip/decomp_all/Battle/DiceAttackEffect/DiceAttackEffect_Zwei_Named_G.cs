namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Zwei_Named_G : DiceAttackEffect
{
}
