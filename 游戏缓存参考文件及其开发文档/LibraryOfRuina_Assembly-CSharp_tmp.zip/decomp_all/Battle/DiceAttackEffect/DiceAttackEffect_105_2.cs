namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_105_2 : DiceAttackEffect
{
}
