namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Stray_Skill_Dino_J : DiceAttackEffect
{
}
