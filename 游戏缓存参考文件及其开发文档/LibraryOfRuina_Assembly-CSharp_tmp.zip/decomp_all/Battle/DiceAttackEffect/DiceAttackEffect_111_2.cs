namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_111_2 : DiceAttackEffect
{
}
