namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_102_1 : DiceAttackEffect
{
}
