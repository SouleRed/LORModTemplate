namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_ch2_J : DiceAttackEffect
{
}
