namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_1_1 : DiceAttackEffect
{
}
