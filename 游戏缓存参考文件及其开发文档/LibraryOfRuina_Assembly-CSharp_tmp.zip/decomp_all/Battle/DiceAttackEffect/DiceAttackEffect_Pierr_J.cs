namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Pierr_J : DiceAttackEffect
{
}
