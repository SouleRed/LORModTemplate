using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_207_2 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	[SerializeField]
	private Vector3 targetOffset;

	[SerializeField]
	private SpriteRenderer effectForTargetSpr1;

	[SerializeField]
	private SpriteRenderer effectForTargetSpr2;

	protected override void Start()
	{
		base.Start();
	}

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position + targetOffset * ((_self.direction == Direction.LEFT) ? 1 : (-1));
		effectForTargetSpr1.flipX = _self.direction == Direction.LEFT;
		effectForTargetSpr2.flipX = _self.direction == Direction.LEFT;
		base.Update();
	}
}
