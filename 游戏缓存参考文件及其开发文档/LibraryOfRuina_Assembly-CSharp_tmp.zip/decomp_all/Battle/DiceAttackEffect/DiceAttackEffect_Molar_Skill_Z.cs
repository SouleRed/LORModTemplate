namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_Skill_Z : DiceAttackEffect
{
}
