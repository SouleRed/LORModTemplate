namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_5_2 : DiceAttackEffect
{
}
