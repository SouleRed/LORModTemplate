namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_Crazy_Naoki_H : DiceAttackEffect
{
}
