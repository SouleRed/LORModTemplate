namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Stray_Skill_Julu_J : DiceAttackEffect
{
}
