namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Street_J : DiceAttackEffect
{
}
