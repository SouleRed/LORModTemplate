namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_9_2 : DiceAttackEffect
{
}
