namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_ch3_E : DiceAttackEffect
{
}
