namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Street_San_H : DiceAttackEffect
{
}
