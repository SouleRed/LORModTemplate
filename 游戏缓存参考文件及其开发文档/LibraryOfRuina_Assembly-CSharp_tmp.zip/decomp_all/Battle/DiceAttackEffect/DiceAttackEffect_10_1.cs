namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_10_1 : DiceAttackEffect
{
}
