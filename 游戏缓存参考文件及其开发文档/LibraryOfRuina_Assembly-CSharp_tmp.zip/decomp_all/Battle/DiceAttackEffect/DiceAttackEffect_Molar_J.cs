namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_J : DiceAttackEffect
{
}
