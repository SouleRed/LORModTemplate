namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Molar_Mika_J : DiceAttackEffect
{
}
