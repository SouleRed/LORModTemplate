using UnityEngine;

namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_203_1 : DiceAttackEffect
{
	[SerializeField]
	private Transform effectForTarget;

	[SerializeField]
	private Vector3 targetOffset;

	private SpriteRenderer effectForTargetSpr;

	protected override void Start()
	{
		base.Start();
		effectForTargetSpr = effectForTarget.GetComponent<SpriteRenderer>();
	}

	protected override void Update()
	{
		effectForTarget.position = _targetTransform.position + targetOffset * ((_self.direction == Direction.LEFT) ? 1 : (-1));
		base.Update();
	}
}
