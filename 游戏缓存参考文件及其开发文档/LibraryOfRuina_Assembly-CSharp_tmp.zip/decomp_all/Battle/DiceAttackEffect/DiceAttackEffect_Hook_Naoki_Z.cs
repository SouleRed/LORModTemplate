namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_Hook_Naoki_Z : DiceAttackEffect
{
}
