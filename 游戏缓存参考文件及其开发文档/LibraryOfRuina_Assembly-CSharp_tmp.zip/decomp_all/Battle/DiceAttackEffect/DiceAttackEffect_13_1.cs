namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_13_1 : DiceAttackEffect
{
}
