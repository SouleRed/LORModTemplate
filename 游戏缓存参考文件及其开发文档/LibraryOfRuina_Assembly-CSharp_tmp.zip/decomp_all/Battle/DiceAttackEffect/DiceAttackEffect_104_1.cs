namespace Battle.DiceAttackEffect;

public class DiceAttackEffect_104_1 : DiceAttackEffect
{
}
