using Sound;
using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_BloodDrain : CreatureEffect
{
	[SerializeField]
	private GameObject _absorbEffect;

	[SerializeField]
	private GameObject _absorbDoneEffect;

	[SerializeField]
	private AudioClip _absorbDoneSound;

	private AbsorbEffectInfo ae;

	private float _absorbDelay = 0.3f;

	private float _elapsedAbsorb;

	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime = -1f)
	{
		_self = self.model;
		base.transform.parent = _self.view.charAppearance.atkEffectRoot;
		_selfTransform = _self.view.charAppearance.atkEffectRoot;
		_ = _self.view.characterRotationCenter.localScale;
		base.transform.localScale = Vector3.one + additionalScale;
		_targetTransform = target?.atkEffectRoot;
		Vector3 vector = target.charAppearance.atkEffectRoot.position + new Vector3(offset.x, offset.y, 0f);
		Vector3 vector2 = self.charAppearance.atkEffectRoot.position + new Vector3(offset.x, offset.y, 0f);
		base.transform.position = vector2;
		_permanent = false;
		_destroyTime = destroyTime;
		_elapsed = 0f;
		StartAudioClip();
		ae = new AbsorbEffectInfo(_absorbEffect, vector, vector2);
		_absorbEffect.transform.position = vector;
		_absorbEffect.SetActive(value: true);
		AutoDestruct autoDestruct = base.gameObject.AddComponent<AutoDestruct>();
		autoDestruct.time = 3f;
		autoDestruct.DestroyWhenDisable();
	}

	public override void OnPrintEffect()
	{
		base.OnPrintEffect();
		base.gameObject.SetActive(value: true);
	}

	public override void Update()
	{
		if (ae != null)
		{
			_elapsedAbsorb += Time.deltaTime;
			ae.SetPos(_elapsedAbsorb / _absorbDelay);
			if (!_absorbDoneEffect.activeInHierarchy && _elapsedAbsorb >= _absorbDelay)
			{
				SingletonBehavior<SoundEffectManager>.Instance.PlayClip(_absorbDoneSound);
				_absorbDoneEffect.SetActive(value: true);
				ae.effectObj.SetActive(value: false);
			}
		}
		base.Update();
	}
}
