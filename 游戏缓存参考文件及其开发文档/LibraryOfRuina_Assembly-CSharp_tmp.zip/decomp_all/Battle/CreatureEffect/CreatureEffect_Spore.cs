using System.Collections.Generic;
using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Spore : CreatureEffect
{
	public class TileEffect
	{
		public Vector3 pos;

		public GameObject particle;
	}

	public GameObject EffectObject;

	public Vector3 localScale = Vector3.one;

	private Dictionary<Vector3, TileEffect> tilePos = new Dictionary<Vector3, TileEffect>();

	public void AddTileEffect(Vector3 globalPos)
	{
		if (!tilePos.ContainsKey(globalPos))
		{
			GameObject gameObject = Object.Instantiate(EffectObject);
			gameObject.transform.position = globalPos;
			gameObject.transform.SetParent(base.transform);
			gameObject.transform.localScale = localScale;
			TileEffect value = new TileEffect
			{
				pos = globalPos,
				particle = gameObject
			};
			tilePos.Add(globalPos, value);
		}
	}

	private void LateUpdate()
	{
		foreach (BattleUnitModel alive in BattleObjectManager.instance.GetAliveList())
		{
			Vector3 globalPos = SingletonBehavior<HexagonalMapManager>.Instance.ViewToCellWorldPos(alive.view.WorldPosition);
			AddTileEffect(globalPos);
		}
	}

	public void ClearEffects()
	{
		foreach (TileEffect value in tilePos.Values)
		{
			Object.Destroy(value.particle);
		}
		tilePos.Clear();
	}
}
