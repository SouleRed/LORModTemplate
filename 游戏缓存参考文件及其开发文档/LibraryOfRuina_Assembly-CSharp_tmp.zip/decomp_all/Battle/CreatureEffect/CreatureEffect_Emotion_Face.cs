using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Emotion_Face : CreatureEffect
{
	[SerializeField]
	private GameObject[] faces;

	public void SetFace(int idx)
	{
		GameObject[] array = faces;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(value: false);
		}
		faces[idx].SetActive(value: true);
	}
}
