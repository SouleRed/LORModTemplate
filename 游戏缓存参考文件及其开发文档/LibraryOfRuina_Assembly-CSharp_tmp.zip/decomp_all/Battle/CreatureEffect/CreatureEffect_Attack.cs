using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Attack : CreatureEffect
{
	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime = -1f)
	{
		_self = self.model;
		base.transform.parent = _self.view.charAppearance.atkEffectRoot;
		_selfTransform = _self.view.charAppearance.atkEffectRoot;
		_ = _self.view.characterRotationCenter.localScale;
		base.transform.localScale = (Vector3.one + additionalScale) * 2f;
		_targetTransform = target?.atkEffectRoot;
		base.transform.localPosition = Vector3.zero + new Vector3(offset.x, offset.y, 0f);
		_permanent = false;
		_destroyTime = destroyTime;
		_elapsed = 0f;
		StartAudioClip();
	}

	public override void OnPrintEffect()
	{
		base.OnPrintEffect();
		base.gameObject.SetActive(value: true);
	}
}
