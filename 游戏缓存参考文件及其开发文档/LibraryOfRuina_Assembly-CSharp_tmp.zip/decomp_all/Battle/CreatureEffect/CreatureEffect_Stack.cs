using System;
using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Stack : CreatureEffect
{
	private int _stackCount;

	public Sprite[] StackSprites;

	public Sprite DefaultSprite;

	private Sprite _lastSprite;

	public SpriteRenderer SpriteRenderer;

	[SerializeField]
	protected int _maxStackCount = 1;

	public int StackCount => _stackCount;

	public int MaxStackCount => _maxStackCount;

	public void InitByCode(int max)
	{
		_maxStackCount = max;
		InitStack();
	}

	private void Awake()
	{
		if ((bool)SpriteRenderer)
		{
			SpriteRenderer = base.gameObject.GetComponent<SpriteRenderer>();
		}
	}

	public void AddStack()
	{
		SetStack(StackCount + 1);
	}

	public void SubStack()
	{
		SetStack(StackCount - 1);
	}

	public void InitStack()
	{
		SetStack(0);
	}

	public void SetStack(int stackValue)
	{
		if (stackValue < 0)
		{
			_stackCount = 0;
		}
		else if (stackValue > MaxStackCount)
		{
			_stackCount = MaxStackCount;
		}
		else
		{
			_stackCount = stackValue;
		}
		try
		{
			if (StackSprites.Length >= 1)
			{
				SpriteRenderer.sprite = StackSprites[stackValue];
				_lastSprite = SpriteRenderer.sprite;
			}
		}
		catch (Exception message)
		{
			Debug.LogError(message);
			if (SpriteRenderer != null)
			{
				if (_lastSprite != null)
				{
					SpriteRenderer.sprite = _lastSprite;
				}
				else if (DefaultSprite != null)
				{
					SpriteRenderer.sprite = DefaultSprite;
				}
			}
		}
	}

	public bool IsActive()
	{
		return base.gameObject.activeInHierarchy;
	}

	public void SetActive(bool state)
	{
		base.gameObject.SetActive(state);
	}

	public override void OnPrintEffect()
	{
		base.OnPrintEffect();
	}
}
