using System;
using Sound;
using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect : MonoBehaviour
{
	[SerializeField]
	protected Vector2 offset;

	[SerializeField]
	protected Vector3 additionalScale;

	protected BattleUnitModel _self;

	protected Transform _selfTransform;

	protected Transform _targetTransform;

	protected bool _permanent = true;

	protected float _destroyTime;

	protected float _elapsed;

	protected EmotionCardAbilityBase _abilityBase;

	protected BattleDiceBehavior _behavior;

	public string SoundSrc = "";

	protected SoundEffectPlayer _sound;

	public void SetEmotionCardAbility(EmotionCardAbilityBase abilityBase)
	{
		_abilityBase = abilityBase;
	}

	public void SetBattleDiceBehavior(BattleDiceBehavior behavior)
	{
		_behavior = behavior;
	}

	public virtual void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime = -1f)
	{
		_self = self.model;
		BodyAura component = base.gameObject.GetComponent<BodyAura>();
		base.transform.parent = _self.view.characterRotationCenter;
		_selfTransform = _self.view.characterRotationCenter;
		if (component != null)
		{
			if (target != null)
			{
				component.SetAppearance(target.model);
			}
			else if (self != null)
			{
				component.SetAppearance(self.model);
			}
		}
		if (target != null)
		{
			base.transform.parent = target.characterRotationCenter;
			_selfTransform = target.characterRotationCenter;
		}
		base.transform.localScale = Vector3.one + additionalScale;
		_targetTransform = target?.atkEffectRoot;
		base.transform.localPosition = Vector3.zero + new Vector3(offset.x, offset.y, 0f);
		base.transform.localRotation = Quaternion.identity;
		if (destroyTime != -1f)
		{
			_permanent = false;
			_destroyTime = destroyTime;
		}
		StartAudioClip();
	}

	public virtual void Update()
	{
		if (!_permanent)
		{
			_elapsed += Time.deltaTime;
			if (_elapsed >= _destroyTime)
			{
				UnityEngine.Object.Destroy(base.gameObject);
			}
		}
	}

	public void SetLayer(string layerName)
	{
		Transform[] componentsInChildren = GetComponentsInChildren<Transform>();
		foreach (Transform transform in componentsInChildren)
		{
			if (transform.gameObject != null)
			{
				transform.gameObject.layer = LayerMask.NameToLayer(layerName);
			}
		}
	}

	public virtual void ManualDestroy()
	{
		UnityEngine.Object.Destroy(base.gameObject);
	}

	public virtual void OnPrintEffect()
	{
		try
		{
			_abilityBase?.OnPrintEffect(_behavior);
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
	}

	public virtual void AttachEffectLayer()
	{
		base.transform.SetParent(BattleEffectLayer.instance.transform);
	}

	public void StartAudioClip()
	{
		if (!string.IsNullOrEmpty(SoundSrc))
		{
			SoundEffectPlayer soundEffectPlayer = SingletonBehavior<SoundEffectManager>.Instance.PlayClip("Creature/" + SoundSrc);
			soundEffectPlayer?.SetAttachParent(base.transform);
			_sound = soundEffectPlayer;
		}
	}

	private void OnEnable()
	{
		if ((bool)_sound)
		{
			_sound.SetParentAsManager();
			_sound = null;
		}
	}
}
