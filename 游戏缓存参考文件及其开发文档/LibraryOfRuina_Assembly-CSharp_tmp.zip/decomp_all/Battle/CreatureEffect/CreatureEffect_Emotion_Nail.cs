namespace Battle.CreatureEffect;

public class CreatureEffect_Emotion_Nail : CreatureEffect
{
}
