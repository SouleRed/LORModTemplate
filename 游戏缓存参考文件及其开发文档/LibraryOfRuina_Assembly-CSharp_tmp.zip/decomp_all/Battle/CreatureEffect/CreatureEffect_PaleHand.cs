using System;
using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_PaleHand : CreatureEffect
{
	public SpriteRenderer[] hands;

	public Animator _anim;

	private int _prevStack;

	public void SetStack(int stackCount)
	{
		_prevStack = stackCount;
		_anim.SetInteger("Stack", stackCount);
		if (stackCount == 0)
		{
			return;
		}
		try
		{
			for (int i = 0; i < 3; i++)
			{
				if (i < stackCount)
				{
					hands[i].enabled = true;
					continue;
				}
				hands[i].enabled = false;
				hands[i].GetComponent<_2dxFX_Liquid>()._Alpha = 0f;
			}
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
	}

	public void Disappear()
	{
		_anim.SetBool("Disappeared", value: true);
	}

	public void ResetAnim()
	{
		_anim.SetTrigger("Reset");
		SpriteRenderer[] array = hands;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].enabled = false;
		}
		_prevStack = 0;
	}

	public void SetActive(bool state)
	{
		base.gameObject.SetActive(state);
	}

	private void OnEnable()
	{
		_anim.SetInteger("Stack", _prevStack);
	}

	public void OnAnimEvent()
	{
		ManualDestroy();
	}

	public void Clear()
	{
		_anim.SetTrigger("Disapp");
	}
}
