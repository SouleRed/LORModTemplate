using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Nail : CreatureEffect
{
	public ParticleSystem pSystem;

	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime = -1f)
	{
		base.Initialize(self, target, destroyTime);
	}

	public void SetEmitValue(int level)
	{
		ParticleSystem.EmissionModule emission = pSystem.emission;
		ParticleSystem.Burst burst = emission.GetBurst(0);
		burst.count = level;
		emission.SetBurst(0, burst);
	}

	public override void OnPrintEffect()
	{
		base.OnPrintEffect();
		base.gameObject.SetActive(value: true);
	}
}
