using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_BeautyBeast : CreatureEffect
{
	public Material defaultMaterial;

	public Material hitMaterial;

	private float _elap;

	public float hitDuration = 1f;

	private bool _hit;

	public ParticleSystemRenderer eyeRenderer;

	public ParticleSystemRenderer harted;

	public void Hit()
	{
		_elap = 0f;
		_hit = true;
		ChangeMaterial(state: false);
	}

	private void ChangeMaterial(bool state)
	{
		eyeRenderer.gameObject.SetActive(state);
		harted.gameObject.SetActive(!state);
	}

	public void FixedUpdate()
	{
		if (_hit)
		{
			_elap += Time.deltaTime;
			if (_elap > hitDuration)
			{
				_elap = 0f;
				_hit = false;
				ChangeMaterial(state: true);
			}
		}
	}
}
