using System;
using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_FaceAttacher : CreatureEffect
{
	private const string _faceTag = "face";

	protected Transform appearanceTarget;

	public Transform FindFace(Transform transform)
	{
		foreach (Transform item in transform)
		{
			if (item.gameObject.activeInHierarchy)
			{
				if (item.gameObject.name == "face")
				{
					return item;
				}
				Transform transform3 = FindFace(item);
				if (transform3 != null)
				{
					return transform3;
				}
			}
		}
		return null;
	}

	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime = -1f)
	{
		_self = self.model;
		base.transform.parent = _self.view.charAppearance.transform;
		_selfTransform = _self.view.charAppearance.transform;
		base.transform.localScale = Vector3.one + additionalScale;
		_targetTransform = target?.atkEffectRoot;
		base.transform.localRotation = Quaternion.identity;
		if (destroyTime != -1f)
		{
			_permanent = false;
			_destroyTime = destroyTime;
		}
		appearanceTarget = self.charAppearance.transform;
		OnChangeAnim();
		try
		{
			self.charAppearance.AddOnCharMotionChanged(OnChangeAnim);
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
		StartAudioClip();
	}

	public void AttachTarget(BattleUnitView target, float destroyTime = -1f)
	{
		try
		{
			_self.view.charAppearance.RemoveOnCharMotionChanged(OnChangeAnim);
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
		_self = target.model;
		base.transform.parent = _self.view.charAppearance.transform;
		_selfTransform = _self.view.charAppearance.transform;
		base.transform.localScale = Vector3.one + additionalScale;
		_targetTransform = target?.atkEffectRoot;
		base.transform.localRotation = Quaternion.identity;
		if (destroyTime != -1f)
		{
			_permanent = false;
			_destroyTime = destroyTime;
		}
		appearanceTarget = target.charAppearance.transform;
		OnChangeAnim();
		try
		{
			target.charAppearance.AddOnCharMotionChanged(OnChangeAnim);
		}
		catch (Exception message2)
		{
			Debug.LogError(message2);
		}
	}

	private void OnDestroy()
	{
		try
		{
			_self.view.charAppearance.RemoveOnCharMotionChanged(OnChangeAnim);
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
	}

	public void OnChangeAnim()
	{
		Transform transform = FindFace(appearanceTarget);
		if ((bool)transform)
		{
			base.transform.position = transform.position + new Vector3(offset.x, offset.y);
			base.transform.SetParent(transform);
		}
	}
}
