using System;
using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Shield : CreatureEffect
{
	public AnimationCurve AlphaCurve;

	public SpriteRenderer AlphaRenderer;

	[SerializeField]
	protected bool _useDefaultAlphaSetting = true;

	private void Awake()
	{
		if (AlphaRenderer == null)
		{
			AlphaRenderer = base.gameObject.GetComponent<SpriteRenderer>();
		}
	}

	public override void Update()
	{
		base.Update();
		SetAlpha();
	}

	private void SetAlpha()
	{
		if (_permanent || !_useDefaultAlphaSetting)
		{
			return;
		}
		try
		{
			float time = _elapsed / _destroyTime;
			float a = AlphaCurve.Evaluate(time);
			Color color = AlphaRenderer.color;
			color.a = a;
			AlphaRenderer.color = color;
		}
		catch (Exception message)
		{
			Debug.LogError(message);
			_permanent = true;
		}
	}
}
