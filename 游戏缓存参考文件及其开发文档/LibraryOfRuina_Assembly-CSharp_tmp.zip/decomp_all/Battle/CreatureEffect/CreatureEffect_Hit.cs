using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Hit : CreatureEffect
{
	public bool useDefaultEffect;

	private SpriteRenderer rend;

	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime = -1f)
	{
		base.Initialize(self, target, 1f);
		_sound?.SetParentAsManager();
	}

	public void SetPerm()
	{
		_permanent = true;
	}

	public override void OnPrintEffect()
	{
		base.OnPrintEffect();
		base.gameObject.SetActive(value: true);
	}

	private void SetAlpha()
	{
		if (rend == null)
		{
			rend = base.gameObject.GetComponent<SpriteRenderer>();
		}
		Color color = rend.color;
		color.a = Mathf.Clamp(1f - _elapsed / _destroyTime, 0f, 1f);
		rend.color = color;
	}

	public override void Update()
	{
		if (useDefaultEffect && !_permanent)
		{
			_elapsed += Time.deltaTime;
			SetAlpha();
			if (_elapsed > _destroyTime)
			{
				ManualDestroy();
			}
		}
		else
		{
			base.Update();
		}
	}
}
