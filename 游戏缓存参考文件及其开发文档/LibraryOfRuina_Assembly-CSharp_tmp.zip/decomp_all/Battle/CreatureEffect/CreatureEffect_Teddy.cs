using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Teddy : CreatureEffect
{
	private float _elap;

	private float _max = 1f;

	private bool _smokeEnabled;

	public Animator stackAnim;

	public SpriteRenderer stackSprite;

	public ParticleSystem smokeEffect;

	public override void Initialize(BattleUnitView self, BattleUnitView target, float destroyTime = -1f)
	{
		base.Initialize(self, target, destroyTime);
	}

	public void OnHit()
	{
		_smokeEnabled = true;
		_elap = 0f;
		smokeEffect.gameObject.SetActive(value: true);
		stackAnim.SetTrigger("Hit");
	}

	public override void Update()
	{
		if (_smokeEnabled)
		{
			_elap += Time.deltaTime;
			if (_elap > _max)
			{
				_smokeEnabled = false;
				smokeEffect.gameObject.SetActive(value: false);
			}
		}
	}
}
