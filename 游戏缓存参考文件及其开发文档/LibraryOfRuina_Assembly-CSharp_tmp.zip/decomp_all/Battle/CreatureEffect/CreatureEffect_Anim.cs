using UnityEngine;

namespace Battle.CreatureEffect;

public class CreatureEffect_Anim : CreatureEffect
{
	[SerializeField]
	protected Animator anim;

	public void SetTrigger(string paramName)
	{
		anim.SetTrigger(paramName);
	}

	public void SetDestroyTime(float time)
	{
		_permanent = false;
		_destroyTime = time;
	}
}
