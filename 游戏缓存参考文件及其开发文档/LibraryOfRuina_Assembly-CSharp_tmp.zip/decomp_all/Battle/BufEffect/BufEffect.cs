using Sound;
using UnityEngine;

namespace Battle.BufEffect;

public class BufEffect : MonoBehaviour
{
	[SerializeField]
	protected Vector2 offset;

	[SerializeField]
	protected Vector3 additionalScale;

	protected BattleUnitModel _self;

	protected Transform _selfTransform;

	protected Transform _targetTransform;

	protected float _destroyTime = 1.5f;

	protected float _elapsed;

	public string SoundSrc = "";

	protected SoundEffectPlayer _sound;

	public virtual void Initialize(BattleUnitView self)
	{
		_self = self.model;
		base.transform.parent = _self.view.camRotationFollower.transform;
		_selfTransform = _self.view.camRotationFollower.transform;
		base.transform.localScale = Vector3.one + additionalScale;
		base.transform.localPosition = Vector3.zero + new Vector3(offset.x, offset.y, 0f);
		base.transform.localRotation = Quaternion.identity;
		StartAudioClip();
	}

	private void Update()
	{
		_elapsed += Time.deltaTime;
		if (_elapsed >= _destroyTime)
		{
			Object.Destroy(base.gameObject);
		}
	}

	public void SetLayer(string layerName)
	{
		Transform[] componentsInChildren = GetComponentsInChildren<Transform>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].gameObject.layer = LayerMask.NameToLayer(layerName);
		}
	}

	public void ManualDestroy()
	{
		Object.Destroy(base.gameObject);
	}

	public void StartAudioClip()
	{
		if (!string.IsNullOrEmpty(SoundSrc))
		{
			SoundEffectPlayer soundEffectPlayer = SingletonBehavior<SoundEffectManager>.Instance.PlayClip("Buf/" + SoundSrc);
			soundEffectPlayer?.SetAttachParent(base.transform);
			_sound = soundEffectPlayer;
		}
	}

	private void OnEnable()
	{
		if ((bool)_sound)
		{
			_sound.SetParentAsManager();
			_sound = null;
		}
	}
}
