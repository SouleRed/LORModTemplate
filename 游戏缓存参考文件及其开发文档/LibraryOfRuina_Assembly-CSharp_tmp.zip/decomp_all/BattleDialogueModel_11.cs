using LOR_XML;

public class BattleDialogueModel_11 : BattleDialogueModel_Librarian
{
	public BattleDialogueModel_11(BattleDialogCharacter battleDlg)
		: base(battleDlg)
	{
		_floorName_RB1 = "Malkuth";
		_characterId_RB1 = "M_P_Librarian_";
		_stageId_RB1 = 70001;
		_characterId_BS = "M_Librarian";
		_sephirahType = SephirahType.Malkuth;
		_characterId_RB2 = _characterId_BS;
	}
}
